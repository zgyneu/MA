import json
import os
import time
from multiprocessing.pool import Pool

from Utils.Convert_Node_Graph_into_Graph import *
from VRP_Algs import Memetic_Algorithm_vrp as MA
from VRP_Algs.Memetic_Algorithm_vrp import *
from VRP_Algs.Simulated_Annealing_vrp import SA
from VRP_Algs.Tabu_Search_vrp import TS


# 多进程处理
class Plotter:
    def __init__(self, instance_id=1):
        self._data_reserve = copy.deepcopy(Converter(instance_id).data)
        self._parameters_data = {}
        self._process_data = {}
        self._data = copy.deepcopy(self._data_reserve)

    def solve_multiple_times(self, cls, m_seeds, m_population, m_iter_time, m_penalty_coefficient,
                             m_terminate_by_fitness_equal,
                             m_change_parameters=False, m_need_correct_pickup_delivery=False,
                             m_shift_cross_and_mutation_on=False, m_dynamic_probability=False, m_niche_num=1,
                             m_is_ga=False,
                             m_target=MA.TargetEnum.TIME):
        """

        :param m_population:
        :param m_niche_num:
        :param m_change_parameters:
        :param m_need_correct_pickup_delivery:
        :param m_dynamic_probability:
        :param m_shift_cross_and_mutation_on:
        :param cls:
        :param m_seeds:
        :param m_iter_time:
        :param m_penalty_coefficient:
        :param m_terminate_by_fitness_equal:
        :return:
        """

        # _obj_cost_record = np.zeros(m_iter_time)
        # _obj_without_penalty_cost_record = np.zeros(m_iter_time)
        _iter_chromosome_record: list[list[MA.Chromosome]] = []
        for _seed in m_seeds:
            self._data = copy.deepcopy(self._data_reserve)

            if m_change_parameters:
                obj = cls(seed=_seed, population=m_population, iter_time=m_iter_time,
                          penalty_coefficient=m_penalty_coefficient,
                          terminate_by_fitness_equal=m_terminate_by_fitness_equal, target=m_target)
                obj.change_parameters(need_correct_pickup_delivery=m_need_correct_pickup_delivery,
                                      shift_cross_and_mutation_on=m_shift_cross_and_mutation_on,
                                      dynamic_probability=m_dynamic_probability, iter_time=m_iter_time,
                                      niche_num=m_niche_num, is_ga=m_is_ga)
            else:
                obj = cls(seed=_seed, population=m_population, niche_num=m_niche_num,
                          penalty_coefficient=m_penalty_coefficient,
                          terminate_by_fitness_equal=m_terminate_by_fitness_equal, target=m_target)
            # _, _, _obj_iter_cost_record, _obj_iter_cost_without_penalty_record\
            _obj_one_iter_chromosome_record: list[MA.Chromosome] = obj.solve_vrp(
                self._data["time_matrix"], self._data["pickups_deliveries"], self._data["time_windows"],
                self._data["demands"], self._data["depot"], self._data["binding"], self._data["num_vehicles"],
                self._data["vehicle_capacities"], self._data["distance_matrix"], self._data["service_time"],
                b_return_iter_cost=True
            )
            _iter_chromosome_record.append(_obj_one_iter_chromosome_record)
            # _obj_cost_record += np.array(_obj_iter_cost_record[:m_iter_time])
            # _obj_without_penalty_cost_record += np.array(_obj_iter_cost_without_penalty_record[:m_iter_time])
            del obj
            gc.collect()
            # print(_obj_cost_record)
        # return _obj_cost_record / len(m_seeds), _obj_without_penalty_cost_record / len(m_seeds)
        return _iter_chromosome_record


def gen_dir() -> str:
    from time import strftime
    # img_dir_name = time.strftime("%Y_%m_%d_%H_%M")

    img_dir_name = strftime("%Y_%m_%d_%H_%M")
    os.mkdir("../Img/" + img_dir_name)
    os.mkdir("../Img/" + img_dir_name + "/process")
    os.mkdir("../Img/" + img_dir_name + "/parameters")
    return "../Img/" + img_dir_name


def save_parameter_data(parameter_dir, seeds, population, iter_time):
    """
    保存每次实验的参数数据
    :return:
    """
    _parameter_map = {
        "seeds": seeds,
        "population": population,
        "iter_time": iter_time,
        "penalty_coefficient": penalty_coefficient,
    }
    f = open(parameter_dir + "/parameters.json", 'w')
    parameters_data = json.dumps(_parameter_map, indent=2, ensure_ascii=False)
    f.write(parameters_data)
    f.close()


def save_iter_data(process_dir, all_seeds_iter_data: list[list[MA.Chromosome]], key_words):
    """
    保存每次实验的实验迭代原始数据
    :return:
    """
    tw_penalty_count_matrix = []
    cap_penalty_count_matrix = []
    pd_penalty_count_matrix = []
    fitness_value_matrix = []
    real_value_matrix = []
    for _one_seed_iter_data in all_seeds_iter_data:
        tw_penalty_count_arr = []
        cap_penalty_count_arr = []
        pd_penalty_count_arr = []
        fitness_value_arr = []
        real_value_arr = []
        for _chromosome in _one_seed_iter_data:
            tw_penalty_count_arr.append(_chromosome.fitness.tw_penalty_count)
            cap_penalty_count_arr.append(_chromosome.fitness.cap_penalty_count)
            pd_penalty_count_arr.append(_chromosome.fitness.pd_penalty_count)
            fitness_value_arr.append(_chromosome.fitness.fitness_value)
            real_value_arr.append(_chromosome.fitness.real_value)
        tw_penalty_count_matrix.append(tw_penalty_count_arr)
        cap_penalty_count_matrix.append(cap_penalty_count_arr)
        pd_penalty_count_matrix.append(pd_penalty_count_arr)
        fitness_value_matrix.append(fitness_value_arr)
        real_value_matrix.append(real_value_arr)
    _process_map = {
        "tw_penalty_count_matrix": tw_penalty_count_matrix,
        "cap_penalty_count_matrix": cap_penalty_count_matrix,
        "pd_penalty_count_matrix": pd_penalty_count_matrix,
        "fitness_value_matrix": fitness_value_matrix,
        "real_value_matrix": real_value_matrix,
    }
    f = open(process_dir + "/" + key_words + ".json", 'w')
    process_data = json.dumps(_process_map, indent=2, ensure_ascii=False)
    f.write(process_data)
    f.close()


def mp_run(instance_id: int, cls, m_seeds, m_population, m_iter_time, m_penalty_coefficient,
           m_terminate_by_fitness_equal,
           m_change_parameters=False, m_need_correct_pickup_delivery=False, m_shift_cross_and_mutation_on=False,
           m_dynamic_probability=False, m_niche_num=1, m_is_ga=False, m_target=MA.TargetEnum.TIME, process_dir_0="", ):
    _plotter = Plotter(instance_id=instance_id)
    print("instance_id:", instance_id, " start.")
    _iter_record = _plotter.solve_multiple_times(cls, m_seeds, m_population, m_iter_time, m_penalty_coefficient,
                                                 m_terminate_by_fitness_equal, m_change_parameters,
                                                 m_need_correct_pickup_delivery, m_shift_cross_and_mutation_on,
                                                 m_dynamic_probability, m_niche_num, m_is_ga, m_target)
    save_iter_data(process_dir_0, _iter_record, "instance-" + str(instance_id) + "_NMA-" + str(m_niche_num))
    print("instance " + str(instance_id) + ":", m_niche_num, " finished")
    gc.collect()


if __name__ == '__main__':
    img_dir = gen_dir()
    process_dir = img_dir + "/process"
    parameter_dir = img_dir + "/parameters"
    seeds = [x ** 2 for x in range(1, 51)]  # [1, 4, 9, 16, 25, 36, 49, 64, 81, 100,...]
    population = 300  # 5000
    niche_num = 1
    terminate_by_fitness_equal = False
    open_vrp = False
    target = MA.TargetEnum.TIME
    iter_time = 200  # 200
    penalty_coefficient = 100000
    need_correct_pickup_delivery = True
    dynamic_probability = True
    is_ga = False

    save_parameter_data(parameter_dir, seeds, population, iter_time)

    process_pool = Pool(8)

    """
        Begin instance=0,1 , IMA 1n ~ 10n , generate 2 graphs
    """
    if True:
        for _instance_id in range(1, 13):
            for _niche_num in range(1, 11):
                process_pool.apply_async(mp_run,
                                         args=(_instance_id, MA, seeds, population, iter_time, penalty_coefficient,
                                               terminate_by_fitness_equal, True,
                                               need_correct_pickup_delivery,
                                               False, dynamic_probability, _niche_num, is_ga, target,
                                               process_dir))

        # # instance 0, IMA 1n ~ 10n
        # for _niche_num in range(1, 11):
        #     process_pool.apply_async(mp_run, args=(1, MA, seeds, population, iter_time, penalty_coefficient,
        #                                            terminate_by_fitness_equal, True, need_correct_pickup_delivery,
        #                                            False, dynamic_probability, _niche_num, is_ga, target, process_dir))
        #
        # # instance 1, IMA 1n ~ 10n
        # for _niche_num in range(1, 11):
        #     process_pool.apply_async(mp_run, args=(2, MA, seeds, population, iter_time, penalty_coefficient,
        #                                            terminate_by_fitness_equal, True, need_correct_pickup_delivery,
        #                                            False, dynamic_probability, _niche_num, is_ga, target, process_dir))
        # """
        #     End instance=0,1 , IMA 1n ~ 10n , generate 2 graphs
        # """
        process_pool.close()
        process_pool.join()

    if False:  # Genetic Algorithm
        for _instance_id in range(1, 13):
            process_pool.apply_async(mp_run, args=(_instance_id, MA, seeds, population, iter_time, penalty_coefficient,
                                                   terminate_by_fitness_equal, True, need_correct_pickup_delivery,
                                                   False, False, 1, True, target, process_dir))
        process_pool.close()
        process_pool.join()

    if False:  # Memetic Algorithm (without dynamic probability and 1 niche)
        for _instance_id in range(1, 13):
            process_pool.apply_async(mp_run, args=(_instance_id, MA, seeds, population, iter_time, penalty_coefficient,
                                                   terminate_by_fitness_equal, True, need_correct_pickup_delivery,
                                                   False, False, 1, is_ga, target, process_dir))
        process_pool.close()
        process_pool.join()

    if False:  # SA
        for _instance_id in range(1, 13):
            target = SA.TargetEnum.TIME
            process_pool.apply_async(mp_run, args=(_instance_id, SA, seeds, population, iter_time, penalty_coefficient,
                                                   terminate_by_fitness_equal, False, need_correct_pickup_delivery,
                                                   False, False, 1, True, target, process_dir
                                                   ))
            # mp_run(_instance_id, SA, seeds, population, iter_time, penalty_coefficient, terminate_by_fitness_equal,
            #        False, need_correct_pickup_delivery, False, False, 1, True, target, process_dir)
        process_pool.close()
        process_pool.join()

    if False:  # TS
        for _instance_id in range(1, 13):
            target = TS.TargetEnum.TIME
            process_pool.apply_async(mp_run, args=(_instance_id, TS, seeds, population, iter_time, penalty_coefficient,
                                                   terminate_by_fitness_equal, False, need_correct_pickup_delivery,
                                                   False, False, 1, True, target, process_dir
                                                   ))
        process_pool.close()
        process_pool.join()

    print("Finished.")
