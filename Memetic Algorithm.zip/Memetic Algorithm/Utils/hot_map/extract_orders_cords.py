import time
import os
import json
from multiprocessing import Pool
import queue


def extract_json_file(dir_path, file_name, begin, end):
    with open(os.path.join(dir_path, file_name), 'r', encoding='UTF-8') as _j_file:
        _j_file_map = json.load(_j_file)
        # print(_j_file_map)
        _j_file.close()
    # print(_j_file_map[0])
    # {'id': '14637464697799'}, {'createTime': '1463746469'}, {'addrSrc': '飞哥土豆粉米线', 'lng': 121.62518379429832, 'lat': 38.91556296768863}, {'addrDst': '一佳客舍 兴工街35号楼601室', 'lng': 121.58097255131754, 'lat': 38.918650874736514}
    _cords_list = []  # 每个元素为2元
    for _record in _j_file_map:
        if int(_record[1]['createTime']) > begin and int(_record[1]['createTime']) < end:
            _cords_list.append((_record[3]['lng'] + 0.005, _record[3]['lat']))
    return _cords_list


if __name__ == '__main__':
    GEO_DIR = "../../SUMO_Simulation/gaodedata"
    time_begin = "2016-5-18 9:00:01"
    time_end = "2016-5-18 14:59:59"
    time_begin_stamp = time.strptime(time_begin, "%Y-%m-%d %H:%M:%S")
    time_end_stamp = time.strptime(time_end, "%Y-%m-%d %H:%M:%S")
    time_begin_stamp = int(time.mktime(time_begin_stamp))
    time_end_stamp = int(time.mktime(time_end_stamp))
    process_pool = Pool(6)
    q = queue.Queue()
    for _file in os.listdir(GEO_DIR):
        # print(os.path.join(GEO_DIR, _file))
        q.put(process_pool.apply_async(extract_json_file, args=(GEO_DIR, _file, time_begin_stamp, time_end_stamp)))
    process_pool.close()
    process_pool.join()

    cords_list = []
    while not q.empty():
        for _cords in q.get().get():
            cords_list.append(_cords)

    geo_features_list = []
    for _cords in cords_list:
        _cord_map = {
            "type": "Feature",
            "properties": {
                "count": 2
            },
            "geometry": {
                "type": "Point",
                "coordinates": [
                    _cords[0], _cords[1]
                ]
            }
        }
        geo_features_list.append(_cord_map)
    geo_map = {"type": "FeatureCollection", "features": geo_features_list}
    geo_file = open("geo.json", 'w')
    geo_map_data = json.dumps(geo_map, indent=2, ensure_ascii=False)
    geo_file.write(geo_map_data)
    geo_file.close()
