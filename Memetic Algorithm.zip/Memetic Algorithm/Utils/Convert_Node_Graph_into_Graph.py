import copy
from enum import Enum


class Converter:
    class _NodeEnum(Enum):
        SHOP = 1
        CLIENT = 2
        PACKAGE = 3
        DEPOT = 4

    def __init__(self, instance_id=0):
        self.speed = 1
        self.vehicle_num = -1
        self.nodes_pos = []
        self.nodes_time_windows = []
        self.vehicle_pos = []
        self.vehicle_time_windows = []
        self.binding_nodes_pos = []
        self.binding_nodes_time_windows = []
        self.pd = []
        self.binding = []
        self.depot = []
        self.change_instance(instance_id=instance_id)
        self.all_nodes_pos = self.vehicle_pos + self.nodes_pos + self.binding_nodes_pos
        self.all_nodes_pos_copy = copy.deepcopy(self.all_nodes_pos)
        self.all_nodes_pos = []
        for _i in range(len(self.all_nodes_pos_copy)):
            self.all_nodes_pos.append((self.all_nodes_pos_copy[_i][0] * 10, self.all_nodes_pos_copy[_i][1] * 10))

        self.all_time_windows = self.vehicle_time_windows + self.nodes_time_windows + self.binding_nodes_time_windows
        self.all_time_windows_copy = copy.deepcopy(self.all_time_windows)
        self.all_time_windows = []
        for _i in range(len(self.all_time_windows_copy)):
            self.all_time_windows.append(
                (self.all_time_windows_copy[_i][0] * 10, self.all_time_windows_copy[_i][1] * 10))

        # self.binding =[[],[],[],[],[]]

        self.demands = []  # 节点需求，奇数节点为1即需要取走，偶数节点为0即送达
        for _i in self.binding:
            self.demands.append(len(_i))
        for _i in range(len(self.nodes_pos)):
            if (_i + 1) % 2 == 1:
                self.demands.append(1)
            else:
                self.demands.append(-1)
        for _i in self.binding:
            for _j in _i:
                self.demands.append(-1)

        self.vehicle_capacities = 3  # 容量限制
        self.service_time = [0] * len(self.all_nodes_pos)  # 每个节点服务时间，包含depot节点，形如：[10,20,10,...]
        # 距离矩阵：所有节点（车辆+路径）间的欧几里得距离矩阵； 时间矩阵：所有节点（默认距离等于时间）再加上服务时间的矩阵
        self.distance_matrix, self.time_matrix = self.calc_matrix(self.all_nodes_pos, self.service_time)
        self.data = {"time_matrix": self.time_matrix, "distance_matrix": self.distance_matrix,
                     "pickups_deliveries": self.pd, "time_windows": self.all_time_windows, "demands": self.demands,
                     "vehicle_capacities": self.vehicle_capacities, "depot": self.depot, "binding": self.binding,
                     "num_vehicles": self.vehicle_num, "service_time": self.service_time, "nodes_attr_map": {},
                     "shop_nodes": [], "client_nodes": [], "package_nodes": []}
        # print('self.data["demands"]:',self.data["demands"])

    def __fix(self):

        if self.vehicle_num > 1:
            # 当num_vehicles>1，更新self._data["pickups_deliveries"]内节点和self._data["binding"]内节点的序号为当前序号+车辆数量-1
            for _i in range(len(self.data["pickups_deliveries"])):
                self.data["pickups_deliveries"][_i][0] += self.vehicle_num - 1
                self.data["pickups_deliveries"][_i][1] += self.vehicle_num - 1
            for _v in range(self.vehicle_num):
                for _j in range(len(self.data["binding"][_v])):
                    self.data["binding"][_v][_j] += self.vehicle_num - 1
        for _pickup_node, _delivery_node in self.pd:
            self.data["shop_nodes"].append(_pickup_node)
            self.data["client_nodes"].append(_delivery_node)
        for _vehicle_binding in self.binding:
            for _package in _vehicle_binding:
                self.data["package_nodes"].append(_package)
        for _node in self.data["shop_nodes"]:
            self.data["nodes_attr_map"][_node] = self._NodeEnum.SHOP
        for _node in self.data["client_nodes"]:
            self.data["nodes_attr_map"][_node] = self._NodeEnum.CLIENT
        for _node in self.data["package_nodes"]:
            self.data["nodes_attr_map"][_node] = self._NodeEnum.PACKAGE
        for _node in self.data["depot"]:
            self.data["nodes_attr_map"][_node] = self._NodeEnum.DEPOT

    def calc_matrix(self, pos_list: list[tuple], servece_time_list: list[int]):
        """
        给入节点坐标，给出距离矩阵和时间矩阵(加上服务时间)
        :param courier_num: 车辆数
        :param servece_time_list: 每个节点服务时间列表
        :param pos_list: 每个节点位置列表
        :return: _ret_time_matrix,_ret_distance_matrix
        """

        import math
        _ret_time_matrix = []
        _ret_distance_matrix = []

        for _i, _pos_a in enumerate(pos_list):
            _time_vec = []
            _distance_vec = []
            for _j, _pos_b in enumerate(pos_list):
                if _i == _j:
                    _distance_vec.append(0)
                    _time_vec.append(0)
                else:
                    _distance = math.sqrt((_pos_a[0] - _pos_b[0]) ** 2 + (_pos_a[1] - _pos_b[1]) ** 2)
                    _distance_vec.append(_distance)
                    _time_vec.append(_distance + servece_time_list[_j])
            _ret_time_matrix.append(_time_vec)
            _ret_distance_matrix.append(_distance_vec)
        return _ret_distance_matrix, _ret_time_matrix

    def _test(self):
        _distance_matrix, _time_matrix = self.calc_matrix(self.all_nodes_pos, self.service_time)
        print(self.data)

    @staticmethod
    def split_route_into_sub_routes(route_a, depots, open_vrp=True):
        """
        将长路径转换为子路径组成的列表
        :return:
        """
        _split_routes = []
        _split_index = 0
        _routes_len = len(route_a)
        for _i, _node in enumerate(route_a):
            # print("_split_index:",_split_index)
            if _i == 0:
                continue

            if _node in depots:
                _split_routes.append(route_a[_split_index:_i])
                if not open_vrp:
                    _split_routes[-1].append(route_a[_split_index])
                _split_index = _i
            if _i == (_routes_len - 1):
                _split_routes.append(route_a[_split_index:])
                if not open_vrp:
                    _split_routes[-1].append(route_a[_split_index])
                return _split_routes

    @staticmethod
    def _perfect_print(route_a, vehicle_num):
        """
        将route转换为depot为负值的route，仅用作打印
        :param route_a:
        :return:
        """
        _route_for_print = []
        for _i in range(len(route_a)):
            _route_for_print.append(route_a[_i] - vehicle_num + 1)
        return _route_for_print

    def calc_distance_of_route(self, route, open_vrp: bool):
        self.__fix()
        _split_routes = self.split_route_into_sub_routes(route, self.depot, open_vrp)
        _distance_cost = 0
        for _sub_route in _split_routes:
            _sub_distance_cost = 0
            _sub_route_len = len(_sub_route)
            if _sub_route_len == 2 and not open_vrp:
                continue
            elif _sub_route_len == 1 and open_vrp:
                continue
            _sub_distance_cost = 0
            for _idx in range(_sub_route_len - 1):
                if _sub_route[_idx] == _sub_route[_idx + 1]:
                    print("routes:", route)
                    print("_split_routes:", _split_routes)
                    print("_sub_route:", _sub_route)
                    raise Exception("error", "error")
                _sub_distance_cost += self.data["distance_matrix"][_sub_route[_idx]][_sub_route[_idx + 1]]
            _distance_cost += _sub_distance_cost
        print(_split_routes)
        print(_distance_cost)
        print(self._perfect_print(route, self.vehicle_num))

    def calc_time_of_route(self, route, open_vrp: bool):
        self.__fix()
        _split_routes = self.split_route_into_sub_routes(route, self.depot, open_vrp)
        _time_cost = 0
        for _sub_route in _split_routes:
            _sub_route_len = len(_sub_route)
            if _sub_route_len == 1:
                continue
            _sub_time_cost = 0
            _accumulate_time_cost = self.data["service_time"][_sub_route[0]]
            # print("sub_route\t_accumulate_time_cost:", _accumulate_time_cost)
            for _idx in range(_sub_route_len - 1):
                _accumulate_time_cost += self.data["distance_matrix"][_sub_route[_idx]][
                                             _sub_route[_idx + 1]] / self.speed + \
                                         self.data["service_time"][_sub_route[_idx + 1]]
                # print("\t\t\t_accumulate_time_cost:", _accumulate_time_cost)
                # print("_accumulate_time_cost:", _accumulate_time_cost)
                if self.data["nodes_attr_map"].get(_sub_route[_idx + 1], None) == self._NodeEnum.CLIENT or \
                        self.data["nodes_attr_map"].get(_sub_route[_idx + 1],
                                                        None) == self._NodeEnum.PACKAGE:
                    # print("in _accumulate_time_cost:", _accumulate_time_cost, "node:", _sub_route[_idx + 1])
                    _sub_time_cost += _accumulate_time_cost
            _time_cost += _sub_time_cost
        print(_split_routes)
        print(_time_cost)
        print(self._perfect_print(route, self.vehicle_num))

    def change_instance(self, instance_id):
        match instance_id:
            case 1:  # 5+35
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (17, 15),
                    (10, 11),
                    (16, 16),
                    (13, 20),
                    (17, 16),
                    (20, 17),
                    (18, 16),
                    (18, 8),
                    (19, 3),
                    (20, 8),
                    (18, 4),
                    (15, 1),
                    (2, 3),
                    (8, 2),
                    (2, 19),
                    (5, 6),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (6, 18),
                    (5, 14),
                    (20, 1),
                    (1, 1),
                    (20, 11),
                    (7, 7),
                    (15, 16),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                )
                self.binding = [[29, 30], [31], [32], [33],
                                [34, 35]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 2:  # 5+37
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (17, 15),
                    (10, 11),
                    (16, 16),
                    (13, 20),
                    (17, 16),
                    (20, 17),
                    (18, 16),
                    (18, 8),
                    (19, 3),
                    (20, 8),
                    (18, 4),
                    (15, 1),
                    (2, 3),
                    (8, 2),
                    (2, 19),
                    (5, 6),
                    (9, 5),
                    (13, 7),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (6, 18),
                    (5, 14),
                    (20, 1),
                    (1, 1),
                    (20, 11),
                    (7, 7),
                    (15, 16),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                    [29, 30],
                )
                self.binding = [[31, 32], [33], [34], [35],
                                [36, 37]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 3:  # 5+39
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (17, 15),
                    (10, 11),
                    (16, 16),
                    (13, 20),
                    (17, 16),
                    (20, 17),
                    (18, 16),
                    (18, 8),
                    (19, 3),
                    (20, 8),
                    (18, 4),
                    (15, 1),
                    (2, 3),
                    (8, 2),
                    (2, 19),
                    (5, 6),
                    (9, 5),
                    (13, 7),
                    (17, 9),
                    (15, 15),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (6, 18),
                    (5, 14),
                    (20, 1),
                    (1, 1),
                    (20, 11),
                    (7, 7),
                    (15, 16),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                    [29, 30],
                    [31, 32],
                )
                self.binding = [[33, 34], [35], [36], [37],
                                [38, 39]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 4:  # 5+41
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (17, 15),
                    (10, 11),
                    (16, 16),
                    (13, 20),
                    (17, 16),
                    (20, 17),
                    (18, 16),
                    (18, 8),
                    (19, 3),
                    (20, 8),
                    (18, 4),
                    (15, 1),
                    (2, 3),
                    (8, 2),
                    (2, 19),
                    (5, 6),
                    (9, 5),
                    (13, 7),
                    (17, 9),
                    (15, 15),
                    (13, 15),
                    (9, 20),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (6, 18),
                    (5, 14),
                    (20, 1),
                    (1, 1),
                    (20, 11),
                    (7, 7),
                    (15, 16),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                    [29, 30],
                    [31, 32],
                    [33,34],
                )
                self.binding = [[35, 36], [37], [38], [39],
                                [40, 41]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 5: # 5+43
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (17, 15),
                    (10, 11),
                    (16, 16),
                    (13, 20),
                    (17, 16),
                    (20, 17),
                    (18, 16),
                    (18, 8),
                    (19, 3),
                    (20, 8),
                    (18, 4),
                    (15, 1),
                    (2, 3),
                    (8, 2),
                    (2, 19),
                    (5, 6),
                    (9, 5),
                    (13, 7),
                    (17, 9),
                    (15, 15),
                    (13, 15),
                    (9, 20),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (6, 18),
                    (5, 14),
                    (20, 1),
                    (1, 1),
                    (20, 11),
                    (7, 7),
                    (15, 16),
                    (3, 20),
                    (3, 11),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                    [29, 30],
                    [31, 32],
                    [33, 34],
                )
                self.binding = [[35, 36], [37,38], [39,40], [41,42],
                                [43]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 6: # 5+45
                self.vehicle_num = 5
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (8, 7),
                    (3, 2),
                    (9, 5),
                    (2, 5),
                    (1, 3),
                    (3, 13),
                    (1, 10),
                    (1, 19),
                    (3, 14),
                    (8, 20),
                    (1, 20),
                    (12, 18),
                    (11, 12),
                    (15, 6),
                    (16, 6),
                    (12, 17),
                    (18, 2),
                    (18, 15),
                    (15, 16),
                    (11, 13),
                    (20, 7),
                    (15, 1),
                    (17, 9),
                    (11, 11),
                    (20, 16),
                    (19, 2),
                    (15, 2),
                    (9, 9),
                    (2, 16),
                    (5, 14),
                    (16, 11),
                    (20, 9),
                    (4, 12),
                    (13, 2),
                    (24, 21),
                    (6, 1),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 70),
                    (0, 70),
                    (0, 50),
                    (0, 50),
                    (0, 60),
                    (0, 60),
                    (0, 60),
                    (0, 60),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (4, 17),
                    (15, 5),
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 13),
                    (5, 15),
                    (17, 5),
                    (20, 8),
                    (6, 2),
                    (1, 2),
                    (17, 20),
                    (20, 17),
                    (11, 14),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 50),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19, 20],
                    [21, 22],
                    [23, 24],
                    [25, 26],
                    [27, 28],
                    [29, 30],
                    [31, 32],
                    [33, 34],
                    [35,36],
                )
                self.binding = [[37, 38], [39, 40], [41, 42], [43, 44],
                                [45]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2, 3, 4
                ]
            case 7: # 3+15
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                )
                self.binding = [[13], [14], [15]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
            case 8: # 3+17
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (18, 15),
                    (10, 11),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13,14],
                )
                self.binding = [[15], [16], [17]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
            case 9: # 3+19
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (18, 15),
                    (10, 11),
                    (9, 5),
                    (18, 1),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15,16],
                )
                self.binding = [[17], [18], [19]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
            case 10:    # 3+21
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (18, 15),
                    (10, 11),
                    (9, 5),
                    (18, 1),
                    (3, 9),
                    (6, 12),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17,18],
                )
                self.binding = [[19], [20], [21]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
            case 11:    # 3+23
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (18, 15),
                    (10, 11),
                    (9, 5),
                    (18, 1),
                    (3, 9),
                    (6, 12),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                    (10, 13),
                    (8, 4),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                )
                self.binding = [[19,20], [21], [22,23]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
            case 12:    # 3+25
                self.vehicle_num = 3
                self.nodes_pos = [  # 非车辆节点位置坐标
                    (9, 8),
                    (16, 8),
                    (8, 7),
                    (14, 3),
                    (8, 9),
                    (10, 15),
                    (8, 8),
                    (1, 8),
                    (7, 9),
                    (1, 15),
                    (7, 10),
                    (8, 20),
                    (18, 15),
                    (10, 11),
                    (9, 5),
                    (18, 1),
                    (3, 9),
                    (6, 12),
                    (16, 16),
                    (8, 11),
                ]
                self.nodes_time_windows = [  # 非车辆节点时间窗
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 30),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 30),
                    (0, 30),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                    (0, 50),
                ]
                self.vehicle_pos = [  # 车辆节点位置坐标
                    (11, 3),
                    (18, 18),
                    (10, 10),
                ]
                self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
                    (0, 5),
                    (0, 5),
                    (0, 5),
                ]
                self.binding_nodes_pos = [
                    (7, 7),
                    (15, 16),
                    (20, 1),
                    (10, 13),
                    (8, 4),
                ]
                self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                    (0, 40),
                ]
                self.pd = (  # 先取后送关系
                    [1, 2],
                    [3, 4],
                    [5, 6],
                    [7, 8],
                    [9, 10],
                    [11, 12],
                    [13, 14],
                    [15, 16],
                    [17, 18],
                    [19,20],
                )
                self.binding = [[21, 22], [23], [24, 25]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
                self.depot: list[int] = [  # 车辆节点索引，从0开始
                    0, 1, 2
                ]
        #
        #
        #
        #
        # if instance_id == 0:  # 28 order nodes, 7 binding nodes, 5 vehicles
        #     self.vehicle_num = 5  # 0,-1,-2
        #     self.nodes_pos = [  # 非车辆节点位置坐标
        #         (9, 8),
        #         (16, 8),
        #         (8, 7),
        #         (14, 3),
        #         (8, 9),
        #         (10, 15),
        #         (8, 8),
        #         (1, 8),
        #         (7, 9),
        #         (1, 15),
        #         (7, 10),
        #         (8, 20),
        #         (17, 15),
        #         (10, 11),
        #         (16, 16),
        #         (13, 20),
        #         (17, 16),
        #         (20, 17),
        #         (18, 16),
        #         (18, 8),
        #         (19, 3),
        #         (20, 8),
        #         (18, 4),
        #         (15, 1),
        #         (2, 3),
        #         (8, 2),
        #         (2, 19),
        #         (5, 6),
        #     ]
        #
        #     self.nodes_time_windows = [  # 非车辆节点时间窗
        #         (0, 30),
        #         (0, 30),
        #         (0, 30),
        #         (0, 30),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 30),
        #         (0, 30),
        #         (0, 50),
        #         (0, 50),
        #         (0, 40),
        #         (0, 40),
        #         (0, 50),
        #         (0, 50),
        #         (0, 60),
        #         (0, 60),
        #         (0, 40),
        #         (0, 40),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #     ]
        #
        #     self.vehicle_pos = [  # 车辆节点位置坐标
        #         (4, 17),
        #         (15, 5),
        #         (11, 3),
        #         (18, 18),
        #         (10, 10),
        #
        #     ]
        #     self.vehicle_time_windows = [  # 车辆节点时间窗，如果需要返回仓库，时间窗需要设置大一些
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #     ]
        #
        #     self.binding_nodes_pos = [
        #         (6, 18),
        #         (5, 14),
        #         (20, 1),
        #         (1, 1),
        #         (20, 11),
        #         (7, 7),
        #         (15, 16),
        #     ]
        #
        #     self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #
        #     ]
        #     self.pd = (  # 先取后送关系
        #         [1, 2],
        #         [3, 4],
        #         [5, 6],
        #         [7, 8],
        #         [9, 10],
        #         [11, 12],
        #         [13, 14],
        #         [15, 16],
        #         [17, 18],
        #         [19, 20],
        #         [21, 22],
        #         [23, 24],
        #         [25, 26],
        #         [27, 28],
        #     )
        #     self.binding = [[29, 30], [31], [32], [33],
        #                     [34, 35]]  # 包裹与车辆绑定情况，形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
        #     self.depot: list[int] = [  # 车辆节点索引，从0开始
        #         0, 1, 2, 3, 4
        #     ]
        # elif instance_id == 1:
        #     self.vehicle_num = 5
        #     self.nodes_pos = [
        #         (8, 7),
        #         (3, 2),
        #         (9, 5),
        #         (2, 5),
        #         (1, 3),
        #         (3, 13),
        #         (1, 10),
        #         (1, 19),
        #         (3, 14),
        #         (8, 20),
        #         (1, 20),
        #         (12, 18),
        #         (11, 12),
        #         (15, 6),
        #         (16, 6),
        #         (12, 17),
        #         (18, 2),
        #         (18, 15),
        #         (15, 16),
        #         (11, 13),
        #         (20, 7),
        #         (15, 1),
        #         (17, 9),
        #         (11, 11),
        #         (20, 16),
        #         (19, 2),
        #         (15, 2),
        #         (9, 9),
        #         (2, 16),
        #         (5, 14),
        #         (16, 11),
        #         (20, 9),
        #         (4, 12),
        #         (13, 2),
        #         (24, 21),
        #         (6, 1),
        #     ]
        #     self.nodes_time_windows = [
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 50),
        #         (0, 50),
        #         (0, 60),
        #         (0, 60),
        #         (0, 70),
        #         (0, 70),
        #         (0, 50),
        #         (0, 50),
        #         (0, 60),
        #         (0, 60),
        #         (0, 60),
        #         (0, 60),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #         (0, 50),
        #     ]
        #     self.vehicle_pos = [
        #         (4, 17),
        #         (15, 5),
        #         (11, 3),
        #         (18, 18),
        #         (10, 10),
        #     ]
        #     self.vehicle_time_windows = [
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #         (0, 100),
        #     ]
        #     self.binding_nodes_pos = [
        #         (7, 13),
        #         (5, 15),
        #         (17, 5),
        #         (20, 8),
        #         (6, 2),
        #         (1, 2),
        #         (17, 20),
        #         (20, 17),
        #         (11, 14),
        #     ]
        #     self.binding_nodes_time_windows = [  # 所有绑定到车辆的节点的时间窗
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #         (0, 40),
        #     ]
        #     self.pd = (
        #         [1, 2],
        #         [3, 4],
        #         [5, 6],
        #         [7, 8],
        #         [9, 10],
        #         [11, 12],
        #         [13, 14],
        #         [15, 16],
        #         [17, 18],
        #         [19, 20],
        #         [21, 22],
        #         [23, 24],
        #         [25, 26],
        #         [27, 28],
        #         [29, 30],
        #         [31, 32],
        #         [33, 34],
        #         [35, 36],
        #     )
        #     self.binding = [
        #         [37, 38], [39, 40], [41, 42], [43, 44], [45]
        #     ]
        #     self.depot: list[int] = [  # 车辆节点索引，从0开始
        #         0, 1, 2, 3, 4
        #     ]


if __name__ == '__main__':
    conv = Converter()
    # conv._test()
    conv.calc_distance_of_route(
        [
            0, 34, 13, 9, 33, 14, 10, 1, 7, 5, 8, 6, 27, 35, 23, 24, 28, 2, 29, 36, 25, 30, 26, 19, 20, 3, 38, 21, 37,
            17, 22, 18, 4, 31, 32, 11, 12, 15, 39, 16
        ],
        False)
    print()
    conv.calc_time_of_route(
        [

            0, 34, 13, 9, 33, 14, 10, 1, 7, 5, 8, 6, 27, 35, 23, 24, 28, 2, 29, 36, 25, 30, 26, 19, 20, 3, 38, 21, 37,
            17, 22, 18, 4, 31, 32, 11, 12, 15, 39, 16
        ],
        # [0, 31,11,12],
        False)
