import json
import os

import numpy
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt



# data_root_path = "../Img/2021_12_21_15_24/process/"   # 1000
# data_root_path ="../Img/2021_12_28_12_41/process/"    # 2000
# data_root_path ="../Img/2021_12_29_15_09/process/"    # 5000
# data_root_path ="../Img/2022_01_02_10_15/process/"    # 200
# data_root_path ="../Img/2022_01_02_14_35/process/"    # 500
# data_root_path = "../Img/2022_01_03_13_41/process/"  # 300

# data_root_path = "../Img/2022_01_15_17_15/process/"  # niche memetic population 300
data_root_path = "../Img/2023_08_10_21_43/process/"  # niche memetic population 500


# data_root_path = "../Img/2022_01_18_03_22/process/"  # niche memetic population 1000


def mkdir(path):
    path = path.strip()
    path = path.rstrip("\\")
    is_exists = os.path.exists(path)
    if not is_exists:
        os.makedirs(path)
        return True
    else:
        for _file_name in os.listdir(path):
            _file_path = os.path.join(path, _file_name)
            os.remove(_file_path)
        os.removedirs(path)
        os.makedirs(path)
        return False


def read_from_json(file_name):
    """

    :param file_name:
    :return:
    """
    with open(data_root_path + file_name, 'r', encoding='UTF-8') as _j_file:
        _j_file_map_1 = json.load(_j_file)
        _j_file.close()
    return _j_file_map_1


def read_from_dir_json(dia_path, file_name):
    """
    从指定的dir读取指定的文件名
    :param dia_path:
    :param file_name:
    :return:
    """
    with open(dia_path + file_name, 'r', encoding='UTF-8') as _j_file:
        _j_file_map_1 = json.load(_j_file)
        _j_file.close()
    return _j_file_map_1


def collect_data(key_name: str, map_data: dict):
    """
    给入需要收集的数据的关键字以及整个数据dict。返回
    :param key_name:
    :param map_data:
    :return:
    """

    pass


def write_to_excel(mat, img_path: str, out_put_name: str):
    with open(img_path + out_put_name, 'w', encoding='UTF-8') as excel_output:
        excel_output.write(',')
        for _i in range(1, 11):
            excel_output.write("niche:" + str(_i))
            excel_output.write(',')
        excel_output.write('\n')
        for _i in range(len(mat)):
            excel_output.write("instance:" + str(_i + 1))
            excel_output.write(',')
            for _j in range(len(mat[_i])):
                excel_output.write(str(mat[_i][_j]))
                excel_output.write(',')
            excel_output.write('\n')
        excel_output.close()


if __name__ == '__main__':
    TOP_HOW_MANY = 10
    img_root_path = data_root_path.replace("process", "img")  # 新建img目录
    mkdir(img_root_path)
    j_file_map: dict = read_from_json("instance-1_NMA-1.json")
    print(j_file_map.keys())
    # print(len(j_file_map["tw_penalty_count_matrix"]))  # 50个种子
    # print(j_file_map["tw_penalty_count_matrix"][0])  # 200次迭代

    if False:  # 验证用：每个不同的instance的不同niche数与不同seed的最大的 时间窗惩罚非零的迭代次数
        for _instance_id in range(1, 13):
            _max_tw_iter_time = 0  # 时间惩罚非零的最大迭代次数（即到第几次迭代，时间惩罚才为0）
            for _niche_num in range(1, 11):
                _j_file_name = "instance-" + str(_instance_id) + "_NMA-" + str(_niche_num) + ".json"
                _j_file_map = read_from_json(_j_file_name)
                for _seed_iters in _j_file_map[
                    "tw_penalty_count_matrix"]:  # 一共50个种子，即执行50轮种子的循环。该for程序检查每个种子循环的最大非零时间惩罚在第几次迭代
                    for _i, _tw_value in enumerate(_seed_iters):  # 遍历200次迭代中每一次的TW值，直到为零或此for结束
                        if _i == len(_seed_iters) - 1:
                            _max_tw_iter_time = len(_seed_iters) - 1
                            break
                        else:
                            if _tw_value == 0 and _i >= _max_tw_iter_time:
                                _max_tw_iter_time = _i
                                break
            _max_tw_iter_time += 1
            print("_max_tw_iter_time: ", _max_tw_iter_time)
        # print(_j_file_map["tw_penalty_count_matrix"][0], len(_j_file_map["tw_penalty_count_matrix"]))

    if False:  # 评估用：每个instance取各niche的前10佳平均，生成表格
        _max_tw_iter_time_3mat = []  # 三维列表，1维：instance_id，2维：每个niche，3维：每seed的最大TW惩罚非零iter。
        _last_fitness_value_3mat = []  # 三维列表，1维：instance_id，2维：每个niche，3维：每seed的收敛（最末一个）fitness值。
        for _instance_id in range(1, 13):
            _max_tw_iter_time_2mat = []  # 二维列表，高维：每个niche，低维：每seed的最大TW惩罚非零iter。
            _last_fitness_value_2mat = []  # 二维列表，高维：每个niche，低维：每seed的收敛（最末一个）fitness值。
            for _niche_num in range(1, 11):
                _max_tw_iter_time_vec = []  # 元素：每seed的最大TW惩罚非零iter。
                _last_fitness_value_vec = []  # 元素：每seed的收敛（最末一个）fitness值。
                _j_file_name = "instance-" + str(_instance_id) + "_NMA-" + str(_niche_num) + ".json"
                _j_file_map = read_from_json(_j_file_name)
                for _seed_iters in _j_file_map["tw_penalty_count_matrix"]:
                    _max_tw_iter_time = 0
                    for _i, _tw_value in enumerate(_seed_iters):
                        if _i == len(_seed_iters) - 1:
                            _max_tw_iter_time = len(_seed_iters)
                            break
                        else:
                            if _tw_value == 0 and _i >= _max_tw_iter_time:
                                _max_tw_iter_time = _i
                                break
                    _max_tw_iter_time_vec.append(_max_tw_iter_time + 1)
                for _seed_iters in _j_file_map["fitness_value_matrix"]:
                    _last_fitness_value_vec.append(_seed_iters[-1])
                _max_tw_iter_time_2mat.append(_max_tw_iter_time_vec)
                _last_fitness_value_2mat.append(_last_fitness_value_vec)
            _max_tw_iter_time_3mat.append(_max_tw_iter_time_2mat)
            _last_fitness_value_3mat.append(_last_fitness_value_2mat)
        # print("_max_tw_iter_time_3mat: ", _max_tw_iter_time_3mat)
        # print("_last_fitness_value_3mat: ", _last_fitness_value_3mat)

        _evaluation_top10_avg_max_tw_iter_time_2mat = []
        _evaluation_total_avg_max_tw_iter_time_2mat = []
        for _instance_id_dimension in _max_tw_iter_time_3mat:
            _evaluation_top10_avg_max_tw_iter_time_vec = []
            _evaluation_total_avg_max_tw_iter_time_vec = []
            for _niche_num_dimension in _instance_id_dimension:  # 包含50个seed的每个seed的_max_tw_iter_time
                _top10_max_tw_iter_avg = sum(sorted(_niche_num_dimension)[:TOP_HOW_MANY]) / TOP_HOW_MANY
                _total_max_tw_iter_avg = sum(_niche_num_dimension) / len(_niche_num_dimension)
                _evaluation_top10_avg_max_tw_iter_time_vec.append(_top10_max_tw_iter_avg)
                _evaluation_total_avg_max_tw_iter_time_vec.append(_total_max_tw_iter_avg)
            _evaluation_top10_avg_max_tw_iter_time_2mat.append(_evaluation_top10_avg_max_tw_iter_time_vec)
            _evaluation_total_avg_max_tw_iter_time_2mat.append(_evaluation_total_avg_max_tw_iter_time_vec)
        print("_evaluation_top10_avg_max_tw_iter_time_2mat: ", _evaluation_top10_avg_max_tw_iter_time_2mat)
        print()
        print("_evaluation_total_avg_max_tw_iter_time_2mat: ", _evaluation_total_avg_max_tw_iter_time_2mat)
        print()

        _evaluation_top10_avg_last_fitness_value_2mat = []
        _evaluation_total_avg_last_fitness_value_2mat = []
        for _instance_id_dimension in _last_fitness_value_3mat:
            _evaluation_top10_avg_last_fitness_value_vec = []
            _evaluation_total_avg_last_fitness_value_vec = []
            for _niche_num_dimension in _instance_id_dimension:  # 包含50个seed的每个seed的_last_fitness_value
                _top10_last_fitness_value_avg = sum(
                    sorted(_niche_num_dimension, reverse=True)[:TOP_HOW_MANY]) / TOP_HOW_MANY
                _total_last_fitness_value_avg = sum(_niche_num_dimension) / len(_niche_num_dimension)
                _evaluation_top10_avg_last_fitness_value_vec.append(_top10_last_fitness_value_avg)
                _evaluation_total_avg_last_fitness_value_vec.append(_total_last_fitness_value_avg)
            _evaluation_top10_avg_last_fitness_value_2mat.append(_evaluation_top10_avg_last_fitness_value_vec)
            _evaluation_total_avg_last_fitness_value_2mat.append(_evaluation_total_avg_last_fitness_value_vec)
        print("_evaluation_top10_avg_last_fitness_value_2mat: ", _evaluation_top10_avg_last_fitness_value_2mat)
        print()
        print("_evaluation_total_avg_last_fitness_value_2mat: ", _evaluation_total_avg_last_fitness_value_2mat)

        write_to_excel(_evaluation_top10_avg_max_tw_iter_time_2mat, img_root_path, "top10_max_tw.csv")
        write_to_excel(_evaluation_top10_avg_last_fitness_value_2mat, img_root_path, "top10_fitness.csv")
        write_to_excel(_evaluation_total_avg_max_tw_iter_time_2mat, img_root_path, "all_max_tw.csv")
        write_to_excel(_evaluation_total_avg_last_fitness_value_2mat, img_root_path, "all_fitness.csv")

    if False:  # 对比 with and without adaptive parameter. Use population size = 500, niche number = 3.
        # 柱状图对比图
        TOP_HOW_MANY = 10
        _niche_num = '3'
        _nmaap_n_max_tw_iter_time_2mat = []  # 2维列表，1维：instance_id，2维：每seed的最大TW惩罚非零iter。
        _nma_without_ap_n_max_tw_iter_time_2mat = []
        _nmaap_n_last_fitness_value_2mat = []  # 2维列表，1维：instance_id，2维：每seed的收敛（最末一个）fitness值。
        _nma_without_ap_n_last_fitness_value_2mat = []
        _nmaap_n_dir = "../Img/2022_01_16_13_04/process/"  # 注意，目录里不止有niche number = 3的
        _nma_without_ap_n_dir = "../Img/2022_02_08_14_07/process/"  # 注意，这里只有niche number = 3
        for _instance_id in range(1, 13):
            _nmaap_n_max_tw_iter_time_vec = []  # 元素：每seed的最大TW惩罚非零iter。
            _nma_without_ap_n_max_tw_iter_time_vec = []  # 元素：每seed的最大TW惩罚非零iter。
            _nmaap_n_last_fitness_value_vec = []  # 元素：每seed的收敛（最末一个）fitness值。
            _nma_without_ap_n_last_fitness_value_vec = []  # 元素：每seed的收敛（最末一个）fitness值。
            _nmaap_n_file_name = "instance-" + str(_instance_id) + "_NMA-" + _niche_num + ".json"
            _nma_without_ap_n_file_name = "instance-" + str(_instance_id) + "_NMA-" + _niche_num + ".json"
            _nmaap_n_file_data: dict = read_from_dir_json(_nmaap_n_dir, _nmaap_n_file_name)
            _nma_without_ap_n_file_data: dict = read_from_dir_json(_nma_without_ap_n_dir, _nma_without_ap_n_file_name)

            for _seed_iters in _nmaap_n_file_data["tw_penalty_count_matrix"]:
                _max_tw_iter_time = 0
                for _i, _tw_value in enumerate(_seed_iters):
                    if _i == len(_seed_iters) - 1:
                        _max_tw_iter_time = len(_seed_iters)
                        break
                    else:
                        if _tw_value == 0 and _i >= _max_tw_iter_time:
                            _max_tw_iter_time = _i
                            break
                _nmaap_n_max_tw_iter_time_vec.append(_max_tw_iter_time + 1)
            for _seed_iters in _nmaap_n_file_data["fitness_value_matrix"]:
                _nmaap_n_last_fitness_value_vec.append(_seed_iters[-1])
            _nmaap_n_max_tw_iter_time_2mat.append(_nmaap_n_max_tw_iter_time_vec)
            _nmaap_n_last_fitness_value_2mat.append(_nmaap_n_last_fitness_value_vec)

            for _seed_iters in _nma_without_ap_n_file_data["tw_penalty_count_matrix"]:
                _max_tw_iter_time = 0
                for _i, _tw_value in enumerate(_seed_iters):
                    if _i == len(_seed_iters) - 1:
                        _max_tw_iter_time = len(_seed_iters)
                        break
                    else:
                        if _tw_value == 0 and _i >= _max_tw_iter_time:
                            _max_tw_iter_time = _i
                            break
                _nma_without_ap_n_max_tw_iter_time_vec.append(_max_tw_iter_time + 1)
            for _seed_iters in _nma_without_ap_n_file_data["fitness_value_matrix"]:
                _nma_without_ap_n_last_fitness_value_vec.append(_seed_iters[-1])
            _nma_without_ap_n_max_tw_iter_time_2mat.append(_nma_without_ap_n_max_tw_iter_time_vec)
            _nma_without_ap_n_last_fitness_value_2mat.append(_nma_without_ap_n_last_fitness_value_vec)

        _evaluation_top10_avg_nmaap_n_max_tw_iter_time_vec = []
        _evaluation_top10_std_nmaap_n_max_tw_iter_time_vec = []
        _evaluation_top10_avg_nma_without_ap_n_max_tw_iter_time_vec = []
        _evaluation_top10_std_nma_without_ap_n_max_tw_iter_time_vec = []
        _evaluation_top10_avg_nmaap_n_last_fitness_value_vec = []
        _evaluation_top10_std_nmaap_n_last_fitness_value_vec = []
        _evaluation_top10_avg_nma_without_ap_n_last_fitness_value_vec = []
        _evaluation_top10_std_nma_without_ap_n_last_fitness_value_vec = []

        for _instance_id_dimension in _nmaap_n_max_tw_iter_time_2mat:
            _top10_max_tw_iter_avg = sum(sorted(_instance_id_dimension)[:TOP_HOW_MANY]) / TOP_HOW_MANY
            _top10_max_tw_iter_std = numpy.std(sorted(_instance_id_dimension)[:TOP_HOW_MANY])
            _evaluation_top10_avg_nmaap_n_max_tw_iter_time_vec.append(_top10_max_tw_iter_avg)
            _evaluation_top10_std_nmaap_n_max_tw_iter_time_vec.append(_top10_max_tw_iter_std)
        print("_evaluation_top10_avg_nmaap_n_max_tw_iter_time_vec:\t\t",
              _evaluation_top10_avg_nmaap_n_max_tw_iter_time_vec)

        for _instance_id_dimension in _nma_without_ap_n_max_tw_iter_time_2mat:
            _top10_max_tw_iter_avg = sum(sorted(_instance_id_dimension)[:TOP_HOW_MANY]) / TOP_HOW_MANY
            _top10_max_tw_iter_std = numpy.std(sorted(_instance_id_dimension)[:TOP_HOW_MANY])
            _evaluation_top10_avg_nma_without_ap_n_max_tw_iter_time_vec.append(_top10_max_tw_iter_avg)
            _evaluation_top10_std_nma_without_ap_n_max_tw_iter_time_vec.append(_top10_max_tw_iter_std)
        print("_evaluation_top10_avg_nma_without_ap_n_max_tw_iter_time_vec:\t\t",
              _evaluation_top10_avg_nma_without_ap_n_max_tw_iter_time_vec)

        for _instance_id_dimension in _nmaap_n_last_fitness_value_2mat:
            _top10_last_fitness_value_avg = sum(
                sorted(_instance_id_dimension, reverse=True)[:TOP_HOW_MANY]) / TOP_HOW_MANY
            _top10_last_fitness_value_std = numpy.std(sorted(_instance_id_dimension, reverse=True)[:TOP_HOW_MANY])
            _evaluation_top10_avg_nmaap_n_last_fitness_value_vec.append(_top10_last_fitness_value_avg)
            _evaluation_top10_std_nmaap_n_last_fitness_value_vec.append(_top10_last_fitness_value_std)
        print("_evaluation_top10_avg_nmaap_n_last_fitness_value_vec:\t\t",
              _evaluation_top10_avg_nmaap_n_last_fitness_value_vec)

        for _instance_id_dimension in _nma_without_ap_n_last_fitness_value_2mat:
            _top10_last_fitness_value_avg = sum(
                sorted(_instance_id_dimension)[:TOP_HOW_MANY]) / TOP_HOW_MANY
            _top10_last_fitness_value_std = numpy.std(sorted(_instance_id_dimension)[:TOP_HOW_MANY])
            _evaluation_top10_avg_nma_without_ap_n_last_fitness_value_vec.append(_top10_last_fitness_value_avg)
            _evaluation_top10_std_nma_without_ap_n_last_fitness_value_vec.append(_top10_last_fitness_value_std)
        print("_evaluation_top10_avg_nma_without_ap_n_last_fitness_value_vec:\t\t",
              _evaluation_top10_avg_nma_without_ap_n_last_fitness_value_vec)

        _instance_id_as_x_label = []
        for _instance_id in range(1, 13):
            if _instance_id < 10:
                _instance_id_as_x_label.append('0' + str(_instance_id))
            else:
                _instance_id_as_x_label.append(str(_instance_id))
        # fig. a
        # 配色参考：https://blog.csdn.net/slandarer/article/details/114157177
        _xa = np.arange(len(_instance_id_as_x_label)) * 0.5  # the label locations
        _width = 0.2  # the width of the bars
        _figa, _axa = plt.subplots(dpi=1200)  # figsize=(16,10)
        _rectsa1 = _axa.bar(_xa - _width / 2, _evaluation_top10_avg_nmaap_n_max_tw_iter_time_vec, _width, bottom=0,
                            yerr=_evaluation_top10_std_nmaap_n_max_tw_iter_time_vec,
                            label='With adaptive parameters', color='#8ECFC9')
        _rectsa2 = _axa.bar(_xa + _width / 2, _evaluation_top10_avg_nma_without_ap_n_max_tw_iter_time_vec, _width,
                            bottom=0, yerr=_evaluation_top10_std_nma_without_ap_n_max_tw_iter_time_vec,
                            label='Without adaptive parameters', color='#FFBE7A')
        # Add some text for labels, title and custom x-axis tick labels, etc.
        # _axa.set_ylabel('Average number of 1st iterations without\nbreaching the main constraint')
        _axa.set_ylabel('Convergence rate')
        _axa.set_xticks(_xa, labels=_instance_id_as_x_label)
        _axa.set_xlabel('Instance id')
        _axa.legend()
        _axa.autoscale_view()
        # _axa.grid(color="white")
        _figa.tight_layout()
        plt.savefig("../Img/ExpImgs/Fig_08.png",
                    dpi=1200, bbox_inches='tight')
        plt.show()
        # fig. b
        _xb = np.arange(len(_instance_id_as_x_label)) * 0.5  # the label locations
        _width = 0.2  # the width of the bars
        _figb, _axb = plt.subplots(dpi=1200)  # figsize=(16,10)
        print("_evaluation_top10_std_nmaap_n_last_fitness_value_vec:",
              _evaluation_top10_std_nmaap_n_last_fitness_value_vec)
        print("_evaluation_top10_std_nma_without_ap_n_last_fitness_value_vec:",
              _evaluation_top10_std_nma_without_ap_n_last_fitness_value_vec)
        _rectsb1 = _axb.bar(_xb - _width / 2, _evaluation_top10_avg_nmaap_n_last_fitness_value_vec, _width, bottom=0,
                            yerr=_evaluation_top10_std_nmaap_n_last_fitness_value_vec,
                            label='With adaptive parameters', color='#8ECFC9')
        _rectsb2 = _axb.bar(_xb + _width / 2, _evaluation_top10_avg_nma_without_ap_n_last_fitness_value_vec, _width,
                            bottom=0, yerr=_evaluation_top10_std_nma_without_ap_n_last_fitness_value_vec,
                            label='Without adaptive parameters', color='#FFBE7A')
        # Add some text for labels, title and custom x-axis tick labels, etc.
        # _axb.set_ylabel('Average fitness value of the last iteration')
        _axb.set_ylabel('Convergence ability')
        _axb.set_xticks(_xb, labels=_instance_id_as_x_label)
        _axb.set_xlabel('Instance id')
        _axb.legend()
        _axb.autoscale_view()
        # _axb.grid(color="white")
        _figb.tight_layout()
        plt.savefig("../Img/ExpImgs/Fig_09.png",
                    dpi=1200, bbox_inches='tight')
        plt.show()

    if False:  # 对比 nmaap-3、ga、ma、sa、ts 并生成表格. Use population size = 500, niche number = 3.
        _niche_num = '3'
        _nmaap_n_dir = "../Img/2022_01_16_13_04/process/"  # 注意，目录里不止有niche number = 3的
        _ga_dir = "../Img/2022_01_26_22_25/process/"  # GA
        _ma_dir = "../Img/2022_01_27_11_01/process/"  # MA
        _sa_dir = "../Img/2022_02_07_22_25/process/"  # SA
        _ts_dir = "../Img/2022_02_07_22_33/process/"  # TS
        _all_algorithms_list = [_ga_dir, _ma_dir, _sa_dir, _ts_dir, _nmaap_n_dir]  # 顺序：ga、ma、sa、ts、nmaap-6
        _max_tw_iter_time_3mat = []  # 三维列表，1维：instance_id，2维：每个algorithm，3维：每seed的最大TW惩罚非零iter。
        _last_fitness_value_3mat = []  # 三维列表，1维：instance_id，2维：每个algorithm，3维：每seed的收敛（最末一个）fitness值。
        for _instance_id in range(1, 13):
            _max_tw_iter_time_2mat = []  # 二维列表，高维：每个algorithm，低维：每seed的最大TW惩罚非零iter。
            _last_fitness_value_2mat = []  # 二维列表，高维：每个algorithm，低维：每seed的收敛（最末一个）fitness值。
            for _algorithm in _all_algorithms_list:
                _max_tw_iter_time_vec = []  # 元素：每seed的最大TW惩罚非零iter。
                _last_fitness_value_vec = []  # 元素：每seed的收敛（最末一个）fitness值。
                if _algorithm == _nmaap_n_dir:
                    _j_file_name = "instance-" + str(_instance_id) + "_NMA-" + _niche_num + ".json"
                else:
                    _j_file_name = "instance-" + str(_instance_id) + "_NMA-1.json"
                _j_file_map: dict = read_from_dir_json(_algorithm, _j_file_name)
                # print(_j_file_map.keys())
                for _seed_iters in _j_file_map["tw_penalty_count_matrix"]:
                    _max_tw_iter_time = 0
                    for _i, _tw_value in enumerate(_seed_iters):
                        if _i == len(_seed_iters) - 1:
                            _max_tw_iter_time = len(_seed_iters)
                            break
                        else:
                            if _tw_value == 0 and _i >= _max_tw_iter_time:
                                _max_tw_iter_time = _i
                                break
                    _max_tw_iter_time_vec.append(_max_tw_iter_time + 1)
                # print(_algorithm,_j_file_map["fitness_value_matrix"])
                for _seed_iters in _j_file_map["fitness_value_matrix"]:
                    _last_fitness_value_vec.append(_seed_iters[-1])
                _max_tw_iter_time_2mat.append(_max_tw_iter_time_vec)
                _last_fitness_value_2mat.append(_last_fitness_value_vec)
            _max_tw_iter_time_3mat.append(_max_tw_iter_time_2mat)
            _last_fitness_value_3mat.append(_last_fitness_value_2mat)

        _evaluation_top10_avg_max_tw_iter_time_2mat = []
        for _instance_id_dimension in _max_tw_iter_time_3mat:
            _evaluation_top10_avg_max_tw_iter_time_vec = []
            for _algorithm_dimension in _instance_id_dimension:  # 包含50个seed的每个seed的_max_tw_iter_time
                _top10_max_tw_iter_avg = sum(sorted(_algorithm_dimension)[:TOP_HOW_MANY]) / TOP_HOW_MANY
                _evaluation_top10_avg_max_tw_iter_time_vec.append(_top10_max_tw_iter_avg)
            _evaluation_top10_avg_max_tw_iter_time_2mat.append(_evaluation_top10_avg_max_tw_iter_time_vec)

        _evaluation_top10_avg_last_fitness_value_2mat = []
        for _instance_id_dimension in _last_fitness_value_3mat:
            _evaluation_top10_avg_last_fitness_value_vec = []
            for _algorithm_dimension in _instance_id_dimension:  # 包含50个seed的每个seed的_last_fitness_value
                _top10_last_fitness_value_avg = sum(
                    sorted(_algorithm_dimension, reverse=True)[:TOP_HOW_MANY]) / TOP_HOW_MANY
                _evaluation_top10_avg_last_fitness_value_vec.append(_top10_last_fitness_value_avg)
            _evaluation_top10_avg_last_fitness_value_2mat.append(_evaluation_top10_avg_last_fitness_value_vec)

        write_to_excel(_evaluation_top10_avg_max_tw_iter_time_2mat, img_root_path, "top10_max_tw_with_baselines.csv")
        write_to_excel(_evaluation_top10_avg_last_fitness_value_2mat, img_root_path, "top10_fitness_with_baselines.csv")

    if True:  # 对比 nmaap-3、ga、ma、sa、ts 并曲线图（使用instance - 3）. Use population size = 500, niche number = 3.
        # 参考：https://blog.csdn.net/bq_cui/article/details/91309520 误差曲线图
        # 参考：https://stackoverflow.com/questions/12957582/plot-yerr-xerr-as-shaded-region-rather-than-error-bars 误差曲线图
        plt.rcParams['axes.facecolor'] = '#eaeaf2'
        # print(plt.rcParams.keys())
        plt.rcParams['xtick.bottom'] = False
        plt.rcParams['ytick.left'] = False

        plt.rcParams['axes.edgecolor'] = 'white'

        _which_instance_to_use = '6'
        _niche_num = '3'
        _nmaap_n_dir = "../Img/2022_01_16_13_04/process/"  # 注意，目录里不止有niche number = 6的
        _ga_dir = "../Img/2022_01_26_22_25/process/"  # GA
        _ma_dir = "../Img/2022_01_27_11_01/process/"  # MA
        _sa_dir = "../Img/2022_02_07_22_25/process/"  # SA
        _ts_dir = "../Img/2022_02_07_22_33/process/"  # TS
        _all_algorithms_list = [_ga_dir, _ma_dir, _sa_dir, _ts_dir, _nmaap_n_dir]  # 顺序：ga、ma、sa、ts、nmaap-3
        _top10_fitness_avg_mat = []  # 2维：1.每个algorithm，2.每个iteration的均值 （取last_fitness_value最好的top10）
        _top10_fitness_std_mat = []
        for _algorithm in _all_algorithms_list:
            if _algorithm == _nmaap_n_dir:
                _j_file_name = "instance-" + _which_instance_to_use + "_NMA-" + _niche_num + ".json"
            else:
                _j_file_name = "instance-" + _which_instance_to_use + "_NMA-1.json"
            _j_file_map: dict = read_from_dir_json(_algorithm, _j_file_name)
            _top10_seeds = []  # 先选出last_fitness_value最好的top10的seeds
            _top10_seeds_map = {}  # key: last_fitness_value, value: index
            for _i, _seed_iters in enumerate(_j_file_map["fitness_value_matrix"]):  # fitness_value_matrix
                _top10_seeds_map[_seed_iters[-1]] = _i
            _top10_last_values = sorted(_top10_seeds_map.keys(), reverse=True)[:TOP_HOW_MANY]
            for _top_last_value in _top10_last_values:
                _top10_seeds.append(_top10_seeds_map[_top_last_value])
            _this_algorithm_top10_seeds_iterations_mat = []  # 2维：记录该algorithm的top10的seeds的每轮iter的fitness_value
            _this_algorithm_top10_seeds_iterations_avg_vec = []  # 1维：记录该algorithm的top10的seeds的每轮iter的fitness_value的平均值
            _this_algorithm_top10_seeds_iterations_std_vec = []  # 1维：记录该algorithm的top10的seeds的每轮iter的fitness_value的std

            for _i, _seed_iters in enumerate(_j_file_map["fitness_value_matrix"]):  # fitness_value_matrix
                if _i in _top10_seeds:
                    _this_algorithm_top10_seeds_iterations_mat.append(_seed_iters)
            for _j in range(len(_this_algorithm_top10_seeds_iterations_mat[0])):
                _list_of_this_iteration = []
                for _i in range(len(_this_algorithm_top10_seeds_iterations_mat)):
                    _list_of_this_iteration.append(_this_algorithm_top10_seeds_iterations_mat[_i][_j])
                _list_of_this_iteration_np = numpy.array(_list_of_this_iteration)
                _this_algorithm_top10_seeds_iterations_avg_vec.append(numpy.average(_list_of_this_iteration_np))
                _this_algorithm_top10_seeds_iterations_std_vec.append(numpy.std(_list_of_this_iteration_np))
            _top10_fitness_avg_mat.append(_this_algorithm_top10_seeds_iterations_avg_vec)
            _top10_fitness_std_mat.append(_this_algorithm_top10_seeds_iterations_std_vec)
        _algorithm_names = ["GA", "MA", "SA", "TS", "NMAAP(Ours)"]
        _std_factor = 0.5
        # _ga_y_avg = numpy.log10(numpy.array(_top10_fitness_avg_mat[0]))
        # _ma_y_avg = numpy.log10(numpy.array(_top10_fitness_avg_mat[1]))
        # _sa_y_avg = numpy.log10(numpy.array(_top10_fitness_avg_mat[2]))
        # _ts_y_avg = numpy.log10(numpy.array(_top10_fitness_avg_mat[3]))
        # _nmaap_y_avg = numpy.log10(numpy.array(_top10_fitness_avg_mat[4]))

        _ga_y_avg = numpy.array(_top10_fitness_avg_mat[0])
        _ma_y_avg = numpy.array(_top10_fitness_avg_mat[1])
        _sa_y_avg = numpy.array(_top10_fitness_avg_mat[2])
        _ts_y_avg = numpy.array(_top10_fitness_avg_mat[3])
        _nmaap_y_avg = numpy.array(_top10_fitness_avg_mat[4])

        _ga_y_std = numpy.array(_top10_fitness_std_mat[0])
        _ga_y_avg_up = _ga_y_avg + _std_factor * _ga_y_std
        _ga_y_avg_down = _ga_y_avg - _std_factor * _ga_y_std
        _ma_y_std = numpy.array(_top10_fitness_std_mat[1])
        _ma_y_avg_up = _ma_y_avg + _std_factor * _ma_y_std
        _ma_y_avg_down = _ma_y_avg - _std_factor * _ma_y_std
        _sa_y_std = numpy.array(_top10_fitness_std_mat[2])
        _sa_y_avg_up = _sa_y_avg + _std_factor * _sa_y_std
        _sa_y_avg_down = _sa_y_avg - _std_factor * _sa_y_std
        _ts_y_std = numpy.array(_top10_fitness_std_mat[3])
        _ts_y_avg_up = _ts_y_avg + _std_factor * _ts_y_std
        _ts_y_avg_down = _ts_y_avg - _std_factor * _ts_y_std
        _nmaap_y_std = numpy.array(_top10_fitness_std_mat[4])
        _nmaap_y_avg_up = _nmaap_y_avg + _std_factor * _nmaap_y_std
        _nmaap_y_avg_down = _nmaap_y_avg - _std_factor * _nmaap_y_std
        _x_axis = np.arange(len(_ga_y_avg))
        _figc, _axc = plt.subplots(dpi=1200)
        _axc.plot(_x_axis, _ga_y_avg, label="GA", color="#8ECFC9")
        _axc.plot(_x_axis, _ma_y_avg, label="MA", color="#FFBE7A")
        _axc.plot(_x_axis, _sa_y_avg, label="SA", color="#FA7F6F")
        _axc.plot(_x_axis, _ts_y_avg, label="TS", color="#82B0D2")
        _axc.plot(_x_axis, _nmaap_y_avg, label="NMAAP (Ours)", color="#8E8BFE")  # BEB8DC
        _axc.fill_between(_x_axis, _ga_y_avg_up, _ga_y_avg_down, alpha=0.2, facecolor="#8ECFC9")
        _axc.fill_between(_x_axis, _ma_y_avg_up, _ma_y_avg_down, alpha=0.2, facecolor="#FFBE7A")
        _axc.fill_between(_x_axis, _sa_y_avg_up, _sa_y_avg_down, alpha=0.2, facecolor="#FA7F6F")
        _axc.fill_between(_x_axis, _ts_y_avg_up, _ts_y_avg_down, alpha=0.2, facecolor="#82B0D2")
        _axc.fill_between(_x_axis, _nmaap_y_avg_up, _nmaap_y_avg_down, alpha=0.2, facecolor="#8E8BFE")
        _axc.set_ylabel('Fitness value')
        _axc.set_xlabel('Iteration number')
        _axc.grid(color="white")
        _axc.legend()
        _axc.autoscale_view()
        _figc.tight_layout()
        plt.savefig("../Img/ExpImgs/Fig_10.png",
                    dpi=1200, bbox_inches='tight')
        plt.show()

    if False:
        _time_window = 20 * 60
        _warm_up_time = 30 * 60
        _simulation_results_dir = "../Img/simulation_result/"
        _algorithm_names = ["GA", "MA", "SA", "TS", "NMA"]
        _time_cost_3mat = []  # 3维，1维：algorithm, 2维：seed, 3维：time cost
        _exceed_time_3mat = []  # 3维，1维：algorithm, 2维：seed, 3维：超时的time cost
        _total_order_counter = 0
        _warm_up_order_counter = 0
        _total_compare_order_counter = 0
        _have_counted = False
        for _algorithm_name in _algorithm_names:
            _time_cost_all_seed_2mat = []  # 2维，1维：seed, 2维：time cost
            _exceed_time_all_seed_2mat = []  # 2维，1维：seed, 2维：超时的time cost
            for _seed_num in range(1, 6):
                _time_cost_per_seed_vec = []  # 1维：time cost
                _exceed_time_per_seed_vec = []  # 1维：超时的time cost
                _orders_data_file = _algorithm_name + "_orders_data_" + str(_seed_num) + ".json"
                _orders_data_map: dict = read_from_dir_json(_simulation_results_dir,
                                                            _orders_data_file)  # key: timepoint, value: time cost
                if not _have_counted:
                    _have_counted = True
                    for _time_point in _orders_data_map.keys():
                        _total_order_counter += 1
                        if int(_time_point) <= _warm_up_time:
                            _warm_up_order_counter += 1
                        else:
                            _total_compare_order_counter += 1
                    print("_total_order_counter:", _total_order_counter)
                    print("_warm_up_order_counter:", _warm_up_order_counter)
                    print("_total_compare_order_counter:", _total_compare_order_counter)

                for _time_point in _orders_data_map.keys():
                    if int(_time_point) <= _warm_up_time:
                        continue
                    else:
                        _time_cost_per_seed_vec.append(_orders_data_map[_time_point])
                        if _orders_data_map[_time_point] > _time_window:
                            _exceed_time_per_seed_vec.append(_orders_data_map[_time_point])
                _time_cost_all_seed_2mat.append(_time_cost_per_seed_vec)
                _exceed_time_all_seed_2mat.append(_exceed_time_per_seed_vec)
            _time_cost_3mat.append(_time_cost_all_seed_2mat)
            _exceed_time_3mat.append(_exceed_time_all_seed_2mat)

        _avg_wait_time_vec = []  # 每种算法的平均顾客等待时间
        _avg_exceed_time_number_vec = []  # 每种算法的平均超时订单数量
        _avg_exceed_time_vec = []  # 每种算法的总超时时间

        if False:  # 5次seed求平均
            print("_avg_wait_time_vec:")
            for _i in range(len(_time_cost_3mat)):  # 每种算法
                _total_time_cost = []
                for _j in range(len(_time_cost_3mat[_i])):  # 每个seed
                    for _time_cost in _time_cost_3mat[_i][_j]:
                        _total_time_cost.append(_time_cost)
                _avg_wait_time_vec.append(sum(_total_time_cost) / len(_total_time_cost))
                print(_avg_wait_time_vec[_i])

            print("_avg_exceed_time_number_vec\t_avg_exceed_time_vec")
            for _i in range(len(_exceed_time_3mat)):  # 每种算法
                _total_exceed_time = []
                for _j in range(len(_exceed_time_3mat[_i])):  # 每个seed
                    for _exceed_time in _exceed_time_3mat[_i][_j]:
                        _total_exceed_time.append(_exceed_time - _time_window)
                _avg_exceed_time_number_vec.append(len(_total_exceed_time) / 5)
                _avg_exceed_time_vec.append(sum(_total_exceed_time) / 5)
                print(_avg_exceed_time_number_vec[_i], _avg_exceed_time_vec[_i])

        if True:  # 保存最好一次seed（超时总时长最少）的平均
            _reserved_seeds = []  # 保存各algorithm的最好seed
            for _i in range(len(_exceed_time_3mat)):  # 每种算法
                _each_seed_total_exceed_time_vec = []
                for _j in range(len(_exceed_time_3mat[_i])):  # 每个seed
                    _each_seed_total_exceed_time_vec.append(
                        sum(_exceed_time_3mat[_i][_j]) - _time_window * len(_exceed_time_3mat[_i][_j]))
                for _j, _time in enumerate(_each_seed_total_exceed_time_vec):
                    if _time == min(_each_seed_total_exceed_time_vec):
                        _reserved_seeds.append(_j)
                        break
            print(numpy.array(_reserved_seeds)+1)
            print("_avg_wait_time_vec:")
            for _i in range(len(_time_cost_3mat)):  # 每种算法
                _total_time_cost = []
                for _j in range(len(_time_cost_3mat[_i])):  # 每个seed
                    if _j == _reserved_seeds[_i]:
                        for _time_cost in _time_cost_3mat[_i][_j]:
                            _total_time_cost.append(_time_cost)
                _avg_wait_time_vec.append(sum(_total_time_cost) / len(_total_time_cost))
                print(round(_avg_wait_time_vec[_i],2))

            print("_avg_exceed_time_number_vec")
            for _i in range(len(_exceed_time_3mat)):  # 每种算法
                _total_exceed_time = []
                for _j in range(len(_exceed_time_3mat[_i])):  # 每个seed
                    if _j == _reserved_seeds[_i]:
                        for _exceed_time in _exceed_time_3mat[_i][_j]:
                            _total_exceed_time.append(_exceed_time - _time_window)
                _avg_exceed_time_number_vec.append(len(_total_exceed_time))
                _avg_exceed_time_vec.append(sum(_total_exceed_time))
                print(_avg_exceed_time_number_vec[_i])

            print("_avg_exceed_time_vec")
            for _i in range(len(_exceed_time_3mat)):
                print(round(_avg_exceed_time_vec[_i], 2))

        if False:  # 保存最好一次seed（总时长最少）的平均
            _reserved_seeds = []  # 保存各algorithm的最好seed
            for _i in range(len(_time_cost_3mat)):  # 每种算法
                _each_seed_total_time_cost_vec = []
                for _j in range(len(_time_cost_3mat[_i])):  # 每个seed
                    _each_seed_total_time_cost_vec.append(sum(_exceed_time_3mat[_i][_j]))
                for _j, _time in enumerate(_each_seed_total_time_cost_vec):
                    if _time == min(_each_seed_total_time_cost_vec):
                        _reserved_seeds.append(_j)
                        break
            print(numpy.array(_reserved_seeds)+1)
            print("_avg_wait_time_vec:")
            for _i in range(len(_time_cost_3mat)):  # 每种算法
                _total_time_cost = []
                for _j in range(len(_time_cost_3mat[_i])):  # 每个seed
                    if _j == _reserved_seeds[_i]:
                        for _time_cost in _time_cost_3mat[_i][_j]:
                            _total_time_cost.append(_time_cost)
                _avg_wait_time_vec.append(sum(_total_time_cost) / len(_total_time_cost))
                print(round(_avg_wait_time_vec[_i], 2))

            print("_avg_exceed_time_number_vec")
            for _i in range(len(_exceed_time_3mat)):  # 每种算法
                _total_exceed_time = []
                for _j in range(len(_exceed_time_3mat[_i])):  # 每个seed
                    if _j == _reserved_seeds[_i]:
                        for _exceed_time in _exceed_time_3mat[_i][_j]:
                            _total_exceed_time.append(_exceed_time - _time_window)
                _avg_exceed_time_number_vec.append(len(_total_exceed_time))
                _avg_exceed_time_vec.append(sum(_total_exceed_time))
                print(_avg_exceed_time_number_vec[_i])

            print("_avg_exceed_time_vec")
            for _i in range(len(_exceed_time_3mat)):
                print(round(_avg_exceed_time_vec[_i], 2))
