import json

"""
const:
awesome history data ->

"""

if __name__ == '__main__':
    dir_path = "../Img/2022_04_20_15_00"
    parameters_dir_path = dir_path + "/parameters"
    parameters_file_path=parameters_dir_path+"/parameters.json"
    process_dir_path = dir_path + "/process"
    process_file_path=process_dir_path+"/instance-0_NMA-1.json"
    parameters_file=open(parameters_file_path,'r')
    process_file=open(process_file_path,'r')


    parameters_map=json.load(parameters_file)
    process_map=json.load(process_file)
    parameters_file.close()
    process_file.close()

    print(process_map["tw_penalty_count_matrix"])