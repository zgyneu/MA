import json
import os

# data_root_path = "../Img/2021_12_21_15_24/process/"   # 1000
# data_root_path ="../Img/2021_12_28_12_41/process/"    # 2000
# data_root_path ="../Img/2021_12_29_15_09/process/"    # 5000
# data_root_path ="../Img/2022_01_02_10_15/process/"    # 200
# data_root_path ="../Img/2022_01_02_14_35/process/"    # 500
data_root_path ="../Img/2022_04_20_15_00/process/"  # 300

def read_from_json(file_name):
    """

    :param file_name:
    :return: 每次迭代的最后一次的适应度组成的向量
    """
    _last_fitness_vec = []
    with open(data_root_path + file_name, 'r', encoding='UTF-8') as _j_file:
        _j_rile_map = json.load(_j_file)
        _j_file.close()
    _fitness_value_matrix = _j_rile_map["fitness_value_matrix"]
    for _each_iter in _fitness_value_matrix:
        _last_fitness_vec.append(_each_iter[-1])
    return _last_fitness_vec


def how_many_this_niche(niche_num, compare_mat):
    _counter = 0
    for _rank_vec in compare_mat:
        if _rank_vec[0] == niche_num:
            _counter += 1
    return _counter


def sum_this_niche_in_all_keys(niche_num, compare_mat, transport_mat):
    _sum = 0
    for _i, _rank_vec in enumerate(compare_mat):
        _sum += transport_mat[_i][niche_num-1]
    return _sum


def compare_fitness(fitness_matrix):
    """

    :param fitness_matrix: 第1维度为niche数，第2维度为不同种子的迭代的最后一轮适应度值
    :return:
    """
    _transport_matrix = []  # 将fitness_matrix转置，第1维度为不同key的结果，第2维度为不同niche的结果
    for _ in range(len(fitness_matrix[0])):
        _transport_matrix.append([])
    # print("len(_transport_matrix): ",len(_transport_matrix),"_transport_matrix: ",_transport_matrix,"len(fitness_matrix[0]: ",len(fitness_matrix[0]))
    for _i, _each_niche_vec in enumerate(fitness_matrix):
        for _j, _each_key_fitness_value in enumerate(_each_niche_vec):
            _transport_matrix[_j].append(_each_key_fitness_value)
    _rank_matrix = []  # 按适应度从大到小排序，二维数组，每个一维数组对应一个种子key的排序，每个元素为niche值
    for _each_key_vector in _transport_matrix:
        _niche_num_list = list(range(1, len(_each_key_vector) + 1))
        _zipped_each_key_vector = zip(_niche_num_list, _each_key_vector)
        _mapped_each_key_vector = {}
        for _n, _f in _zipped_each_key_vector:
            _mapped_each_key_vector[_n] = _f
        _sort_vector = sorted(_mapped_each_key_vector.items(), key=lambda x: x[1], reverse=True)
        _rank_vec = []
        for _item in _sort_vector:
            _rank_vec.append(_item[0])
        _rank_matrix.append(_rank_vec)

    return _rank_matrix, _transport_matrix


if __name__ == '__main__':
    all_j_file_names = os.listdir(data_root_path)
    # -----------------------------------------------------------------------------------
    instance_one_file_names = all_j_file_names[:10]
    print("instance one: ", instance_one_file_names)
    instance_one_fitness_matrix = []
    for each_niche_iter in instance_one_file_names:
        instance_one_fitness_matrix.append(read_from_json(each_niche_iter))
        # ↑ 得到instance_0的（第1维度为niche数，第2维度为不同种子的迭代的最后一轮适应度值）的矩阵
        #   如instance_one_compare_matrix[0]代表niche=1的N次不同迭代的最后一轮适应度的vector
    # print("instance_one_fitness_matrix: ", instance_one_fitness_matrix)
    instance_one_compare_matrix, instance_one_fitness_transport = compare_fitness(instance_one_fitness_matrix)
    # ↑ 得到instance_0的（第1维度为key数，第2维度为不同niche的迭代的最后一轮适应度值）的矩阵
    print("instance_one_compare_matrix: ", instance_one_compare_matrix)
    # -----------------------------------------------------------------------------------
    instance_two_file_names = all_j_file_names[10:]
    print("instance two: ", instance_two_file_names)
    instance_two_fitness_matrix = []
    for each_niche_iter in instance_two_file_names:
        instance_two_fitness_matrix.append(read_from_json(each_niche_iter))
        # ↑ 得到instance_1的（第1维度为niche数，第2维度为不同种子的迭代的最后一轮适应度值）的矩阵
    # print("instance_two_fitness_matrix: ", instance_two_fitness_matrix)
    instance_two_compare_matrix, instance_two_fitness_transport = compare_fitness(instance_two_fitness_matrix)
    print("instance_two_compare_matrix: ", instance_two_compare_matrix)
    print("len(instance_two_compare_matrix): ", len(instance_two_compare_matrix))
    print()
    # ------------------------------------------------------------------------------------
    print("instance one:")
    for i,vec in enumerate(instance_one_compare_matrix):
        print("vec ",i+1,": ",end='\t')
        for elem in vec:
            print(elem,end='\t')
        print()

    print("instance two:")
    for i,vec in enumerate(instance_two_compare_matrix):
        print("vec ",i+1,": ",end='\t')
        for elem in vec:
            print(elem,end='\t')
        print()

    print()
    for i in range(1, 11):
        print("one: ",i,": ", sum_this_niche_in_all_keys(i, instance_one_compare_matrix, instance_one_fitness_transport))

    for i in range(1, 11):
        print("two: ",i,": ", sum_this_niche_in_all_keys(i, instance_two_compare_matrix, instance_two_fitness_transport))