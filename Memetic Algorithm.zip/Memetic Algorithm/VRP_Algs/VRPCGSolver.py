'''
Created on Aug 16, 2022

@author: guangyuzou
'''

def cgAssignMax(p,y):
    # p = [[13,4,7,6,4],[1,11,5,4,2],[6,7,2,8,3],[1,3,5,9,4]]
    # y = [[[2]], [[4]], [[1]], [[0,3]]]
    # p = [[13,4,7,6],[1,11,5,4],[6,7,2,8]]
    # y = [[[1]], [[3]], [[0]]]
    # p = [[-1278, -1176, -696, -514, -536, -1050, -548, -856], [-1278, -1176, -696, -514, -536, -1050, -548, -856], [-1278, -1176, -696, -514, -536, -1050, -548, -856], [-1278, -1176, -696, -514, -536, -1050, -548, -856]]
    # p = [[-1278, -176, -696, -14], [-127, -116, -69, -54], [-278, -1176, -66, -514]]
    #
    # y = [[[3]], [[2]], [[1,0]]]
    from docplex.mp.model import Model
    
    for i,_ in enumerate(p):
        for j,_ in enumerate(p[i]):
            p[i][j] *= -1
        
    y[0],y[-1] = y[-1],y[0]
    y[1],y[-2] = y[-2],y[1]
    def calCost(y, i):
        c = 0
        for j, v in enumerate(y):
            if i < len(v):
                for vv in v[i]:
                    c += p[j][vv]
                break
            else:
                i -= len(v)
        return c
    # task i in y[j]
    def inAssign(i, y, j):
        ret = 0
        l = [x for sub in y for x in sub]    
        if i in l[j]:
            ret = 1
        return ret       
    master_mdl = Model('Master-Assign')
    dummy_vars = master_mdl.continuous_var_dict(range(sum(len(i) for i in y)), lb=0, ub=1, name="dummy_cut")
    cost = master_mdl.sum( dummy_vars[j] * calCost(y,j) for j in range(sum(len(i) for i in y)))
    obj = master_mdl.maximize( cost )
    #task equal 1
    cts1 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] * inAssign(i, y,j) for j in range(sum(len(ii) for ii in y)))== 1 for i in range(len(p[0])))
    
    varsRange = [0]*len(y)
    for i,x in enumerate(y):
        if i == 0:
            varsRange[i] = range(len(x))
        else:
            if len(varsRange[i-1]) != 0:
                varsRange[i] = range(varsRange[i-1][-1]+1, varsRange[i-1][-1]+1+ len(x))
            else:
                varsRange[i] = varsRange[i-1]
    #y_k^i <= 1    
    cts2 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] for j in varsRange[i]) <= 1 for i in range(len(y)))
    
    master_mdl.solve()
    # master_mdl.report()
    
    # for j in range(sum(len(i) for i in y)):
    #     print(dummy_vars[j].solution_value)
                   
    
    dualsTask = master_mdl.dual_values(cts1)
    # print('dualsTask', dualsTask)
    dualsWorker = master_mdl.dual_values(cts2)
    # print('dualsWorker', dualsWorker)
    
    for iter in range(30):
        pricingSol = [-1, float('-inf'), []]
     
        for k in range(len(p)):
            sub_mdl = Model('Sub-knapsack'+str(k))
            item_vars = sub_mdl.binary_var_dict(range(len(p[0])), name='items')
            sub_mdl.add_constraint(sub_mdl.sum(item_vars[i] for i in range(len(p[0]))) <= 10)
            sub_mdl.maximize( sub_mdl.sum((p[k][i]-dualsTask[i])*item_vars[i] for i in range(len(p[0]))))
            sub_mdl.solve()
            # sub_mdl.report()
            # print('obj:', sub_mdl.objective_value)
            pricingObj = sub_mdl.objective_value - dualsWorker[k]
            # print('pricing:',  pricingObj)
            if pricingObj > pricingSol[1]:
                pricingSol[1] = pricingObj
                pricingSol[0] = k
                pricingSol[2].clear()
                for i in range(len(p[0])):
                    # print(item_vars[i].solution_value)
                    if item_vars[i].solution_value == 1:
                        pricingSol[2].append(i)
        if pricingSol[1] <= 0:
            break;
        # print(pricingSol)
        if pricingSol[0] != -1:
            y[pricingSol[0]].append(pricingSol[2])
        print(f'Iteration {iter} Obj {master_mdl.objective_value} add {pricingSol}')
        master_mdl = Model('Master-Assign')
        dummy_vars = master_mdl.continuous_var_dict(range(sum(len(i) for i in y)), lb=0, ub=1, name="dummy_cut")
    
        cost = master_mdl.sum( dummy_vars[j] * calCost(y,j) for j in range(sum(len(i) for i in y)))
        master_mdl.maximize( cost )
        cts1 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] * inAssign(i, y,j) for j in range(sum(len(ii) for ii in y)))== 1 for i in range(len(p[0])))
        
        varsRange = [0]*len(y)
        for i,x in enumerate(y):
            if i == 0:
                varsRange[i] = range(len(x))
            else:
                if len(varsRange[i-1]) != 0:
                    varsRange[i] = range(varsRange[i-1][-1]+1, varsRange[i-1][-1]+1+ len(x))
                else:
                    varsRange[i] = varsRange[i-1]
        #y_k^i <= 1    
        cts2 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] for j in varsRange[i]) <= 1 for i in range(len(y)))
    
    
        master_mdl.solve()
        # master_mdl.report()
        dualsTask = master_mdl.dual_values(cts1)
        # print('dualsTask', dualsTask)
        dualsWorker = master_mdl.dual_values(cts2)
        # print('dualsWorker', dualsWorker)
    
    for i in range(len(dummy_vars)):
        master_mdl._set_var_type(dummy_vars[i],master_mdl.integer_vartype)
        
    master_mdl.solve()
    master_mdl.print_information()
    master_mdl.report()    
    k = 0
    for i, v in enumerate(y):
        for j,vv in enumerate(v):
            if i == 0 and dummy_vars[k].solution_value == 1 or i > 0 and dummy_vars[k].solution_value == 1:
                print(i, ':', vv)
            k+=1
class Order():
    def __init__(self, merchant, customer):
        self._merchant = merchant
        self._customer = customer     
    def __repr__(self):
        return '{}-{}'.format(self._merchant, self._customer)                                         
def prepareData():
    data = {}
    data['distance_matrix'] = [
        [
            0, 548, 776, 696, 582, 274, 502, 194, 308, 194, 536, 502, 388, 354,
            468, 776, 662
        ],
        [
            548, 0, 684, 308, 194, 502, 730, 354, 696, 742, 1084, 594, 480, 674,
            1016, 868, 1210
        ],
        [
            776, 684, 0, 992, 878, 502, 274, 810, 468, 742, 400, 1278, 1164,
            1130, 788, 1552, 754
        ],
        [
            696, 308, 992, 0, 114, 650, 878, 502, 844, 890, 1232, 514, 628, 822,
            1164, 560, 1358
        ],
        [
            582, 194, 878, 114, 0, 536, 764, 388, 730, 776, 1118, 400, 514, 708,
            1050, 674, 1244
        ],
        [
            274, 502, 502, 650, 536, 0, 228, 308, 194, 240, 582, 776, 662, 628,
            514, 1050, 708
        ],
        [
            502, 730, 274, 878, 764, 228, 0, 536, 194, 468, 354, 1004, 890, 856,
            514, 1278, 480
        ],
        [
            194, 354, 810, 502, 388, 308, 536, 0, 342, 388, 730, 468, 354, 320,
            662, 742, 856
        ],
        [
            308, 696, 468, 844, 730, 194, 194, 342, 0, 274, 388, 810, 696, 662,
            320, 1084, 514
        ],
        [
            194, 742, 742, 890, 776, 240, 468, 388, 274, 0, 342, 536, 422, 388,
            274, 810, 468
        ],
        [
            536, 1084, 400, 1232, 1118, 582, 354, 730, 388, 342, 0, 878, 764,
            730, 388, 1152, 354
        ],
        [
            502, 594, 1278, 514, 400, 776, 1004, 468, 810, 536, 878, 0, 114,
            308, 650, 274, 844
        ],
        [
            388, 480, 1164, 628, 514, 662, 890, 354, 696, 422, 764, 114, 0, 194,
            536, 388, 730
        ],
        [
            354, 674, 1130, 822, 708, 628, 856, 320, 662, 388, 730, 308, 194, 0,
            342, 422, 536
        ],
        [
            468, 1016, 788, 1164, 1050, 514, 514, 662, 320, 274, 388, 650, 536,
            342, 0, 764, 194
        ],
        [
            776, 868, 1552, 560, 674, 1050, 1278, 742, 1084, 810, 1152, 274,
            388, 422, 764, 0, 798
        ],
        [
            662, 1210, 754, 1358, 1244, 708, 480, 856, 514, 468, 354, 844, 730,
            536, 194, 798, 0
        ],
    ]
    data['distance_matrix'] = [[-j for j in i] for i in data['distance_matrix'] ]
    data['pickups_deliveries'] = [
        [1, 6],
        [2, 10],
        [4, 3],
        [5, 9],
        [7, 8],
        [15, 11],
        [13, 12],
        [16, 14],
    ]
    data['num_vehicles'] = 4

    data['time_windows'] = [ (0, 72000000)] * len(data['distance_matrix'])
    data['time_windows'][0] = (0,0)
    data['vehicle_capacities'] = 10
    data['demands'] = [0]*len(data['distance_matrix'])
    for i in data['pickups_deliveries'] :
        for j, k in enumerate(i):
            if j == 0:
                data['demands'][k] = 1
            else:    
                data['demands'][k] = -1
    data['depot'] = 0
    # print(callCTSPLib(data))
    plan = [[] for _ in range(data['num_vehicles'])]
    i = 0
    orders = []
    for pair in  data['pickups_deliveries']:
        order = Order(pair[0], pair[1])
        orders.append(order)
        if len(plan[i]) == 0:
            plan[i].append([order])
        else:
            plan[i][-1].append(order)
        i += 1
        if i >= data['num_vehicles']:
            i %= data['num_vehicles']
    # plan[0].append([orders[0], orders[4]])
    # plan[1].append([orders[1], orders[3], orders[7]])
    # plan[2].append([orders[2]])
    # plan[3].append([orders[5], orders[6]])

    cost = []
    for iCourier, p in enumerate(plan):
        cost.append([])
        for ors in orders:
            courierData, index_node = splitDataForCourier(data, 0,[ors])
            route = callCTSPLib(courierData)
            route[1:] = [index_node[route[i]] for i in range(1, len(route))]
            cost[-1].append(route[0])
    # for iCourier, p in enumerate(plan):
    #     cost.append([])
    #     for ors in p:
    #         courierData, index_node = splitDataForCourier(data, 0,ors)
    #         route = callCTSPLib(courierData)
    #         route[1:] = [index_node[route[i]] for i in range(1, len(route))]
    #         cost[-1].append(route[0])
    
    return (plan, cost, orders, data)

class VRPCGSolver():
    @staticmethod
    def solve(data):
        data['depot'] = data['starts']
        data['vehicle_capacities'] = data['vehicle_capacities'][0]
        
        plan = [[] for _ in range(data['num_vehicles'])]
        y = [[] for _ in range(data['num_vehicles'])]
        i = 0
        orders = []
        for pair in  data['pickups_deliveries']:
            order = Order(pair[0], pair[1])
            orders.append(order)
            if len(plan[i]) == 0:
                plan[i].append([order])
                y[i].append([len(orders)-1])
            else:
                plan[i][-1].append(order)
                y[i][-1].append(len(orders)-1)
            i += 1
            if i >= data['num_vehicles']:
                i %= data['num_vehicles']

        cost = []
        for iCourier in data['depot']:
            cost.append([])
            for ors in orders:
                courierData, index_node = splitDataForCourier(data, iCourier,[ors])
                route = callCTSPLib(courierData)
                route[1:] = [index_node[route[i]] for i in range(1, len(route))]
                cost[-1].append(route[0])
        cgAssignMax(cost, y)
        # for i, v in enumerate(data['distance_matrix']):
        #     for j, _ in enumerate(v):
        #         data['distance_matrix'][i][j] *= -1
        # cost = []
        # for iCourier, pl in enumerate(plan):
        #     cost.append([])
        #     for ors in pl:
        #         courierData, index_node = splitDataForCourier(data, iCourier,ors)
        #         route = callCTSPLib(courierData)
        #         route[1:] = [index_node[route[i]] for i in range(1, len(route))]
        #         cost[-1].append(route[0])
        # cgAssignVRP(cost,plan,orders,data)
     
def splitDataForCourier(data, curCourier, orders):
    ret = {} 
    # distance mat
    
    index_node = {}
    index_node[0] = curCourier
    node_index = {}
    node_index[curCourier] = 0
    index = 1
    for j in orders:
        node_index[j._merchant] = index
        index_node[index] = j._merchant
        index += 1
        node_index[j._customer] = index
        index_node[index] = j._customer
        index += 1
    ret['distance_matrix'] = [[0]*len(index_node) for i in range(len(index_node))]
    for i in range(len(ret['distance_matrix'])):
        for j in range(len(ret['distance_matrix'])):
            if i != j:
                ret['distance_matrix'][i][j] = data['distance_matrix'][index_node[i]][index_node[j]]
    # pickup
    ret['pickups_deliveries'] = [[node_index[i._merchant], node_index[i._customer]] for i in orders]
    # time window
    ret['time_windows'] = [ (0, 72000000)] * len(ret['distance_matrix'])
    ret['time_windows'][0] = (0,0)
    # demands
    ret['demands'] = [0]*len(ret['distance_matrix'])
    for j, k in enumerate(orders):
        if j % 2 == 0:
            ret['demands'][node_index[k._merchant]] = 1
        else:    
            ret['demands'][node_index[k._customer]] = -1
    ret['vehicle_capacities'] = data['vehicle_capacities']
    return ret, index_node    
def callCTSPLib(data):
    
    def convert2DtoCtype(a):
        retType = c_int*(len(a)*len(a[0]))
        ret = retType()
        for i in range(len(a)):
            for j in range(len(a[i])):
                ret[i*len(a[i])+j] = round(a[i][j])
        return (ret, len(a)*len(a[0]))
    def convert1DtoCtype(a):
        retType = c_int*len(a)
        ret = retType()
        for i in range(len(a)):
            ret[i] = a[i]
        return (ret, len(a))
    def convertDictToCType(x):
        retType = c_int*(2*len(x))
        ret = retType();
        retLen = 0
        for i in x:
            ret[retLen] = i[0]
            ret[retLen+1] = i[1]
            retLen += 2
        return (ret, retLen)
    
    
    def convert2Dto1D(a):
        ret = []
        for i in range(len(a)):
            for j in range(len(a[i])):
                ret.append(int(round(a[i][j])))
        return ret
    def convertDictTo1D(x):
        ret = []
        for i in x:
            ret.append(i[0])
            ret.append(i[1])
        return ret
    def convert1Dto1D(a):
        ret = []
        for i in range(len(a)):
            ret.append(a[i])
        return (ret)
    
    import tspModule
    route = tspModule.runTSP(convert2Dto1D(data['distance_matrix']), convertDictTo1D(data['pickups_deliveries']), data['vehicle_capacities'], convert1Dto1D(data['demands']), convertDictTo1D(data['time_windows']), 0, 0)
    return (route)
    # routePy = [wrapper._index2Node[v] for i, v in enumerate(route) if i > 0 if v != wrapper._node2Index[startP] ] 
    # if route[0] < 0:
    #     return float('inf'), []
    # else:
    #     return int(route[0]), routePy 
def cgAssignVRP(p,y, orders, data):
    # p = [[13,4,7,6],[1,11,5,4],[6,7,2,8],[1,3,5,9]]
    # y = [[[0]], [[1]], [[2]], [[3]]]
    # p = [[13,4,7,6],[1,11,5,4],[6,7,2,8]]
    # y = [[[1]], [[3]], [[0]]]
    from docplex.mp.model import Model
    
    # for i,_ in enumerate(p):
    #     for j,_ in enumerate(p[i]):
    #         p[i][j] *= -1
        
    
    # def calCost(y, i):
    #     c = 0
    #     for j, v in enumerate(y):
    #         if i < len(v):
    #             c += p[j][i]
    #             break
    #         else:
    #             i -= len(v)
    #     return c
    def calCost(y, i):
        c = 0
        for j, v in enumerate(y):
            if i < len(v):
                c = p[j][i]
                break
            else:
                i -= len(v)
        return c
    # task i in y[j]
    def inAssign(i, y, j):
        ret = 0
        k = j
        for v in y:
            if k < len(v):
                ret = 1 if i in v[k] else 0
                break
            else:
                k -= len(v)
        return ret       
    master_mdl = Model('Master-Assign')
    dummy_vars = master_mdl.continuous_var_dict(range(sum(len(i) for i in y)), lb=0, ub=1, name="dummy_cut")
    cost = master_mdl.sum( dummy_vars[j] * calCost(y,j) for j in range(sum(len(i) for i in y)))
    obj = master_mdl.maximize( cost )
    #task equal 1
    cts1 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] * inAssign(i, y,j) for j in range(sum(len(ii) for ii in y)))== 1 for i in orders)
    
    varsRange = [0]*len(y)
    for i,x in enumerate(y):
        if i == 0:
            varsRange[i] = range(len(x))
        else:
            if len(varsRange[i-1]) != 0:
                varsRange[i] = range(varsRange[i-1][-1]+1, varsRange[i-1][-1]+1+ len(x))
            else:
                varsRange[i] = varsRange[i-1]
    #y_k^i <= 1    
    cts2 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] for j in varsRange[i]) <= 1 for i in range(len(y)))
 
 
    master_mdl.solve()
    master_mdl.report()
    
    for j in range(sum(len(i) for i in y)):
        print(dummy_vars[j].solution_value)
                   
    k = 0
    for i, v in enumerate(y):
        for j,vv in enumerate(v):
            if i == 0 and dummy_vars[k].solution_value == 1 or i > 0 and dummy_vars[k].solution_value == 1:
                print(i, ':', vv)
            k+=1
    dualsTask = master_mdl.dual_values(cts1)
    # print('dualsTask', dualsTask)
    dualsWorker = master_mdl.dual_values(cts2)
    # print('dualsWorker', dualsWorker)
    
    
    #calculate p matrix
    pSingle = [[] for _ in y]
    for i, courier in enumerate(pSingle):
        for order in orders:
            courierData, index_node = splitDataForCourier(data, i,[order])
            route = callCTSPLib(courierData)
            route[1:] = [index_node[route[i]] for i in range(1, len(route))]
            courier.append(route[0])
    
    
    for iter in range(100):
        pricingSol = [-1, float('-inf'), []]
     
        for k in range(len(p)):
            sub_mdl = Model('Sub-knapsack'+str(k))
            item_vars = sub_mdl.binary_var_dict(range(len(orders)), name='Order')
            sub_mdl.add_constraint(sub_mdl.sum(item_vars[i] for i in range(len(orders))) <= 10)
            sub_mdl.maximize( sub_mdl.sum((pSingle[k][i]-dualsTask[i])*item_vars[i] for i in range(len(orders))))
            sub_mdl.solve()
            # sub_mdl.report()
            # print('obj:', sub_mdl.objective_value)
            pricingObj = sub_mdl.objective_value - dualsWorker[k]
            # print('pricing:',  pricingObj)
            if pricingObj > pricingSol[1]:
                pricingSol[1] = pricingObj
                pricingSol[0] = k
                pricingSol[2].clear()
                for i in range(len(orders)):
                    # print(item_vars[i].solution_value)
                    if item_vars[i].solution_value == 1:
                        pricingSol[2].append(orders[i])
        if pricingSol[1] <= 0:
            break;
        # print(pricingSol)
        if pricingSol[0] != -1:
            y[pricingSol[0]].append(pricingSol[2])
            # add the new cost to p array
            courierData, index_node = splitDataForCourier(data, pricingSol[0],pricingSol[2])
            route = callCTSPLib(courierData)
            route[1:] = [index_node[route[i]] for i in range(1, len(route))]
            p[pricingSol[0]].append(route[0])
            
                  
        print(f'Iteration {iter} Obj {master_mdl.objective_value} add {pricingSol}')
        
        master_mdl = Model('Master-Assign')
        dummy_vars = master_mdl.continuous_var_dict(range(sum(len(i) for i in y)), lb=0, ub=1, name="dummy_cut")
        cost = master_mdl.sum( dummy_vars[j] * calCost(y,j) for j in range(sum(len(i) for i in y)))
        obj = master_mdl.maximize( cost )
        #task equal 1
        cts1 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] * inAssign(i, y,j) for j in range(sum(len(ii) for ii in y)))== 1 for i in orders)
        
        varsRange = [0]*len(y)
        for i,x in enumerate(y):
            if i == 0:
                varsRange[i] = range(len(x))
            else:
                if len(varsRange[i-1]) != 0:
                    varsRange[i] = range(varsRange[i-1][-1]+1, varsRange[i-1][-1]+1+ len(x))
                else:
                    varsRange[i] = varsRange[i-1]
        #y_k^i <= 1    
        cts2 = master_mdl.add_constraints( master_mdl.sum(dummy_vars[j] for j in varsRange[i]) <= 1 for i in range(len(y)))
 
   
        master_mdl.solve()
        # master_mdl.report()
        dualsTask = master_mdl.dual_values(cts1)
        # print('dualsTask', dualsTask)
        dualsWorker = master_mdl.dual_values(cts2)
        # print('dualsWorker', dualsWorker)
    
    for i in range(len(dummy_vars)):
        master_mdl._set_var_type(dummy_vars[i],master_mdl.integer_vartype)
        
    master_mdl.solve()
    master_mdl.print_information()
    master_mdl.report()    
    k = 0
    for i, v in enumerate(y):
        for j,vv in enumerate(v):
            if i == 0 and dummy_vars[k].solution_value == 1 or i > 0 and dummy_vars[k].solution_value == 1:
                print(i, ':', vv)
            k+=1
# plan, cost, orders, data = prepareData()
# cgAssignVRP(cost, plan, orders, data)
# cgAssignMax()

