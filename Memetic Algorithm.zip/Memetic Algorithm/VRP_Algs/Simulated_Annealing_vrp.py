import math
import random
from time import time
from itertools import permutations

from Utils.Convert_Node_Graph_into_Graph import *


# 采用罚函数解决VRP的三种限制
# 采用pickup and delivery纠正算子，加快求解收敛速度
# 采用轮盘赌算法，适应度越高的染色体交叉遗传的概率越大
# 采用(逆序+位移+)2opt算子的变异算法，保持解的多样性，加快跳出局部最优解
# 采用动态调整cross over概率和mutation概率，平衡“保留精英”和跳出局部最优
# multi-depot、nodes-binding


# 部分规定：
# 1.运算过程中，所有chromosome指带有fitness的route，即 chromosome=[route,fitness]，solution同chromosome
# 2.运算过程中，无论openvrp与否，存储于变量中的route、subroute列表，都只有头部带有depot而尾部不带有depot

class SA:
    class _NodeEnum(Enum):
        SHOP = 1
        CLIENT = 2
        PACKAGE = 3
        DEPOT = 4

    class TargetEnum(Enum):
        """
        目标函数Enum：
            1.最少Client、Package节点等待时间（从该订单产生到订单完成的总时间）
            2.最少总行驶距离（所有骑手）
        """
        TIME = 1
        DISTANCE = 2

    class _Cache:
        fitness_mem_map = {}  # 缓存 路径(.__str__())->适应度
        cost_without_penalty_mem_map = {}  # 缓存 路径(.__str__())->路径花费
        local_search_map = {}  # 缓存 路径(.__str__())->chromosome (local_search结果)
        fitness_value_sub_route_map = {}  # 缓存 子路径(.__str__())->适应度值(float)
        local_search_save_all_map = {}  # 缓存 路径(.__str__())->所有邻域解的列表 (local_search结果)
        route_to_sub_routes_map = {}  # 缓存 路径(.__str__())->对应的子路径列表
        hamming_distance_map = {}  # 缓存 路径(.__str__())->完整路径对应的汉明码距离
        hamming_of_sub_route_map = {}  # 缓存 子路径(.__str__())->子路径对应的汉明码距离

        def clean(self):
            self.fitness_mem_map = {}
            self.cost_without_penalty_mem_map = {}
            self.local_search_map = {}
            self.fitness_value_sub_route_map = {}
            self.local_search_save_all_map = {}
            self.route_to_sub_routes_map = {}
            self.hamming_distance_map = {}
            self.hamming_of_sub_route_map = {}

    class Chromosome:
        """
        染色体类，包含route和相应的fitness，即 chromosome=[route,_Fitness]
        """

        class Fitness:
            """
            适应度类，给入等待时间或行驶路程（不需要求倒数）和各种惩罚的计数
            """

            def __init__(self, fitness_value: float, real_value: float, pd_penalty_count: int, cap_penalty_count: int,
                         tw_penalty_count: float):
                """
                初始化适应度类
                :param fitness_value: 1/(real_value+penalties_value)
                :param real_value: 等待时间或行驶路程（不需要求倒数）
                :param pd_penalty_count: 取送顺序错误计数
                :param cap_penalty_count: 容量超限（上、下限）计数
                :param tw_penalty_count: 时间窗超出计数
                """
                self.tw_penalty_count = tw_penalty_count
                self.cap_penalty_count = cap_penalty_count
                self.pd_penalty_count = pd_penalty_count
                self.fitness_value = fitness_value
                self.real_value = real_value
                # 如果个体含有 取送惩罚 或 容量惩罚，则有严重惩罚
                self.b_have_fatal_penalty = True if (cap_penalty_count != 0 or pd_penalty_count) != 0 else False
                # 如果个体没有严重惩罚，但有时间窗惩罚，则有普通惩罚
                self.b_have_penalty = True if \
                    (tw_penalty_count != 0 and not self.b_have_fatal_penalty) else False

        def __init__(self, route: list, fitness: Fitness):
            self.route = route
            self.fitness = fitness

    def _calc_fitness_value(self, real_value: float, pd_penalty_count: int, cap_penalty_count: int,
                            tw_penalty_count: float) -> Chromosome.Fitness:
        """
        通过给入等待时间或行驶路程，计算适应度值，fitness_value=1/(real_value+penalties_value)
        :param real_value: 等待时间或行驶路程（不需要求倒数）
        :return:
        """
        _fitness_value = 1.0 / (real_value + (self._capacity_penalty_ratio * cap_penalty_count +
                                              self._time_window_penalty_ratio * tw_penalty_count +
                                              self._pickup_delivery_penalty_ratio * pd_penalty_count)
                                * self._penalty_coefficient)
        return self.Chromosome.Fitness(_fitness_value, real_value, pd_penalty_count, cap_penalty_count,
                                       tw_penalty_count)

    def __init__(self, seed=123, population=1000, iter_time=1000, penalty_coefficient=100000, niche_num=1,
                 terminate_by_fitness_equal=True,
                 open_vrp: bool = True, target=TargetEnum.DISTANCE, speed=1, debug_info=False):
        self._data = {}
        self._speed = speed
        random.seed(seed)
        self._cache = self._Cache()
        self._iteration_num = iter_time  # 迭代代数
        self._nodes_len = -1
        self._terminate_fitness_equal_time = 20
        self._b_terminate_by_fitness_equal = terminate_by_fitness_equal
        self._penalty_coefficient = penalty_coefficient  # 罚系数, 1尽可能大
        self._pickup_delivery_penalty_ratio = 5000  # 取送顺序罚倍率
        self._time_window_penalty_ratio = 1  # 每超时1秒的罚倍率
        self._capacity_penalty_ratio = 1000  # 每超限或低限1个的罚倍率
        self._need_correct_pickup_delivery = True

        self._terminate_fitness_equal_count = 0  # 迭代过程中，最优解相等次数计数器
        self.__iter_count=0
        self._b_open_vrp = open_vrp  # open_vrp最后少一步计算，即最后一个路径节点返回depot的开销
        self._target = target  # 目标函数：总时间最少或总路径最短

        self._init_temp = 5000  # 初温
        self._terminate_temp = 1e-5  # 终止温度
        self._annealing_rate = 0.975  # 退火率

        self.__b_debug_info_print = debug_info

    def create_data_model(self, graph, pickups_deliveries, time_windows, demands: list, depot: list, binding,
                          num_vehicles, capacity=3, distance_matrix=None, service_time=None):
        """Stores the data for the problem.写入时，车辆节点从负数开始一直到0（包含0），路径节点从1开始"""
        self._data["time_matrix"] = graph  # matrix 注意：起对角线元素、第一列元素COST均为0
        self._data["distance_matrix"] = distance_matrix  # 用于instance算法对比，matrix不包含service_time
        self._data["pickups_deliveries"] = pickups_deliveries  # 二维list，内层维度分别为shop和client,形如：[[3, 1], [4, 2],]
        self._data["time_windows"] = time_windows  # list，内层为tuple，分别是0和time_remain
        # 形如：[
        #     (0, 5),  # depot
        #     (0, 10),  # 1
        #     (0, 500),  # 2
        #     (0, 5),  # 3
        #      ]
        self._data["demands"] = demands  # 形如：[1, -1, -1, 1]
        self._data["vehicle_capacities"] = capacity  # 容量限制，形如 3
        self._data["depot"] = depot  # 形如： [0,1,2,3]，对应原始depot[-4,-3,-2,-1]，或[0,0,0,0]，对应原始depot[0,0,0,0]
        self._data["binding"] = binding  # 形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
        self._data["num_vehicles"] = num_vehicles
        self._nodes_len = len(graph[0])
        self._data["shop_nodes"] = []
        self._data["client_nodes"] = []
        self._data["package_nodes"] = []
        self._data["service_time"] = service_time  # 形如：[10,20,...]
        if num_vehicles > 1:
            # 当num_vehicles>1，更新self._data["pickups_deliveries"]内节点和self._data["binding"]内节点的序号为当前序号+车辆数量-1
            for _i in range(len(self._data["pickups_deliveries"])):
                self._data["pickups_deliveries"][_i][0] += num_vehicles - 1
                self._data["pickups_deliveries"][_i][1] += num_vehicles - 1
            for _v in range(num_vehicles):
                for _j in range(len(self._data["binding"][_v])):
                    self._data["binding"][_v][_j] += num_vehicles - 1

        self._data["shop_client_map"] = {}  # 用于快速找出shop对应的client
        self._data["client_shop_map"] = {}  # 用于快速找出client对应的shop
        self._data["binding_node_to_vehicle_id_map"] = {}  # 用于快速找出package对应绑定的vehicle id
        for _pickup_node, _delivery_node in pickups_deliveries:
            self._data["shop_nodes"].append(_pickup_node)
            self._data["client_nodes"].append(_delivery_node)
            self._data["shop_client_map"][_pickup_node] = _delivery_node
            self._data["client_shop_map"][_delivery_node] = _pickup_node
        for _i, _vehicle_binding in enumerate(binding):
            for _package in _vehicle_binding:
                self._data["package_nodes"].append(_package)
                self._data["binding_node_to_vehicle_id_map"][_package] = _i
        self._data["nodes_attr_map"]: dict = {}  # 用于快速判断节点是什么类型，值共四种："depot","shop"、"client"、"package"
        for _node in self._data["shop_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.SHOP
        for _node in self._data["client_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.CLIENT
        for _node in self._data["package_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.PACKAGE
        for _node in self._data["depot"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.DEPOT

    def _gen_init_sol(self) -> Chromosome:
        """产生初始解，单一解，greedy"""
        _init_population = []
        for _ in range(self._nodes_len ** 2):
            _route = []
            # 针对每个骑手，分配一条子路径
            for _depot in self._data["depot"]:
                _sub_route = [_depot]
                _route.append(_sub_route)
            _sub_route_len = len(_route)
            # 先将所有pd对随机分配给所有骑手，注意：client节点在shop节点之后
            for _shop_node, _client_node in self._data["pickups_deliveries"]:
                _random_choose_sub_route_idx = random.randint(0, _sub_route_len - 1)
                _random_client_insert_idx = random.randint(1, len(_route[_random_choose_sub_route_idx]))
                _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
                _route[_random_choose_sub_route_idx].insert(_random_client_insert_idx, _client_node)
                _route[_random_choose_sub_route_idx].insert(_random_shop_insert_idx, _shop_node)
            # 将所有binding节点分配给对应骑手，随机插入各子路径
            for _i, _vehicle_binding in enumerate(self._data["binding"]):
                for _binding_node in _vehicle_binding:
                    _random_insert_idx = random.randint(1, len(_route[_i]))
                    _route[_i].insert(_random_insert_idx, _binding_node)
            _concatenated_route = []
            # 子路径首尾连接
            for _sub_route in _route:
                _sub_route = self._correct_pickup_and_delivery(_sub_route)
                _concatenated_route += _sub_route
            # 种群存入每一个chromosome个体
            _init_population.append(self.Chromosome(_concatenated_route,
                                                    self._calc_fit(_concatenated_route, self._b_open_vrp,
                                                                   target=self._target)))
        # for _sol in _init_population:
        #     print("_sol.fitness:",_sol.fitness)

        # 返回最优个体
        _best_sol: SA.Chromosome | None = None
        _best_fitness_value = -1
        for _sol in _init_population:
            if _sol.fitness.fitness_value > _best_fitness_value:
                _best_fitness_value = _sol.fitness.fitness_value
                _best_sol = _sol
        return _best_sol

    def _split_route_into_sub_routes(self, route: list) -> list[list]:
        """
        将长路径转换为子路径组成的列表，route总按头部为depot而末尾不包含depot
        :return:
        """
        _split_routes = self._cache.route_to_sub_routes_map.get(route.__str__(), [])
        if _split_routes:
            _split_routes_copy = copy.deepcopy(_split_routes)
            return _split_routes_copy
        _split_index = 0
        _routes_len = len(route)
        for _i, _node in enumerate(route):
            if _i == 0:
                continue
            if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.DEPOT:
                _split_routes.append(route[_split_index:_i])
                _split_index = _i
            if _i == (_routes_len - 1):
                _split_routes.append(route[_split_index:])
                _split_routes_copy = copy.deepcopy(_split_routes)
                self._cache.route_to_sub_routes_map[route.__str__()] = _split_routes_copy
                return _split_routes

    def _calc_fit(self, route, b_open_vrp=True, target=TargetEnum.DISTANCE) -> Chromosome.Fitness:
        """

        :param target: 针对benchmark的对比，只比较路线总长度，不计算服务时间等（服务时间只用作tw约束）
        :param route: 列表
        :param b_open_vrp: 路径是否在最后插入depot，即车辆是否需要返回depot
        :return:
        """
        # 首先，根据depot分割route
        _fitness = self._cache.fitness_mem_map.get(route.__str__(), None)

        if _fitness:

            return _fitness
        _split_routes = self._split_route_into_sub_routes(route)

        if target == self.TargetEnum.DISTANCE or target == self.TargetEnum.TIME:
            _target_cost = 0
            # 循环计算各子route的cost，对于 for_total_distance，只cost就是所有route的总距离（不包括服务时间）
            if target == self.TargetEnum.DISTANCE:  # 适应度：路径总距离
                for _sub_route in _split_routes:
                    # 缓存子路径计算结果（单纯距离不含惩罚）
                    _sub_distance_cost = self._cache.cost_without_penalty_mem_map.get(_sub_route.__str__(), -1)
                    if _sub_distance_cost != -1:
                        _target_cost += _sub_distance_cost
                        continue
                    else:
                        _sub_route_len = len(_sub_route)
                        if _sub_route_len == 1:
                            continue
                        _sub_distance_cost = 0
                        # 计算子route的纯路径距离
                        for _idx in range(_sub_route_len - 1):
                            _sub_distance_cost += self._data["distance_matrix"][_sub_route[_idx]][_sub_route[_idx + 1]]
                        # 如果非开放vrp，则需要返回depot
                        if not b_open_vrp:
                            _sub_distance_cost += self._data["distance_matrix"][_sub_route[-1]][_sub_route[0]]
                        self._cache.cost_without_penalty_mem_map[_sub_route.__str__()] = _sub_distance_cost
                        _target_cost += _sub_distance_cost

            # 循环计算各子route的cost，对于 for_total_distance，只cost就是所有route的总距离（不包括服务时间），且不存在openvrp的区别
            elif target == self.TargetEnum.TIME:
                for _sub_route in _split_routes:
                    # 缓存子路径计算结果（单纯所有客户、包裹节点花费时间不含惩罚）
                    _sub_time_cost = self._cache.cost_without_penalty_mem_map.get(_sub_route.__str__(), -1)
                    if _sub_time_cost != -1:
                        _target_cost += _sub_time_cost
                        continue
                    else:
                        _sub_route_len = len(_sub_route)
                        if _sub_route_len == 1:
                            continue
                        _sub_time_cost = 0
                        _accumulate_time_cost = self._data["service_time"][_sub_route[0]]  # 用于累积子路径的时间花费
                        # 计算子route的纯时间消耗（各客户、包裹节点花费时间）
                        for _idx in range(_sub_route_len - 1):
                            _accumulate_time_cost += self._data["distance_matrix"][_sub_route[_idx]][
                                                         _sub_route[_idx + 1]] / self._speed + \
                                                     self._data["service_time"][_sub_route[_idx + 1]]
                            if self._data["nodes_attr_map"].get(_sub_route[_idx + 1], None) == self._NodeEnum.CLIENT or \
                                    self._data["nodes_attr_map"].get(_sub_route[_idx + 1],
                                                                     None) == self._NodeEnum.PACKAGE:
                                _sub_time_cost += _accumulate_time_cost
                        self._cache.cost_without_penalty_mem_map[_sub_route.__str__()] = _sub_time_cost
                        _target_cost += _sub_time_cost
            # 惩罚统计
            _cap_penalty_count = 0  # 累计超限或低限个数
            _time_penalty_count = 0  # 累计超时秒数
            _pickup_delivery_penalty_count = 0  # 累计先取后送违背次数
            for _sub_route in _split_routes:
                _sub_time_cost = 0
                _sub_cap_accu = 0
                _sub_route_len = len(_sub_route)
                if _sub_route_len == 1:
                    continue
                for _idx in range(_sub_route_len - 1):
                    if _sub_route[_idx] == _sub_route[_idx + 1]:
                        print("route:", route)
                        print("_sub_route[_idx]:", _sub_route[_idx])
                        print("_split_routes:", _split_routes)
                        raise Exception("error", "error")
                    # 计算时间窗惩罚
                    if _sub_time_cost < self._data["time_windows"][_sub_route[_idx]][0]:
                        _time_penalty_count += self._data["time_windows"][_sub_route[_idx]][0] - _sub_time_cost
                    _sub_time_cost += self._data['distance_matrix'][_sub_route[_idx]][
                                          _sub_route[_idx + 1]] / self._speed
                    if _sub_time_cost > self._data["time_windows"][_sub_route[_idx + 1]][1]:
                        _time_penalty_count += _sub_time_cost - self._data["time_windows"][_sub_route[_idx + 1]][1]
                    _sub_time_cost += self._data["service_time"][_sub_route[_idx + 1]]
                    # 计算容量惩罚
                    _sub_cap_accu += self._data['demands'][_sub_route[_idx]]
                    if _sub_cap_accu < 0:
                        _cap_penalty_count += -_sub_cap_accu
                    elif _sub_cap_accu > self._data['vehicle_capacities']:
                        _cap_penalty_count += _sub_cap_accu - self._data['vehicle_capacities']
                # 非openvrp，补充回depot的时间窗惩罚检测
                if not b_open_vrp:
                    _sub_time_cost += self._data['distance_matrix'][_sub_route[-1]][_sub_route[0]] / self._speed
                    if _sub_time_cost > self._data["time_windows"][_sub_route[0]][1]:
                        _time_penalty_count += _sub_time_cost - self._data["time_windows"][_sub_route[0]][1]

                # 计算先取后送惩罚
                for _idx, _node in enumerate(_sub_route):
                    if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                        _second = self._data["shop_client_map"].get(_node, None)
                        try:
                            _second_idx = _sub_route.index(_second)
                        except Exception:
                            _second_idx = -1
                            raise Exception("_sub_route:", _sub_route, "_order:", (_node, _second), "\n",
                                            "_split_routes:", _split_routes)
                        if _idx > _second_idx:
                            _pickup_delivery_penalty_count += 1

            _fitness: SA.Chromosome.Fitness = self._calc_fitness_value(real_value=_target_cost,
                                                                       pd_penalty_count=_pickup_delivery_penalty_count,
                                                                       cap_penalty_count=_cap_penalty_count,
                                                                       tw_penalty_count=_time_penalty_count)
            self._cache.fitness_mem_map[route.__str__()] = _fitness
            return _fitness  # self._Chromosome.Fitness类

    def __total_diff_chromosome(self, population):
        if self.__b_debug_info_print:
            _container = []
            for _chromosome in population:
                # print(_chromosome[0].__str__())
                _container.append(_chromosome[0].__str__())
            _container = set(_container)
            print("how many diff:", len(_container))
        else:
            return

    def _calc_fitness_value_of_sub_route(self, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> float:
        """
        用在局部搜索，计算局部搜索的子route的适应度
        :param target:
        :param b_open_vrp:
        :param sub_route:
        :return:
        """
        _fitness_value = self._cache.fitness_value_sub_route_map.get(sub_route.__str__(), -1)
        if _fitness_value != -1:
            return _fitness_value
        _sub_route_len = len(sub_route)
        if target == self.TargetEnum.DISTANCE or target == self.TargetEnum.TIME:
            _target_cost = 0
            if target == self.TargetEnum.DISTANCE:
                if _sub_route_len == 1:
                    return 0
                for _idx in range(_sub_route_len - 1):
                    if sub_route[_idx] == sub_route[_idx + 1]:
                        raise Exception("error", "error")
                    _target_cost += self._data["distance_matrix"][sub_route[_idx]][sub_route[_idx + 1]]
                if not b_open_vrp:
                    _target_cost += self._data["distance_matrix"][sub_route[-1]][sub_route[0]]
                self._cache.cost_without_penalty_mem_map[sub_route.__str__()] = _target_cost
            elif target == self.TargetEnum.TIME:
                if _sub_route_len == 1:
                    return 0
                _target_cost = 0
                _accumulate_time_cost = self._data["service_time"][sub_route[0]]  # 用于累积子路径的时间花费
                # 计算子route的纯时间消耗（各客户、包裹节点花费时间）
                for _idx in range(_sub_route_len - 1):
                    _accumulate_time_cost += self._data["distance_matrix"][sub_route[_idx]][
                                                 sub_route[_idx + 1]] / self._speed + \
                                             self._data["service_time"][sub_route[_idx + 1]]
                    if self._data["nodes_attr_map"].get(sub_route[_idx + 1], None) == self._NodeEnum.CLIENT or \
                            self._data["nodes_attr_map"].get(sub_route[_idx + 1],
                                                             None) == self._NodeEnum.PACKAGE:
                        _target_cost += _accumulate_time_cost
                self._cache.cost_without_penalty_mem_map[sub_route.__str__()] = _target_cost
            # 惩罚统计
            _cap_penalty_count = 0  # 累计超限或低限个数
            _time_penalty_count = 0  # 累计超时秒数
            _pickup_delivery_penalty_count = 0  # 累计先取后送违背次数
            _time_cost = 0
            _cap_accu = 0

            for _idx in range(_sub_route_len - 1):
                if sub_route[_idx] == sub_route[_idx + 1]:
                    raise Exception("error", "error")
                if _time_cost < self._data["time_windows"][sub_route[_idx]][0]:
                    _time_penalty_count += self._data["time_windows"][sub_route[_idx]][0] - _time_cost
                _time_cost += self._data["distance_matrix"][sub_route[_idx]][sub_route[_idx + 1]] / self._speed
                if _time_cost > self._data["time_windows"][sub_route[_idx + 1]][1]:
                    _time_penalty_count += _time_cost - self._data["time_windows"][sub_route[_idx + 1]][1]

                _cap_accu += self._data['demands'][sub_route[_idx]]
                if _cap_accu < 0:
                    _cap_penalty_count += -_cap_accu
                elif _cap_accu > self._data['vehicle_capacities']:
                    _cap_penalty_count += _cap_accu - self._data['vehicle_capacities']

            if not b_open_vrp:
                _time_cost += self._data['distance_matrix'][sub_route[-1]][sub_route[0]] / self._speed
                if _time_cost > self._data["time_windows"][sub_route[0]][1]:
                    _time_penalty_count += _time_cost - self._data["time_windows"][sub_route[0]][1]
            for _idx, _node in enumerate(sub_route):
                if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                    _second = self._data["shop_client_map"].get(_node, None)
                    try:
                        _second_idx = sub_route.index(_second)
                    except Exception:
                        _second_idx = -1
                        raise Exception("_sub_route:", sub_route, "_order:", (_node, _second))
                    if _idx > _second_idx:
                        _pickup_delivery_penalty_count += 1
            _cost = _target_cost + (
                    _pickup_delivery_penalty_count * self._pickup_delivery_penalty_ratio + _cap_penalty_count * self._capacity_penalty_ratio + _time_penalty_count * self._time_window_penalty_ratio) * self._penalty_coefficient
            _fitness_value = 1.0 / _cost
            self._cache.fitness_value_sub_route_map[sub_route.__str__()] = _fitness_value
            return _fitness_value  # 只返回适应度值(float)

    def _correct_pickup_and_delivery(self, sub_route: list):
        """
        :param sub_route: 这里sub_route头部有depot，末尾不包括depot
        纠正chromosome的先取后送错误
        :return:
        """
        for _i, _node in enumerate(sub_route):
            if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                _second_node = self._data["shop_client_map"][_node]
                _j = sub_route.index(_second_node)
                # 如果shop的index在client的index之后，则交换节点
                if _i > _j:
                    sub_route[_i], sub_route[_j] = sub_route[_j], sub_route[_i]
        return sub_route

    def _check_feasible(self, solution: Chromosome) -> bool:
        """

        :param route:
        :return:
        """
        if solution.fitness.pd_penalty_count > 0 or solution.fitness.cap_penalty_count > 0:
            return False
        return True

    @DeprecationWarning
    def __solve_with_few_nodes(self):
        """

        :param threshold_node_num: 当节点数少于threshold时，使用穷举算法求解
        :return:
        """

        _all_routes_without_depot = permutations(list(range(1, len(self._data['demands']))))
        _all_solutions = []
        for _route_without_depot in _all_routes_without_depot:
            _route = [0] + list(_route_without_depot)
            _all_solutions.append((_route, self._calc_fit(_route, True)))
        _all_solutions.sort(key=lambda x: x[1])
        for _solution in _all_solutions:
            if self._check_feasible(_solution[0]):
                return _solution[0], _solution[1]
        return False, False

    def _destroy_and_repair(self, route: list, b_open_vrp, target) -> list:
        """

        :param solution:
        :return:
        """
        _split_sub_routes = self._split_route_into_sub_routes(route)
        _choose_nodes: list[list] = []
        # 先选择从每个子路径中提取的节点（对）
        for _sub_route in _split_sub_routes:
            _sub_route_len = len(_sub_route)
            if _sub_route_len == 1:
                _choose_nodes.append([])
            else:
                _random_idx_in_sub_route = random.randint(1, _sub_route_len - 1)
                _choose_node = _sub_route[_random_idx_in_sub_route]
                _choose_node_attr = self._data["nodes_attr_map"].get(_sub_route[_random_idx_in_sub_route], None)
                if _choose_node_attr == self._NodeEnum.PACKAGE:
                    _choose_nodes.append([_choose_node])
                elif _choose_node_attr == self._NodeEnum.SHOP:
                    _choose_nodes.append([_choose_node, self._data["shop_client_map"][_choose_node]])
                elif _choose_node_attr == self._NodeEnum.CLIENT:
                    _choose_nodes.append([self._data["client_shop_map"][_choose_node], _choose_node])
        # 依次插入每一个节点（对），并迭代出适应度最高的路径
        for _i, _insert_nodes in enumerate(_choose_nodes):
            if len(_insert_nodes) == 1:
                _split_sub_routes[_i].remove(_insert_nodes[0])
                _split_sub_routes[_i] = self._insert_to_sub_route(_insert_nodes, _split_sub_routes[_i], b_open_vrp,
                                                                  target)
            else:
                _split_sub_routes[_i].remove(_insert_nodes[1])
                _split_sub_routes[_i].remove(_insert_nodes[0])
                _best_fitness_value = -1
                _best_route: list | None = None
                _best_sub_route_idx = -1
                _best_sub_route: list | None = None
                # 尝试将该节点（对）插入每一个子路径中，找到插入后适应度最高的路径
                for _j in range(len(_split_sub_routes)):
                    _best_inserted_sub_route = self._insert_to_sub_route(_insert_nodes, _split_sub_routes[_j],
                                                                         b_open_vrp, target)

                    _copy_split_sub_routes = copy.deepcopy(_split_sub_routes)
                    _copy_split_sub_routes[_j] = _best_inserted_sub_route
                    _concatenated_route = []
                    for _sub_route in _copy_split_sub_routes:
                        _concatenated_route += _sub_route
                    _fitness = self._calc_fit(_concatenated_route, b_open_vrp, target)
                    if _fitness.fitness_value > _best_fitness_value:
                        _best_fitness_value = _fitness.fitness_value
                        _best_route = _concatenated_route
                        _best_sub_route_idx = _j
                        _best_sub_route = _best_inserted_sub_route
                _split_sub_routes[_best_sub_route_idx] = _best_sub_route
        _concatenated_route = []
        for _sub_route in _split_sub_routes:
            _concatenated_route += _sub_route
        return _concatenated_route

    def _local_search(self, route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> Chromosome:
        """
        局部搜索算法，对每个子route进行局部搜索，找到每个子route的最优邻域解，组合为route
        :param target:
        :param b_open_vrp:
        :param route: 每个子route段只有头部包含depot而尾部不包含depot
        :return:
        """
        _route = self._destroy_and_repair(route, b_open_vrp, target)
        _route = self._loop_2_opt_switch(_route, b_open_vrp, target)

        return self.Chromosome(_route, self._calc_fit(_route, b_open_vrp, target))

    def _loop_2_opt_switch(self, route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> list:
        """
        局部搜索算法，对每个子route进行局部搜索，找到每个子route的最优邻域解，组合为route
        :param target:
        :param open_vrp:
        :param route: 每个子route段只有头部包含depot而尾部不包含depot
        :return:
        """
        _split_routes = self._split_route_into_sub_routes(route)
        _best_route = []
        for _sub_route in _split_routes:
            _best_route += self._local_search_sub_route(_sub_route, b_open_vrp, target)
        return _best_route

    def _local_search_sub_route(self, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> list:
        _best_sub_route: list | None = None
        _best_fitness_value = -1
        _sub_route_len = len(sub_route)
        if _sub_route_len <= 2:
            return sub_route
        for _i in range(1, _sub_route_len - 1):
            for _j in range(_i + 1, _sub_route_len):
                _switched_route = copy.deepcopy(sub_route)
                _switched_route[_i], _switched_route[_j] = _switched_route[_j], _switched_route[_i]
                _switched_route = self._correct_pickup_and_delivery(_switched_route)
                _fitness_value = self._calc_fitness_value_of_sub_route(_switched_route, b_open_vrp, target)
                if _fitness_value > _best_fitness_value:
                    _best_fitness_value = _fitness_value
                    _best_sub_route = _switched_route
        return _best_sub_route

    def _insert_to_sub_route(self, insert_nodes: list, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE):
        """
        将_destropy_and_repair中_choose_nodes中的子元素插入到locao_search后的sub_route中
        即：先执行_local_search_subroute，后对_best_sub_route执行_insert_to_subroute并产生一个_best_sub_route
        :param insert_nodes:
        :param sub_route:
        :param b_open_vrp:
        :param target:
        :return:
        """
        _best_sub_route: list | None = None
        _best_fitness_value = -1
        _sub_route_len = len(sub_route)
        if len(insert_nodes) == 1:
            for _i in range(1, _sub_route_len + 1):
                _inserted_sub_route = copy.deepcopy(sub_route)
                _inserted_sub_route.insert(_i, insert_nodes[0])
                _fitness_value = self._calc_fitness_value_of_sub_route(_inserted_sub_route, b_open_vrp, target)
                if _fitness_value > _best_fitness_value:
                    _best_fitness_value = _fitness_value
                    _best_sub_route = _inserted_sub_route
        else:
            for _j in range(1, _sub_route_len + 1):
                for _i in range(1, _j + 1):
                    _inserted_sub_route = copy.deepcopy(sub_route)
                    _inserted_sub_route.insert(_j, insert_nodes[1])
                    _inserted_sub_route.insert(_i, insert_nodes[0])
                    _fitness_value = self._calc_fitness_value_of_sub_route(_inserted_sub_route, b_open_vrp, target)
                    if _fitness_value > _best_fitness_value:
                        _best_fitness_value = _fitness_value
                        _best_sub_route = _inserted_sub_route
        return _best_sub_route

    def _annealing(self, temp, current_solution: Chromosome, new_solution: Chromosome) -> Chromosome:
        _delta_E = new_solution.fitness.fitness_value - current_solution.fitness.fitness_value
        if _delta_E > 0:
            return new_solution
        _prob = math.exp(_delta_E / temp)
        if _prob > random.random():
            return new_solution
        else:
            return current_solution

    def solve_vrp(self, time_graph, pickups_deliveries, time_windows, demands, depot, binding, num_vehicles, capacity,
                  distance_matrix, service_time, b_return_iter_cost=False):
        """

        :return:
        """
        # TODO: 加入输入上一轮解，以此通过启发式方法，将新订单的两个节点插入上一轮的解中，生成初始解
        _time_0 = time()
        _iter_record = []  # 用于存储每轮迭代后的best_solution的cost
        _iter_without_penalty_record = []  # 用于存储每轮迭代后的best_solution的cost（忽略penalty）
        _iter_chromosome_record: list[SA.Chromosome] = []  # 用于存储每轮迭代的染色体（包含适应度）
        self.create_data_model(time_graph, pickups_deliveries, time_windows, demands, depot, binding, num_vehicles,
                               capacity, distance_matrix, service_time)
        _current_temp = self._init_temp
        _best_solution = self._gen_init_sol()
        _solution = copy.deepcopy(_best_solution)
        self._terminate_fitness_equal_count = 0
        for _ in range(self._iteration_num):
            _new_solution = self._local_search(_solution.route, self._b_open_vrp, self._target)
            _solution = self._annealing(_current_temp, _solution, _new_solution)
            if _solution.fitness.fitness_value > _best_solution.fitness.fitness_value:
                _best_solution = _solution
            _current_temp = self._annealing_rate * _current_temp

            if self.__b_debug_info_print:
                print("\n_best_solution:", _best_solution.route, " fitness:",
                      _best_solution.fitness.fitness_value.__round__(6),
                      " real_value:", _best_solution.fitness.real_value.__round__(2),
                      "\n_curt_solution:", _solution.route, " fitness:", _solution.fitness.fitness_value.__round__(6),
                      " real_value:", _solution.fitness.real_value.__round__(2))
            # # debug
            self.__iter_count+=1
            print(self.__iter_count,"\n_best_solution:", _best_solution.route, " fitness:",
                  _best_solution.fitness.fitness_value.__round__(6),
                  " real_value:", _best_solution.fitness.real_value.__round__(2), " fatal?penalty?:",
                  _best_solution.fitness.b_have_fatal_penalty, _best_solution.fitness.b_have_penalty, "t_p_count:",
                  _best_solution.fitness.tw_penalty_count.__round__(2), "s",
                  "\n_curt_solution:", _solution.route, " fitness:", _solution.fitness.fitness_value.__round__(6),
                  " real_value:", _solution.fitness.real_value.__round__(2), " fatal?penalty?:",
                  _solution.fitness.b_have_fatal_penalty, _solution.fitness.b_have_penalty, "t_p_count:",
                  _solution.fitness.tw_penalty_count.__round__(2), "s", "\ttime:", time() - _time_0)  # debug
            if b_return_iter_cost:
                _iter_record.append(int(1 / _best_solution.fitness.fitness_value))
                _iter_without_penalty_record.append(_best_solution.fitness.real_value)
        if self.__b_debug_info_print:
            print("result:", _best_solution.route, _best_solution.fitness.fitness_value,
                  _best_solution.fitness.real_value)

        if b_return_iter_cost:
            self.clean_cache()
            # return _best_solution.route, int(
            #     1 / _best_solution.fitness.fitness_value), _iter_record, _iter_without_penalty_record
            return _iter_chromosome_record
        if self._check_feasible(_best_solution):
            self.clean_cache()
            return _best_solution.route, int(1 / _best_solution.fitness.fitness_value)
        else:
            self.clean_cache()
            return False

    def _perfect_print(self, route):
        """
        将route转换为depot为负值的route，仅用作打印
        :param route:
        :return:
        """
        _route_for_print = []
        for _i in range(len(route)):
            _route_for_print.append(route[_i] - self._data["num_vehicles"] + 1)
        return _route_for_print

    def _check_order_in_same_sub_route(self, route):
        """

        :param route:
        :return:
        """
        return
        _bit_list = [0] * 107
        for _node in route:
            _bit_list[_node] += 1
            if _node != 0 and _bit_list[_node] > 1:
                _split_routes = self._split_route_into_sub_routes(route, True)
                raise Exception("len(route):", len(route), "_split_routes:", _split_routes, "repeated node:", _node)

        if len(route) != 116:
            raise Exception("len(route):", len(route))
        _split_routes = self._split_route_into_sub_routes(route, True)
        for _sub_route in _split_routes:
            for _node in _sub_route:
                if _node in self._data["shop_nodes"]:
                    _second = None
                    for _order in self._data["pickups_deliveries"]:
                        if _node == _order[0]:
                            _second = _order[1]
                            break
                    try:
                        _second_idx = _sub_route.index(_second)
                    except Exception:
                        _second_idx = -1
                        raise Exception("_sub_route:", _sub_route, "_order:", (_node, _second), "\n", "_split_routes:",
                                        _split_routes)

    def clean_cache(self):
        """
        求解结束后，清空运算缓存
        :return:
        """
        self._cache.clean()
        self._data = {}


if __name__ == '__main__':
    conv = Converter(instance_id=6)
    data = conv.data

    time1 = time()
    SA = SA(seed=222, population=1000, niche_num=10, terminate_by_fitness_equal=False, open_vrp=False,
            target=SA.TargetEnum.TIME,
            debug_info=False)

    SA.solve_vrp(data["time_matrix"], data["pickups_deliveries"], data["time_windows"], data["demands"], data["depot"],
                 data["binding"], data["num_vehicles"], data["vehicle_capacities"], data["distance_matrix"],
                 data["service_time"])

    print("time:", time() - time1)
