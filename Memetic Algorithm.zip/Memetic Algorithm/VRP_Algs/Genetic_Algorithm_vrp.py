from Memetic_Algorithm_vrp import *


# 采用罚函数解决VRP的三种限制
# 采用pickup and delivery纠正算子，加快求解收敛速度
# 采用轮盘赌算法，适应度越高的染色体交叉遗传的概率越大
# 采用(逆序+位移+)2opt算子的变异算法，保持解的多样性，加快跳出局部最优解
# 采用动态调整cross over概率和mutation概率，平衡“保留精英”和跳出局部最优
# multi-depot、nodes-binding


# 部分规定：
# 1.运算过程中，所有chromosome指带有fitness的route，即 chromosome=[route,fitness]，solution同chromosome
# 2.运算过程中，无论openvrp与否，存储于变量中的route、subroute列表，都只有头部带有depot而尾部不带有depot


if __name__ == '__main__':
    conv = Converter(instance_id=1)
    data = conv.data

    time1 = time()
    GA = MA(seed=123,population=1000,niche_num=1, terminate_by_fitness_equal=False, open_vrp=False, target=MA.TargetEnum.TIME,
            debug_info=False)
    GA.change_parameters(need_correct_pickup_delivery=True, shift_cross_and_mutation_on=False,
                         dynamic_probability=False,
                         iter_time=200, niche_num=1,is_ga=True)
    # GA.create_data_model(graph, pickups_deliveries, time_windows, demands)
    # GA.gen_init_sol()
    # # for i in GA.sol_list:
    # #     print(i)
    # parents = GA.rou_wheel_sel(50)
    # for p in parents:
    #     print("cross_over:", GA.cross_over(p))

    GA.solve_vrp(data["time_matrix"], data["pickups_deliveries"], data["time_windows"], data["demands"], data["depot"],
                 data["binding"], data["num_vehicles"], data["vehicle_capacities"], data["distance_matrix"],
                 data["service_time"])

    print("time:", time() - time1)
