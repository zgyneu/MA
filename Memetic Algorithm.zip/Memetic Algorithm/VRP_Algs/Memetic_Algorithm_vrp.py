import math
import random
from time import time
from itertools import permutations
import gc

from Utils.Convert_Node_Graph_into_Graph import *


# 采用罚函数解决VRP的三种限制
# 采用pickup and delivery纠正算子，加快求解收敛速度
# 采用轮盘赌算法，适应度越高的染色体交叉遗传的概率越大
# 采用(逆序+位移+)2opt算子的变异算法，保持解的多样性，加快跳出局部最优解
# 采用动态调整cross over概率和mutation概率，平衡“保留精英”和跳出局部最优
# multi-depot、nodes-binding


# 部分规定：
# 1.运算过程中，所有chromosome指带有fitness的route，即 chromosome=[route,fitness]，solution同chromosome
# 2.运算过程中，无论openvrp与否，存储于变量中的route、subroute列表，都只有头部带有depot而尾部不带有depot

class MA:
    class _NodeEnum(Enum):
        SHOP = 1
        CLIENT = 2
        PACKAGE = 3
        DEPOT = 4

    class TargetEnum(Enum):
        """
        目标函数Enum：
            1.最少Client、Package节点等待时间（从该订单产生到订单完成的总时间）
            2.最少总行驶距离（所有骑手）
        """
        TIME = 1
        DISTANCE = 2

    class _Cache:
        def __init__(self):
            self.fitness_mem_map = {}  # 缓存 路径(.__str__())->适应度
            self.cost_without_penalty_mem_map = {}  # 缓存 路径(.__str__())->路径花费
            self.local_search_map = {}  # 缓存 路径(.__str__())->chromosome (local_search结果)
            self.fitness_value_sub_route_map = {}  # 缓存 子路径(.__str__())->适应度值(float)
            self.local_search_save_all_map = {}  # 缓存 路径(.__str__())->所有邻域解的列表 (local_search结果)
            self.route_to_sub_routes_map = {}  # 缓存 路径(.__str__())->对应的子路径列表
            self.hamming_distance_map = {}  # 缓存 路径(.__str__())->完整路径对应的汉明码距离
            self.hamming_of_sub_route_map = {}  # 缓存 子路径(.__str__())->子路径对应的汉明码距离
            self.new_orders_nodes_map = {}  # 缓存 节点是否为新订单的节点， node_num -> True/False

        def clean(self):
            del self.fitness_mem_map
            gc.collect()
            self.fitness_mem_map = {}
            del self.cost_without_penalty_mem_map
            gc.collect()
            self.cost_without_penalty_mem_map = {}
            del self.local_search_map
            gc.collect()
            self.local_search_map = {}
            del self.fitness_value_sub_route_map
            gc.collect()
            self.fitness_value_sub_route_map = {}
            del self.local_search_save_all_map
            gc.collect()
            self.local_search_save_all_map = {}
            del self.route_to_sub_routes_map
            gc.collect()
            self.route_to_sub_routes_map = {}
            del self.hamming_distance_map
            gc.collect()
            self.hamming_distance_map = {}
            del self.hamming_of_sub_route_map
            del self.new_orders_nodes_map
            gc.collect()
            self.hamming_of_sub_route_map = {}
            self.new_orders_nodes_map = {}

    class Chromosome:
        """
        染色体类，包含route和相应的fitness，即 chromosome=[route,_Fitness]
        """

        class Fitness:
            """
            适应度类，给入等待时间或行驶路程（不需要求倒数）和各种惩罚的计数
            """

            def __init__(self, fitness_value: float, real_value: float, pd_penalty_count: int, cap_penalty_count: int,
                         tw_penalty_count: float):
                """
                初始化适应度类
                :param fitness_value: 1/(real_value+penalties_value)
                :param real_value: 等待时间或行驶路程（不需要求倒数）
                :param pd_penalty_count: 取送顺序错误计数
                :param cap_penalty_count: 容量超限（上、下限）计数
                :param tw_penalty_count: 时间窗超出计数
                """
                self.tw_penalty_count = tw_penalty_count
                self.cap_penalty_count = cap_penalty_count
                self.pd_penalty_count = pd_penalty_count
                self.fitness_value = fitness_value
                self.real_value = real_value
                # 如果个体含有 取送惩罚 或 容量惩罚，则有严重惩罚
                self.b_have_fatal_penalty = True if (cap_penalty_count != 0 or pd_penalty_count) != 0 else False
                # 如果个体没有严重惩罚，但有时间窗惩罚，则有普通惩罚
                self.b_have_penalty = True if \
                    (tw_penalty_count != 0 and not self.b_have_fatal_penalty) else False

        def __init__(self, route: list, fitness: Fitness):
            self.route = route
            self.fitness = fitness

    def _calc_fitness_value(self, real_value: float, pd_penalty_count: int, cap_penalty_count: int,
                            tw_penalty_count: float) -> Chromosome.Fitness:
        """
        通过给入等待时间或行驶路程，计算适应度值，fitness_value=1/(real_value+penalties_value)
        :param real_value: 等待时间或行驶路程（不需要求倒数）
        :return:
        """
        _fitness_value = 1.0 / (real_value + (self._capacity_penalty_ratio * cap_penalty_count +
                                              self._time_window_penalty_ratio * tw_penalty_count +
                                              self._pickup_delivery_penalty_ratio * pd_penalty_count)
                                * self._penalty_coefficient)
        return self.Chromosome.Fitness(_fitness_value, real_value, pd_penalty_count, cap_penalty_count,
                                       tw_penalty_count)

    def __init__(self, seed=123, population=1000, iter_time=1000, penalty_coefficient=100000, niche_num=1,
                 terminate_by_fitness_equal=True,
                 open_vrp: bool = True, target=TargetEnum.DISTANCE, speed=1, debug_info=False,
                 allow_orders_to_be_reassigned=True):
        self._data = {}
        self._speed = speed
        random.seed(seed)
        self._cache = self._Cache()
        self._choose_top_percent = 0.01
        self._cross_over_prob = 0.79  # 0.2
        self._mut_prob = 0.1  # 0.15
        self._local_search_prob = 0.1  # 0.4
        self._generation_num = iter_time  # 迭代代数
        self._population_size = population
        self._nodes_len = -1
        self._terminate_fitness_equal_time = 50
        self._b_terminate_by_fitness_equal = terminate_by_fitness_equal
        self._penalty_coefficient = penalty_coefficient  # 罚系数, 1尽可能大
        self._pickup_delivery_penalty_ratio = 5000  # 取送顺序罚倍率
        self._time_window_penalty_ratio = 1  # 每超时1秒的罚倍率
        self._capacity_penalty_ratio = 10000  # 每超限或低限1个的罚倍率
        self._need_correct_pickup_delivery = True

        self.__crossover_equal_count = 0
        self._terminate_fitness_equal_count = 0  # 迭代过程中，最优解相等次数计数器
        self._shift_cross_and_mutation_on = False
        self._dynamic_probability = True  # 动态调整概率
        self._b_open_vrp = open_vrp  # open_vrp最后少一步计算，即最后一个路径节点返回depot的开销
        self._target = target  # 目标函数：总时间最少或总路径最短
        self._num_of_niches = niche_num  # 小生境数量
        self._allow_orders_to_be_reassigned = allow_orders_to_be_reassigned  # 是否允许旧的未取餐订单二次分配

        self.__b_debug_info_print = debug_info

    def change_parameters(self, need_correct_pickup_delivery=True, shift_cross_and_mutation_on=True,
                          dynamic_probability=True, iter_time=1000, niche_num=3, is_ga=False):
        """

        :return:
        """
        self._need_correct_pickup_delivery = need_correct_pickup_delivery
        self._shift_cross_and_mutation_on = shift_cross_and_mutation_on
        self._dynamic_probability = dynamic_probability
        self._generation_num = iter_time
        self._num_of_niches = niche_num
        if is_ga:
            self._cross_over_prob += self._local_search_prob
            self._local_search_prob = 0

    def create_data_model(self, graph, pickups_deliveries, time_windows, demands: list, depot: list, binding,
                          num_vehicles, capacity=3, distance_matrix=None, service_time=None, new_orders_nodes=None,
                          dispatched_orders_nodes=None):
        """Stores the data for the problem.写入时，车辆节点从负数开始一直到0（包含0），路径节点从1开始"""
        self._data["time_matrix"] = graph  # matrix 注意：起对角线元素、第一列元素COST均为0
        self._data["distance_matrix"] = distance_matrix  # 用于instance算法对比，matrix不包含service_time
        self._data["pickups_deliveries"] = pickups_deliveries  # 二维list，内层维度分别为shop和client,形如：[[3, 1], [4, 2],]
        self._data["time_windows"] = time_windows  # list，内层为tuple，分别是0和time_remain
        # 形如：[
        #     (0, 5),  # depot
        #     (0, 10),  # 1
        #     (0, 500),  # 2
        #     (0, 5),  # 3
        #      ]
        self._data["demands"] = demands  # 形如：[1, -1, -1, 1]
        self._data["vehicle_capacities"] = capacity  # 容量限制，形如 3
        self._data["depot"] = depot  # 形如： [0,1,2,3]，对应原始depot[-4,-3,-2,-1]，或[0,0,0,0]，对应原始depot[0,0,0,0]
        self._data["binding"] = binding  # 形如：[[],[5,7],[10],[]]，即共4辆车，5,7绑定-3号车，10绑定-2号车
        self._data["new_orders_nodes"] = new_orders_nodes  # 形如：[[3,4],[5,6]]，即这些订单是新订单（每个订单2个节点）
        self._data[
            "dispatched_orders_nodes"] = dispatched_orders_nodes  # 所有已分配的订单节点，不算绑定节点（已取餐），形如：[[],[[5,7]],[[6,8],[9,10]],[]]，即共4辆车，[[5,7]]绑定-3号车，[[6,8],[9,10]],绑定-2号车
        self._data["num_vehicles"] = num_vehicles
        self._nodes_len = len(graph[0])
        self._data["shop_nodes"] = []
        self._data["client_nodes"] = []
        self._data["package_nodes"] = []
        self._data["service_time"] = service_time  # 形如：[10,20,...]
        if num_vehicles > 1:
            # 当num_vehicles>1，更新self._data["pickups_deliveries"]内节点和self._data["binding"]内节点的序号为当前序号+车辆数量-1
            for _i in range(len(self._data["pickups_deliveries"])):
                self._data["pickups_deliveries"][_i][0] += num_vehicles - 1
                self._data["pickups_deliveries"][_i][1] += num_vehicles - 1

            for _i in range(len(self._data["new_orders_nodes"])):
                self._data["new_orders_nodes"][_i][0] += num_vehicles - 1
                self._data["new_orders_nodes"][_i][1] += num_vehicles - 1
                self._cache.new_orders_nodes_map[self._data["new_orders_nodes"][_i][0]] = True
                self._cache.new_orders_nodes_map[self._data["new_orders_nodes"][_i][1]] = True

            for _v in range(num_vehicles):
                for _j in range(len(self._data["binding"][_v])):
                    self._data["binding"][_v][_j] += num_vehicles - 1
                for _j in range(len(self._data["dispatched_orders_nodes"][_v])):
                    for _k in range(len(self._data["dispatched_orders_nodes"][_v][_j])):
                        self._data["dispatched_orders_nodes"][_v][_j][_k] += num_vehicles - 1
        self._data["shop_client_map"] = {}  # 用于快速找出shop对应的client
        self._data["client_shop_map"] = {}  # 用于快速找出client对应的shop
        self._data["binding_node_to_vehicle_id_map"] = {}  # 用于快速找出package对应绑定的vehicle id
        for _pickup_node, _delivery_node in pickups_deliveries:
            self._data["shop_nodes"].append(_pickup_node)
            self._data["client_nodes"].append(_delivery_node)
            self._data["shop_client_map"][_pickup_node] = _delivery_node
            self._data["client_shop_map"][_delivery_node] = _pickup_node
        for _i, _vehicle_binding in enumerate(binding):
            for _package in _vehicle_binding:
                self._data["package_nodes"].append(_package)
                self._data["binding_node_to_vehicle_id_map"][_package] = _i
        self._data["nodes_attr_map"]: dict = {}  # 用于快速判断节点是什么类型，值共四种："depot","shop"、"client"、"package"
        for _node in self._data["shop_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.SHOP
        for _node in self._data["client_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.CLIENT
        for _node in self._data["package_nodes"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.PACKAGE
        for _node in self._data["depot"]:
            self._data["nodes_attr_map"][_node] = self._NodeEnum.DEPOT

    def _gen_init_sol(self) -> list[Chromosome]:
        """产生初始解"""
        _init_population = []
        for _ in range(self._population_size):
            _route = []
            # 针对每个骑手，分配一条子路径
            for _depot in self._data["depot"]:
                _sub_route = [_depot]
                _route.append(_sub_route)
            _sub_route_len = len(_route)
            if self._allow_orders_to_be_reassigned:
                # 先将所有pd对随机分配给所有骑手，注意：client节点在shop节点之后
                for _shop_node, _client_node in self._data["pickups_deliveries"]:
                    _random_choose_sub_route_idx = random.randint(0, _sub_route_len - 1)
                    _random_client_insert_idx = random.randint(1, len(_route[_random_choose_sub_route_idx]))
                    _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
                    _route[_random_choose_sub_route_idx].insert(_random_client_insert_idx, _client_node)
                    _route[_random_choose_sub_route_idx].insert(_random_shop_insert_idx, _shop_node)
            else:  # 不允许二次分配，之前分配给某个骑手的订单，依然要分配到该骑手下
                # 先插入dispatched订单节点到对应的骑手
                for _sub_route_index, _orders_nodes_list in enumerate(self._data["dispatched_orders_nodes"]):
                    for _orders_nodes in _orders_nodes_list:
                        _shop_node, _client_node = _orders_nodes
                        _random_client_insert_idx = random.randint(1, len(_route[_sub_route_index]))
                        _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
                        _route[_sub_route_index].insert(_random_client_insert_idx, _client_node)
                        _route[_sub_route_index].insert(_random_shop_insert_idx, _shop_node)
                # 后插入该时间隙的新订单节点到随机骑手
                for _shop_node, _client_node in self._data["new_orders_nodes"]:
                    _random_choose_sub_route_idx = random.randint(0, _sub_route_len - 1)
                    _random_client_insert_idx = random.randint(1, len(_route[_random_choose_sub_route_idx]))
                    _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
                    _route[_random_choose_sub_route_idx].insert(_random_client_insert_idx, _client_node)
                    _route[_random_choose_sub_route_idx].insert(_random_shop_insert_idx, _shop_node)

            # 将所有binding节点分配给对应骑手，随机插入各子路径
            for _i, _vehicle_binding in enumerate(self._data["binding"]):
                for _binding_node in _vehicle_binding:
                    _random_insert_idx = random.randint(1, len(_route[_i]))
                    _route[_i].insert(_random_insert_idx, _binding_node)
            _concatenated_route = []
            # 子路径首尾连接
            for _sub_route in _route:
                _sub_route = self._correct_pickup_and_delivery(_sub_route)
                _concatenated_route += _sub_route
            # 种群存入每一个chromosome个体
            _init_population.append(self.Chromosome(_concatenated_route,
                                                    self._calc_fit(_concatenated_route, self._b_open_vrp,
                                                                   target=self._target)))
        if self.__b_debug_info_print:
            for _chromosome in _init_population:
                self._check_order_in_same_sub_route(_chromosome.route)
        # 返回种群
        return _init_population

    def _split_route_into_sub_routes(self, route: list) -> list[list]:
        """
        将长路径转换为子路径组成的列表，route总按头部为depot而末尾不包含depot
        :return:
        """
        _split_routes = self._cache.route_to_sub_routes_map.get(route.__str__(), [])
        if _split_routes:
            _split_routes_copy = copy.deepcopy(_split_routes)
            return _split_routes_copy
        _split_index = 0
        _routes_len = len(route)
        for _i, _node in enumerate(route):
            if _i == 0:
                continue
            if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.DEPOT:
                _split_routes.append(route[_split_index:_i])
                _split_index = _i
            if _i == (_routes_len - 1):
                _split_routes.append(route[_split_index:])
                _split_routes_copy = copy.deepcopy(_split_routes)
                self._cache.route_to_sub_routes_map[route.__str__()] = _split_routes_copy
                return _split_routes

    def _calc_fit(self, route, b_open_vrp=True, target=TargetEnum.DISTANCE) -> Chromosome.Fitness:
        """

        :param target: 针对benchmark的对比，只比较路线总长度，不计算服务时间等（服务时间只用作tw约束）
        :param route: 列表
        :param b_open_vrp: 路径是否在最后插入depot，即车辆是否需要返回depot
        :return:
        """
        # 首先，根据depot分割route
        _fitness = self._cache.fitness_mem_map.get(route.__str__(), None)
        if _fitness:
            return _fitness
        _split_routes = self._split_route_into_sub_routes(route)
        if target == self.TargetEnum.DISTANCE or target == self.TargetEnum.TIME:
            _target_cost = 0
            # 循环计算各子route的cost，对于 for_total_distance，只cost就是所有route的总距离（不包括服务时间）
            if target == self.TargetEnum.DISTANCE:  # 适应度：路径总距离
                for _sub_route in _split_routes:
                    # 缓存子路径计算结果（单纯距离不含惩罚）
                    _sub_distance_cost = self._cache.cost_without_penalty_mem_map.get(_sub_route.__str__(), -1)
                    if _sub_distance_cost != -1:
                        _target_cost += _sub_distance_cost
                        continue
                    else:
                        _sub_route_len = len(_sub_route)
                        if _sub_route_len == 1:
                            continue
                        _sub_distance_cost = 0
                        # 计算子route的纯路径距离
                        for _idx in range(_sub_route_len - 1):
                            _sub_distance_cost += self._data["distance_matrix"][_sub_route[_idx]][_sub_route[_idx + 1]]
                        # 如果非开放vrp，则需要返回depot
                        if not b_open_vrp:
                            _sub_distance_cost += self._data["distance_matrix"][_sub_route[-1]][_sub_route[0]]
                        self._cache.cost_without_penalty_mem_map[_sub_route.__str__()] = _sub_distance_cost
                        _target_cost += _sub_distance_cost

            # 循环计算各子route的cost，对于 for_total_distance，只cost就是所有route的总距离（不包括服务时间），且不存在openvrp的区别
            elif target == self.TargetEnum.TIME:
                for _sub_route in _split_routes:
                    # 缓存子路径计算结果（单纯所有客户、包裹节点花费时间不含惩罚）
                    _sub_time_cost = self._cache.cost_without_penalty_mem_map.get(_sub_route.__str__(), -1)
                    if _sub_time_cost != -1:
                        _target_cost += _sub_time_cost
                        continue
                    else:
                        _sub_route_len = len(_sub_route)
                        if _sub_route_len == 1:
                            continue
                        _sub_time_cost = 0
                        _accumulate_time_cost = self._data["service_time"][_sub_route[0]]  # 用于累积子路径的时间花费
                        # 计算子route的纯时间消耗（各客户、包裹节点花费时间）
                        for _idx in range(_sub_route_len - 1):
                            _accumulate_time_cost += self._data["distance_matrix"][_sub_route[_idx]][
                                                         _sub_route[_idx + 1]] / self._speed + \
                                                     self._data["service_time"][_sub_route[_idx + 1]]
                            if self._data["nodes_attr_map"].get(_sub_route[_idx + 1], None) == self._NodeEnum.CLIENT or \
                                    self._data["nodes_attr_map"].get(_sub_route[_idx + 1],
                                                                     None) == self._NodeEnum.PACKAGE:
                                _sub_time_cost += _accumulate_time_cost
                        self._cache.cost_without_penalty_mem_map[_sub_route.__str__()] = _sub_time_cost
                        _target_cost += _sub_time_cost
            # 惩罚统计
            _cap_penalty_count = 0  # 累计超限或低限个数
            _time_penalty_count = 0  # 累计超时秒数
            _pickup_delivery_penalty_count = 0  # 累计先取后送违背次数
            for _sub_route in _split_routes:
                _sub_time_cost = 0
                _sub_cap_accu = 0
                _sub_route_len = len(_sub_route)
                if _sub_route_len == 1:
                    continue
                for _idx in range(_sub_route_len - 1):
                    if _sub_route[_idx] == _sub_route[_idx + 1]:
                        print("route:", route)
                        print("_sub_route[_idx]:", _sub_route[_idx])
                        print("_split_routes:", _split_routes)
                        raise Exception("error", "error")
                    # 计算时间窗惩罚
                    if _sub_time_cost < self._data["time_windows"][_sub_route[_idx]][0]:
                        _time_penalty_count += self._data["time_windows"][_sub_route[_idx]][0] - _sub_time_cost
                    _sub_time_cost += self._data['distance_matrix'][_sub_route[_idx]][
                                          _sub_route[_idx + 1]] / self._speed
                    if _sub_time_cost > self._data["time_windows"][_sub_route[_idx + 1]][1]:
                        _time_penalty_count += _sub_time_cost - self._data["time_windows"][_sub_route[_idx + 1]][1]
                    _sub_time_cost += self._data["service_time"][_sub_route[_idx + 1]]
                    # 计算容量惩罚
                    _sub_cap_accu += self._data['demands'][_sub_route[_idx]]
                    if _sub_cap_accu < 0:
                        _cap_penalty_count += -_sub_cap_accu
                    elif _sub_cap_accu > self._data['vehicle_capacities']:
                        _cap_penalty_count += _sub_cap_accu - self._data['vehicle_capacities']
                # 非openvrp，补充回depot的时间窗惩罚检测
                if not b_open_vrp:
                    _sub_time_cost += self._data['distance_matrix'][_sub_route[-1]][_sub_route[0]] / self._speed
                    if _sub_time_cost > self._data["time_windows"][_sub_route[0]][1]:
                        _time_penalty_count += _sub_time_cost - self._data["time_windows"][_sub_route[0]][1]

                # 计算先取后送惩罚
                for _idx, _node in enumerate(_sub_route):
                    if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                        _second = self._data["shop_client_map"].get(_node, None)
                        try:
                            _second_idx = _sub_route.index(_second)
                        except Exception:
                            _second_idx = -1
                            raise Exception("_sub_route:", _sub_route, "_order:", (_node, _second), "\n",
                                            "_split_routes:", _split_routes)
                        if _idx > _second_idx:
                            _pickup_delivery_penalty_count += 1

            _fitness: MA.Chromosome.Fitness = self._calc_fitness_value(real_value=_target_cost,
                                                                       pd_penalty_count=_pickup_delivery_penalty_count,
                                                                       cap_penalty_count=_cap_penalty_count,
                                                                       tw_penalty_count=_time_penalty_count)
            self._cache.fitness_mem_map[route.__str__()] = _fitness
            return _fitness  # self._Chromosome.Fitness类

    def _cal_hamming_distance(self, chrome_1: Chromosome, chrome_2: Chromosome):
        """

        :return:
        """
        _hamming_distance = self._cache.hamming_distance_map.get(chrome_1.route.__str__() + chrome_2.route.__str__(),
                                                                 -1)
        if _hamming_distance != -1:
            return _hamming_distance
        _hamming_distance = 0
        _split_routes_one = self._cache.route_to_sub_routes_map[chrome_1.route.__str__()]
        _split_routes_two = self._cache.route_to_sub_routes_map[chrome_2.route.__str__()]

        for _i in range(len(_split_routes_one)):
            _len_sub_route_one = len(_split_routes_one[_i])
            _len_sub_route_two = len(_split_routes_two[_i])
            _hamming_distance += abs(_len_sub_route_one - _len_sub_route_two)
            for _j in range(1, min(_len_sub_route_one, _len_sub_route_two)):
                if _split_routes_one[_i][_j] != _split_routes_two[_i][_j]:
                    _hamming_distance += 1

        self._cache.hamming_distance_map[chrome_1.route.__str__() + chrome_2.route.__str__()] = _hamming_distance
        self._cache.hamming_distance_map[chrome_2.route.__str__() + chrome_1.route.__str__()] = _hamming_distance
        return _hamming_distance

    @staticmethod
    def _rou_wheel_sel(n, population: list[Chromosome]) -> list[tuple[int, int]]:
        """
        轮盘赌，选择双亲
        :param population:
        :param n: 轮盘赌旋转次数
        """
        wheel = []  # 轮盘，每两个元素区间为
        choose_parents: list[tuple[int, int]] | list = []  # 每个元素为二元组，即所选择的双亲，元素总数为n
        total_fitness = 0
        for _solution in population:
            total_fitness += _solution.fitness.fitness_value
            wheel.append(total_fitness)
        for _i in range(n):
            _parent_one_randint = random.random() * total_fitness
            _parent_two_randint = (_parent_one_randint + total_fitness / 2) % total_fitness  # 每次轮盘赌，同时选择出双亲
            _parent_one_idx = -1
            _parent_two_idx = -1
            if _parent_one_randint <= wheel[0]:
                _parent_one_idx = 0
            if _parent_two_randint <= wheel[0]:
                _parent_two_idx = 0
            for _idx in range(len(wheel) - 1):
                if _parent_one_idx == -1 and wheel[_idx] < _parent_one_randint <= wheel[_idx + 1]:
                    _parent_one_idx = _idx + 1
                if _parent_two_idx == -1 and wheel[_idx] < _parent_two_randint <= wheel[_idx + 1]:
                    _parent_two_idx = _idx + 1
                if _parent_one_idx != -1 and _parent_two_idx != -1:
                    choose_parents.append((_parent_one_idx, _parent_two_idx))
                    break
        return choose_parents

    def _mutation_2_opt(self, route: list) -> list:
        """
        2-opt算法，执行变异过程：选取两个不同骑手，随机对换若干订单
        :param route:
        :return:
        """
        # 划分路径为各子路径
        _split_routes: list[list] = self._split_route_into_sub_routes(route)
        _sub_route_len = len(_split_routes)
        _random_sub_route_one_idx = random.randint(0, _sub_route_len - 1)  # 随机选第一个骑手
        _random_sub_route_two_idx = random.randint(0, _sub_route_len - 1)  # 随机选第二个骑手
        while _random_sub_route_one_idx == _random_sub_route_two_idx:
            _random_sub_route_two_idx = random.randint(0, _sub_route_len - 1)
        # 先从第一个骑手选择变异基因（订单节点对）
        # 先提取第一个骑手所有订单对
        _extract_orders_from_one = []  # [[1,2],[3,4],...]
        _extract_orders_from_one_indices = []  # [[1,2],[3,4],...]  从第1个骑手提取的订单的[两个节点的索引]
        if self._allow_orders_to_be_reassigned:  # 默认允许订单二次分配
            for _i, _node in enumerate(_split_routes[_random_sub_route_one_idx]):
                if self._data["nodes_attr_map"].get(_node,
                                                    None) == self._NodeEnum.SHOP:
                    _second_node = self._data["shop_client_map"][_node]
                    _extract_orders_from_one.append([_node, _second_node])
                    try:
                        _j = _split_routes[_random_sub_route_one_idx].index(_second_node)
                    except Exception:
                        _j = -1
                        raise Exception("error", "error")
                    _extract_orders_from_one_indices.append([_i, _j])
            # 再提取第二个骑手所有订单对
            _extract_orders_from_two = []  # [[1,2],[3,4],...]
            _extract_orders_from_two_indices = []  # [[1,2],[3,4],...]  从第2个骑手提取的订单的[两个节点的索引]
            for _i, _node in enumerate(_split_routes[_random_sub_route_two_idx]):
                if self._data["nodes_attr_map"].get(_node,
                                                    None) == self._NodeEnum.SHOP:
                    _second_node = self._data["shop_client_map"][_node]
                    _extract_orders_from_two.append([_node, _second_node])
                    try:
                        _j = _split_routes[_random_sub_route_two_idx].index(_second_node)
                    except Exception:
                        _j = -1
                        raise Exception("error", "error")
                    _extract_orders_from_two_indices.append([_i, _j])
        else:  # 不允许非新订单二次分配
            for _i, _node in enumerate(_split_routes[_random_sub_route_one_idx]):
                if self._data["nodes_attr_map"].get(_node,
                                                    None) == self._NodeEnum.SHOP and self._cache.new_orders_nodes_map.get(
                        _node, False):
                    _second_node = self._data["shop_client_map"][_node]
                    _extract_orders_from_one.append([_node, _second_node])
                    try:
                        _j = _split_routes[_random_sub_route_one_idx].index(_second_node)
                    except Exception:
                        _j = -1
                        raise Exception("error", "error")
                    _extract_orders_from_one_indices.append([_i, _j])
            # 再提取第二个骑手所有订单对
            _extract_orders_from_two = []  # [[1,2],[3,4],...]
            _extract_orders_from_two_indices = []  # [[1,2],[3,4],...]  从第2个骑手提取的订单的[两个节点的索引]
            for _i, _node in enumerate(_split_routes[_random_sub_route_two_idx]):
                if self._data["nodes_attr_map"].get(_node,
                                                    None) == self._NodeEnum.SHOP and self._cache.new_orders_nodes_map.get(
                        _node, False):
                    _second_node = self._data["shop_client_map"][_node]
                    _extract_orders_from_two.append([_node, _second_node])
                    try:
                        _j = _split_routes[_random_sub_route_two_idx].index(_second_node)
                    except Exception:
                        _j = -1
                        raise Exception("error", "error")
                    _extract_orders_from_two_indices.append([_i, _j])

        _extract_orders_from_one_len = len(_extract_orders_from_one)
        _extract_orders_from_two_len = len(_extract_orders_from_two)
        # 如果两个骑手都没有订单（Package除外），无法变异，返回原路径
        if _extract_orders_from_one_len == 0 and _extract_orders_from_two_len == 0:
            _mutation_route = copy.deepcopy(route)
            return _mutation_route
        # 如果两个骑手包含的订单对数量相等，建立随机映射关系(随机创建一个数组)，如[1,2,3,4]<->[2,3,4,1]进行交换订单
        elif _extract_orders_from_one_len != 0 and _extract_orders_from_two_len != 0:
            # 建立随机映射订单交换对，
            _exchange_num = random.randint(1, min(_extract_orders_from_one_len, _extract_orders_from_two_len))
            # _exchange_num = min(_extract_orders_from_one_len, _extract_orders_from_two_len)
            _shuffle_list_one = random.sample(list(range(_extract_orders_from_one_len)), _exchange_num)
            _shuffle_list_two = random.sample(list(range(_extract_orders_from_two_len)), _exchange_num)
            random.shuffle(_shuffle_list_two)
            _exchange_pairs = zip(_shuffle_list_one, _shuffle_list_two)
            # 按映射关系，对两个骑手对应订单对进行交换
            for _ei, _ej in _exchange_pairs:
                _split_routes[_random_sub_route_one_idx][_extract_orders_from_one_indices[_ei][0]], \
                _split_routes[_random_sub_route_two_idx][_extract_orders_from_two_indices[_ej][0]] = \
                    _split_routes[_random_sub_route_two_idx][_extract_orders_from_two_indices[_ej][0]], \
                    _split_routes[_random_sub_route_one_idx][_extract_orders_from_one_indices[_ei][0]]
                _split_routes[_random_sub_route_one_idx][_extract_orders_from_one_indices[_ei][1]], \
                _split_routes[_random_sub_route_two_idx][_extract_orders_from_two_indices[_ej][1]] = \
                    _split_routes[_random_sub_route_two_idx][_extract_orders_from_two_indices[_ej][1]], \
                    _split_routes[_random_sub_route_one_idx][_extract_orders_from_one_indices[_ei][1]]
            _mutation_route = []
            for _sub_route_idx in range(_sub_route_len):
                _mutation_route += _split_routes[_sub_route_idx]
            return _mutation_route
        else:
            # 一个骑手订单量为0，另一个不为0
            _max_orders_len = max(_extract_orders_from_one_len, _extract_orders_from_two_len)
            _exchange_num = random.randint(1, _max_orders_len)
            # _exchange_num = _max_orders_len
            _zero_courier, _not_zero_courier = (_random_sub_route_one_idx, _random_sub_route_two_idx) \
                if _extract_orders_from_one_len == 0 else (_random_sub_route_two_idx, _random_sub_route_one_idx)
            _extract_orders = _extract_orders_from_one if _extract_orders_from_one else _extract_orders_from_two
            _exchange_list = random.sample(list(range(_exchange_num)), _exchange_num)
            for _ei in _exchange_list:
                _random_client_insert_idx = random.randint(1, len(_split_routes[_zero_courier]))
                _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
                # print("_extract_orders:",_extract_orders,"_ei:",_ei,"_extract_orders_from_one:",_extract_orders_from_one,"_extract_orders_from_two:",_extract_orders_from_two)
                _split_routes[_zero_courier].insert(_random_client_insert_idx, _extract_orders[_ei][1])
                _split_routes[_zero_courier].insert(_random_shop_insert_idx, _extract_orders[_ei][0])
                _split_routes[_not_zero_courier].remove(_extract_orders[_ei][1])
                _split_routes[_not_zero_courier].remove(_extract_orders[_ei][0])
            _mutation_route = []
            for _sub_route_idx in range(_sub_route_len):
                _mutation_route += _split_routes[_sub_route_idx]
            return _mutation_route

    @DeprecationWarning
    def __mutation_2_opt_deprecated(self, chromosome):
        """
        2-opt算法，执行变异过程：选取两个不同骑手，对换各自第一个订单，若某骑手无完整订单，则从另一骑手迁移订单
        """
        _split_routes = self._split_route_into_sub_routes(chromosome, True)
        _sub_route_len = len(_split_routes)
        _random_sub_route_one_idx = random.randint(0, _sub_route_len - 1)
        _random_sub_route_two_idx = random.randint(0, _sub_route_len - 1)
        while _random_sub_route_one_idx == _random_sub_route_two_idx:
            _random_sub_route_two_idx = random.randint(0, _sub_route_len - 1)
        _extract_order_from_one = []
        _extract_order_from_one_indices = []
        _second_node_index = None
        for _i, _node in enumerate(_split_routes[_random_sub_route_one_idx]):
            if not _extract_order_from_one and _node in self._data["shop_nodes"]:
                _extract_order_from_one_indices.append(_i)
                for _order in self._data["pickups_deliveries"]:
                    if _node == _order[0]:
                        _extract_order_from_one = _order
                        break
            if _extract_order_from_one:
                if _node == _extract_order_from_one[1]:
                    _extract_order_from_one_indices.append(_i)
                    break

        _extract_order_from_two = []
        _extract_order_from_two_indices = []
        _second_node_index = None
        for _i, _node in enumerate(_split_routes[_random_sub_route_two_idx]):
            if not _extract_order_from_two and _node in self._data["shop_nodes"]:
                _extract_order_from_two_indices.append(_i)
                for _order in self._data["pickups_deliveries"]:
                    if _node == _order[0]:
                        _extract_order_from_two = _order
                        break
            if _extract_order_from_two:
                if _node == _extract_order_from_two[1]:
                    _extract_order_from_two_indices.append(_i)
                    break

        if not _extract_order_from_two and not _extract_order_from_one:
            return chromosome
        elif _extract_order_from_one and not _extract_order_from_two:
            _split_routes[_random_sub_route_one_idx].pop(_extract_order_from_one_indices[1])
            _split_routes[_random_sub_route_one_idx].pop(_extract_order_from_one_indices[0])
            _random_client_insert_idx = random.randint(1, len(_split_routes[_random_sub_route_two_idx]))
            _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
            _split_routes[_random_sub_route_two_idx].insert(_random_client_insert_idx, _extract_order_from_one[1])
            _split_routes[_random_sub_route_two_idx].insert(_random_shop_insert_idx, _extract_order_from_one[0])
            _mutation_chromosome = []
            for _sub_route_idx in range(_sub_route_len):
                _mutation_chromosome += _split_routes[_sub_route_idx]
            if self.__b_debug_info_print:
                self._check_order_in_same_sub_route(_mutation_chromosome)
            return _mutation_chromosome
        elif _extract_order_from_two and not _extract_order_from_one:
            _split_routes[_random_sub_route_two_idx].pop(_extract_order_from_two_indices[1])
            _split_routes[_random_sub_route_two_idx].pop(_extract_order_from_two_indices[0])
            _random_client_insert_idx = random.randint(1, len(_split_routes[_random_sub_route_one_idx]))
            _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
            _split_routes[_random_sub_route_one_idx].insert(_random_client_insert_idx, _extract_order_from_two[1])
            _split_routes[_random_sub_route_one_idx].insert(_random_shop_insert_idx, _extract_order_from_two[0])
            _mutation_chromosome = []
            for _sub_route_idx in range(_sub_route_len):
                _mutation_chromosome += _split_routes[_sub_route_idx]
            if self.__b_debug_info_print:
                self._check_order_in_same_sub_route(_mutation_chromosome)
            return _mutation_chromosome
        else:
            _split_routes[_random_sub_route_one_idx][_extract_order_from_one_indices[0]] = _extract_order_from_two[0]
            _split_routes[_random_sub_route_one_idx][_extract_order_from_one_indices[1]] = _extract_order_from_two[1]
            _split_routes[_random_sub_route_two_idx][_extract_order_from_two_indices[0]] = _extract_order_from_one[0]
            # print("_random_sub_route_two_idx:",_random_sub_route_two_idx,"_extract_order_from_one:",_extract_order_from_one,"_extract_order_from_two_indices:",_extract_order_from_two_indices)
            _split_routes[_random_sub_route_two_idx][_extract_order_from_two_indices[1]] = _extract_order_from_one[1]
            _mutation_chromosome = []
            for _sub_route_idx in range(_sub_route_len):
                _mutation_chromosome += _split_routes[_sub_route_idx]
            if self.__b_debug_info_print:
                self._check_order_in_same_sub_route(_mutation_chromosome)
            return _mutation_chromosome

    def _mutation_2_opt_and_cal_fit(self, route: list) -> Chromosome:
        """
        变异同时计算适应度
        :param route:
        :return:
        """
        _mutation_route = self._mutation_2_opt(route)
        if self.__b_debug_info_print:
            self._check_order_in_same_sub_route(_mutation_route)
        return self.Chromosome(_mutation_route, self._calc_fit(_mutation_route, self._b_open_vrp, self._target))

    def _choose_top(self, population: list[Chromosome], percent):
        """
        选择适应度较好的前percent的population
        :param percent:
        :param population: 初始解
        :return:
        """
        # _top_len = int(self._population_size * percent)
        # if _top_len < 1:
        #     return []
        # _sorted_population = sorted(population, reverse=True, key=lambda x: x.fitness.fitness_value)
        # _top_population = [_sorted_population[0]]
        # _i = 1
        # while len(_top_population) < _top_len:
        #     if _sorted_population[_i].route != _top_population[-1].route:
        #         _top_population.append(_sorted_population[_i])
        #     _i += 1
        # return _top_population

        return sorted(population, reverse=True,
                      key=lambda x: x.fitness.fitness_value)[:int(self._population_size * percent)]

    def _segment_into_niches(self, population: list[Chromosome], num_of_niches=1) -> list[list[Chromosome]]:
        """
        将总体种群按汉明码距分割为 num_of_niches 个小生境
        :param population: 种群
        :param num_of_niches: 小生境数量
        :return: 二维列表，每个元素为一个小生境
        """
        if num_of_niches == 1:
            return [population]
        _niches: list[list[MA.Chromosome]] = []  # 包含 num_of_niches 个子列表
        _population_len = len(population)
        _each_niche_size = int(_population_len / num_of_niches)
        for _ in range(num_of_niches):
            _niches.append([])
        _population_copy = copy.deepcopy(population)
        _population_copy.sort(key=lambda item: item.fitness.fitness_value, reverse=True)  # 按适应度排序,从大到小
        _niche_centers = [0]  # 适应度最大的个体作为第一个小生境中心，存储序号
        _hamming_distances_summer_dict = {}  # 每个元素为所有个体距前i个小生境中心的汉明距离加和的列表，key:个体的index，value:个体距小生境中心距离加和列表

        _niche_mark = [-1] * _population_len  # 用以标记每个个体加入哪个小生境
        _niche_mark[0] = 0
        for _i in range(num_of_niches - 1):
            # 先找到新的小生境中心
            if _i != 0:
                _max_sum_distance = 0
                _max_sum_distance_chrome_index = 0
                for _j in range(_population_len):
                    if _niche_mark[_j] == -1:
                        if _hamming_distances_summer_dict[_j] > _max_sum_distance:
                            _max_sum_distance = _hamming_distances_summer_dict[_j]
                            _max_sum_distance_chrome_index = _j
                _niche_centers.append(_max_sum_distance_chrome_index)  # 第_i号小生境中心
                _niche_mark[_niche_centers[_i]] = _i
            # 再找到距离该小生境中心最近的(1/k)*population_size个个体，加入该小生境
            _hamming_distances_to_n_niche_center_dict = {}
            for _j in range(_population_len):
                if _niche_mark[_j] == -1:
                    _hamming_distance = self._cal_hamming_distance(_population_copy[_niche_centers[_i]],
                                                                   _population_copy[_j])
                    _hamming_distances_to_n_niche_center_dict[_j] = _hamming_distance
                    if _i == 0:
                        _hamming_distances_summer_dict[_j] = _hamming_distance
                    else:
                        _hamming_distances_summer_dict[_j] += _hamming_distance

            _hamming_distances_to_n_niche_center_list = sorted(_hamming_distances_to_n_niche_center_dict.items(),
                                                               key=lambda item: item[1])
            _niche_counter = _each_niche_size
            for _j, _ in _hamming_distances_to_n_niche_center_list:
                if _niche_mark[_j] == -1:
                    _niche_mark[_j] = _i
                    _niche_counter -= 1
                    if _niche_counter <= 0:
                        break
        for _j in range(_population_len):
            _niches[_niche_mark[_j]].append(_population_copy[_j])
        return _niches

    def _cross_over(self, parents: tuple[int, int], population: list[Chromosome]) -> tuple[list, list]:
        """
        对选中的parents进行交叉，两点交叉，算子：order Crossover(OX)
        :param population: 种群（小生境）
        :param parents: 二元组，组成二元组的每个元素为self.chromosome的下标号
        :return:
        """

        _parent_chromosome_route_one = population[parents[0]].route
        _parent_chromosome_route_two = population[parents[1]].route
        _parent_chromosome_split_sub_routes_one = self._split_route_into_sub_routes(_parent_chromosome_route_one)
        _parent_chromosome_split_sub_routes_two = self._split_route_into_sub_routes(_parent_chromosome_route_two)
        _sub_route_num = len(_parent_chromosome_split_sub_routes_one)
        _choose_random_reserve_sub_route_idx = random.randint(0, self._data["num_vehicles"] - 1)  # 选中保留下的子染色体
        _nodes_in_chromosome_one_reserved = _parent_chromosome_split_sub_routes_one[
                                                _choose_random_reserve_sub_route_idx][1:]  # 不包含depot节点
        _nodes_in_chromosome_two_reserved = _parent_chromosome_split_sub_routes_two[
                                                _choose_random_reserve_sub_route_idx][1:]
        _orders_only_in_one = []  # 存储只在染色体1的子染色体中的订单节点，格式[[1,2],[3,4]]，将随机插入染色体2
        _orders_only_in_two = []  # 将随机插入染色体1
        for _node in _nodes_in_chromosome_one_reserved:
            if _node not in _nodes_in_chromosome_two_reserved and self._data["nodes_attr_map"].get(_node,
                                                                                                   None) == self._NodeEnum.SHOP:
                _orders_only_in_one.append([_node, self._data["shop_client_map"][_node]])
        for _node in _nodes_in_chromosome_two_reserved:
            if _node not in _nodes_in_chromosome_one_reserved and self._data["nodes_attr_map"].get(_node,
                                                                                                   None) == self._NodeEnum.SHOP:
                _orders_only_in_two.append([_node, self._data["shop_client_map"][_node]])
        _new_chromosome_split_sub_routes_one = []
        for _sub_route_idx in range(_sub_route_num):
            if _sub_route_idx == _choose_random_reserve_sub_route_idx:
                _new_sub_route = _parent_chromosome_split_sub_routes_one[_choose_random_reserve_sub_route_idx]
            else:
                _new_sub_route = []
                for _node in _parent_chromosome_split_sub_routes_two[_sub_route_idx]:
                    if _node not in _nodes_in_chromosome_one_reserved:
                        _new_sub_route.append(_node)
            _new_chromosome_split_sub_routes_one.append(_new_sub_route)
        for _shop_node, _client_node in _orders_only_in_two:
            _random_choose_sub_route_idx = random.randint(0, _sub_route_num - 1)
            _random_client_insert_idx = random.randint(1, len(
                _new_chromosome_split_sub_routes_one[_random_choose_sub_route_idx]))
            _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
            _new_chromosome_split_sub_routes_one[_random_choose_sub_route_idx].insert(_random_client_insert_idx,
                                                                                      _client_node)
            _new_chromosome_split_sub_routes_one[_random_choose_sub_route_idx].insert(_random_shop_insert_idx,
                                                                                      _shop_node)

        _new_chromosome_split_sub_routes_two = []
        for _sub_route_idx in range(_sub_route_num):
            if _sub_route_idx == _choose_random_reserve_sub_route_idx:
                _new_sub_route = _parent_chromosome_split_sub_routes_two[_choose_random_reserve_sub_route_idx]
            else:
                _new_sub_route = []
                for _node in _parent_chromosome_split_sub_routes_one[_sub_route_idx]:
                    if _node not in _nodes_in_chromosome_two_reserved:
                        _new_sub_route.append(_node)
            _new_chromosome_split_sub_routes_two.append(_new_sub_route)
        for _shop_node, _client_node in _orders_only_in_one:
            _random_choose_sub_route_idx = random.randint(0, _sub_route_num - 1)
            _random_client_insert_idx = random.randint(1, len(
                _new_chromosome_split_sub_routes_two[_random_choose_sub_route_idx]))
            _random_shop_insert_idx = random.randint(1, _random_client_insert_idx)
            _new_chromosome_split_sub_routes_two[_random_choose_sub_route_idx].insert(_random_client_insert_idx,
                                                                                      _client_node)
            _new_chromosome_split_sub_routes_two[_random_choose_sub_route_idx].insert(_random_shop_insert_idx,
                                                                                      _shop_node)

        _child_chromosome_route_one = []
        _child_chromosome_route_two = []
        for _sub_route_idx in range(_sub_route_num):
            _child_chromosome_route_one += _new_chromosome_split_sub_routes_one[_sub_route_idx]
            _child_chromosome_route_two += _new_chromosome_split_sub_routes_two[_sub_route_idx]
        if self.__b_debug_info_print:
            # print("_parent_chromosome_one_split_sub_routes:", _parent_chromosome_one_split_sub_routes)
            # print("_parent_chromosome_two_split_sub_routes:", _parent_chromosome_two_split_sub_routes)
            # print("_choose_random_reserve_sub_route_idx:", _choose_random_reserve_sub_route_idx)
            self._check_order_in_same_sub_route(_child_chromosome_route_one)
            self._check_order_in_same_sub_route(_child_chromosome_route_two)
        return _child_chromosome_route_one, _child_chromosome_route_two

    def __total_diff_chromosome(self, population):
        if self.__b_debug_info_print:
            _container = []
            for _chromosome in population:
                # print(_chromosome[0].__str__())
                _container.append(_chromosome[0].__str__())
            _container = set(_container)
            print("how many diff:", len(_container))
        else:
            return

    def _cross_over_and_cal_fit(self, parents: tuple[int, int], population: list[Chromosome]) -> tuple[
        Chromosome, Chromosome]:
        """
        交叉并计算适应度
        :param population:
        :param parents:
        :return:
        """

        _child_chromosome_route_one, _child_chromosome_route_two = self._cross_over(parents, population)
        return self.Chromosome(_child_chromosome_route_one,
                               self._calc_fit(_child_chromosome_route_one, self._b_open_vrp, target=self._target)), \
               self.Chromosome(_child_chromosome_route_two,
                               self._calc_fit(_child_chromosome_route_two, self._b_open_vrp, target=self._target))

    def _local_search_sub_route(self, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> list:
        """
        对每个子route进行局部搜索
        :param target:
        :param b_open_vrp:
        :param sub_route: 包含头部depot，末尾不包含depot
        :return: 最好的邻域搜索结果，只返回路径
        """
        _best_sub_route: list | None = None
        _best_fitness_value = -1
        _sub_route_len = len(sub_route)
        if _sub_route_len <= 2:
            return sub_route
        for _i in range(1, _sub_route_len - 1):
            for _j in range(_i + 1, _sub_route_len):
                _switched_route = copy.deepcopy(sub_route)
                _switched_route[_i], _switched_route[_j] = _switched_route[_j], _switched_route[_i]
                _switched_route = self._correct_pickup_and_delivery(_switched_route)
                _fitness_value = self._calc_fitness_value_of_sub_route(_switched_route, b_open_vrp, target)
                if _fitness_value > _best_fitness_value:
                    _best_fitness_value = _fitness_value
                    _best_sub_route = _switched_route
        return _best_sub_route

    def _calc_fitness_value_of_sub_route(self, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> float:
        """
        用在局部搜索，计算局部搜索的子route的适应度
        :param target:
        :param b_open_vrp:
        :param sub_route:
        :return:
        """
        _fitness_value = self._cache.fitness_value_sub_route_map.get(sub_route.__str__(), -1)
        if _fitness_value != -1:
            return _fitness_value
        _sub_route_len = len(sub_route)
        if target == self.TargetEnum.DISTANCE or target == self.TargetEnum.TIME:
            _target_cost = 0
            if target == self.TargetEnum.DISTANCE:
                if _sub_route_len == 1:
                    return 0
                for _idx in range(_sub_route_len - 1):
                    if sub_route[_idx] == sub_route[_idx + 1]:
                        raise Exception("error", "error")
                    _target_cost += self._data["distance_matrix"][sub_route[_idx]][sub_route[_idx + 1]]
                if not b_open_vrp:
                    _target_cost += self._data["distance_matrix"][sub_route[-1]][sub_route[0]]
                self._cache.cost_without_penalty_mem_map[sub_route.__str__()] = _target_cost
            elif target == self.TargetEnum.TIME:
                if _sub_route_len == 1:
                    return 0
                _target_cost = 0
                _accumulate_time_cost = self._data["service_time"][sub_route[0]]  # 用于累积子路径的时间花费
                # 计算子route的纯时间消耗（各客户、包裹节点花费时间）
                for _idx in range(_sub_route_len - 1):
                    _accumulate_time_cost += self._data["distance_matrix"][sub_route[_idx]][
                                                 sub_route[_idx + 1]] / self._speed + \
                                             self._data["service_time"][sub_route[_idx + 1]]
                    if self._data["nodes_attr_map"].get(sub_route[_idx + 1], None) == self._NodeEnum.CLIENT or \
                            self._data["nodes_attr_map"].get(sub_route[_idx + 1],
                                                             None) == self._NodeEnum.PACKAGE:
                        _target_cost += _accumulate_time_cost
                self._cache.cost_without_penalty_mem_map[sub_route.__str__()] = _target_cost
            # 惩罚统计
            _cap_penalty_count = 0  # 累计超限或低限个数
            _time_penalty_count = 0  # 累计超时秒数
            _pickup_delivery_penalty_count = 0  # 累计先取后送违背次数
            _time_cost = 0
            _cap_accu = 0

            for _idx in range(_sub_route_len - 1):
                if sub_route[_idx] == sub_route[_idx + 1]:
                    raise Exception("error", "error")
                if _time_cost < self._data["time_windows"][sub_route[_idx]][0]:
                    _time_penalty_count += self._data["time_windows"][sub_route[_idx]][0] - _time_cost
                _time_cost += self._data["distance_matrix"][sub_route[_idx]][sub_route[_idx + 1]] / self._speed
                if _time_cost > self._data["time_windows"][sub_route[_idx + 1]][1]:
                    _time_penalty_count += _time_cost - self._data["time_windows"][sub_route[_idx + 1]][1]

                _cap_accu += self._data['demands'][sub_route[_idx]]
                if _cap_accu < 0:
                    _cap_penalty_count += -_cap_accu
                elif _cap_accu > self._data['vehicle_capacities']:
                    _cap_penalty_count += _cap_accu - self._data['vehicle_capacities']

            if not b_open_vrp:
                _time_cost += self._data['distance_matrix'][sub_route[-1]][sub_route[0]] / self._speed
                if _time_cost > self._data["time_windows"][sub_route[0]][1]:
                    _time_penalty_count += _time_cost - self._data["time_windows"][sub_route[0]][1]
            for _idx, _node in enumerate(sub_route):
                if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                    _second = self._data["shop_client_map"].get(_node, None)
                    try:
                        _second_idx = sub_route.index(_second)
                    except Exception:
                        _second_idx = -1
                        raise Exception("_sub_route:", sub_route, "_order:", (_node, _second))
                    if _idx > _second_idx:
                        _pickup_delivery_penalty_count += 1
            _cost = _target_cost + (
                    _pickup_delivery_penalty_count * self._pickup_delivery_penalty_ratio + _cap_penalty_count * self._capacity_penalty_ratio + _time_penalty_count * self._time_window_penalty_ratio) * self._penalty_coefficient
            if 0.0 <= _cost < 10 ** -5:
                _fitness_value = float('+inf')
            else:
                _fitness_value = 1.0 / _cost
            self._cache.fitness_value_sub_route_map[sub_route.__str__()] = _fitness_value
            return _fitness_value  # 只返回适应度值(float)

    def _local_search(self, route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> Chromosome:
        """
        局部搜索算法，对每个子route进行局部搜索，找到每个子route的最优邻域解，组合为route
        :param target:
        :param b_open_vrp:
        :param route: 每个子route段只有头部包含depot而尾部不包含depot
        :return:
        """
        _route = self._loop_2_opt_switch(route, b_open_vrp, target)
        # _route = self._destroy_and_repair(_route, b_open_vrp, target)
        return self.Chromosome(_route, self._calc_fit(_route, b_open_vrp, target))

    def _loop_2_opt_switch(self, route: list, b_open_vrp, target=TargetEnum.DISTANCE) -> list:
        """
        局部搜索算法，对每个子route进行局部搜索，找到每个子route的最优邻域解，组合为route
        :param target:
        :param b_open_vrp:
        :param route: 每个子route段只有头部包含depot而尾部不包含depot
        :return:
        """
        _split_routes = self._split_route_into_sub_routes(route)
        if self.__b_debug_info_print:
            self._check_order_in_same_sub_route(route)
        _best_route = []
        for _sub_route in _split_routes:
            _best_route += self._local_search_sub_route(_sub_route, b_open_vrp, target)
        if self.__b_debug_info_print:
            self._check_order_in_same_sub_route(_best_route)
        return _best_route

    def _destroy_and_repair(self, route: list, b_open_vrp, target) -> list:
        """

        :param route:
        :return:
        """
        _split_sub_routes = self._split_route_into_sub_routes(route)
        _choose_nodes: list[list] = []
        # 先选择从每个子路径中提取的节点（对）
        for _sub_route in _split_sub_routes:
            _sub_route_len = len(_sub_route)
            if _sub_route_len == 1:
                _choose_nodes.append([])
            else:
                _random_idx_in_sub_route = random.randint(1, _sub_route_len - 1)
                _choose_node = _sub_route[_random_idx_in_sub_route]
                _choose_node_attr = self._data["nodes_attr_map"].get(_sub_route[_random_idx_in_sub_route], None)
                if _choose_node_attr == self._NodeEnum.PACKAGE:
                    _choose_nodes.append([_choose_node])
                elif _choose_node_attr == self._NodeEnum.SHOP:
                    _choose_nodes.append([_choose_node, self._data["shop_client_map"][_choose_node]])
                elif _choose_node_attr == self._NodeEnum.CLIENT:
                    _choose_nodes.append([self._data["client_shop_map"][_choose_node], _choose_node])
        # 依次插入每一个节点（对），并迭代出适应度最高的路径
        for _i, _insert_nodes in enumerate(_choose_nodes):
            if len(_insert_nodes) == 0:
                continue
            elif len(_insert_nodes) == 1:
                _split_sub_routes[_i].remove(_insert_nodes[0])
                _split_sub_routes[_i] = self._insert_to_sub_route(_insert_nodes, _split_sub_routes[_i], b_open_vrp,
                                                                  target)
            else:
                _split_sub_routes[_i].remove(_insert_nodes[1])
                _split_sub_routes[_i].remove(_insert_nodes[0])
                _best_fitness_value = -1
                _best_route: list | None = None
                _best_sub_route_idx = -1
                _best_sub_route: list | None = None
                # 尝试将该节点（对）插入每一个子路径中，找到插入后适应度最高的路径
                for _j in range(len(_split_sub_routes)):
                    _best_inserted_sub_route = self._insert_to_sub_route(_insert_nodes, _split_sub_routes[_j],
                                                                         b_open_vrp, target)

                    _copy_split_sub_routes = copy.deepcopy(_split_sub_routes)
                    _copy_split_sub_routes[_j] = _best_inserted_sub_route
                    _concatenated_route = []
                    for _sub_route in _copy_split_sub_routes:
                        _concatenated_route += _sub_route
                    _fitness = self._calc_fit(_concatenated_route, b_open_vrp, target)
                    if _fitness.fitness_value > _best_fitness_value:
                        _best_fitness_value = _fitness.fitness_value
                        _best_route = _concatenated_route
                        _best_sub_route_idx = _j
                        _best_sub_route = _best_inserted_sub_route
                _split_sub_routes[_best_sub_route_idx] = _best_sub_route
        _concatenated_route = []
        for _sub_route in _split_sub_routes:
            _concatenated_route += _sub_route
        return _concatenated_route

    def _insert_to_sub_route(self, insert_nodes: list, sub_route: list, b_open_vrp, target=TargetEnum.DISTANCE):
        """
        将_destropy_and_repair中_choose_nodes中的子元素插入到locao_search后的sub_route中
        即：先执行_local_search_subroute，后对_best_sub_route执行_insert_to_subroute并产生一个_best_sub_route
        :param insert_nodes:
        :param sub_route:
        :param b_open_vrp:
        :param target:
        :return:
        """
        _best_sub_route: list | None = None
        _best_fitness_value = -1
        _sub_route_len = len(sub_route)
        if len(insert_nodes) == 1:
            for _i in range(1, _sub_route_len + 1):
                _inserted_sub_route = copy.deepcopy(sub_route)
                _inserted_sub_route.insert(_i, insert_nodes[0])
                _fitness_value = self._calc_fitness_value_of_sub_route(_inserted_sub_route, b_open_vrp, target)
                if _fitness_value > _best_fitness_value:
                    _best_fitness_value = _fitness_value
                    _best_sub_route = _inserted_sub_route
        else:
            for _j in range(1, _sub_route_len + 1):
                for _i in range(1, _j + 1):
                    _inserted_sub_route = copy.deepcopy(sub_route)
                    _inserted_sub_route.insert(_j, insert_nodes[1])
                    _inserted_sub_route.insert(_i, insert_nodes[0])
                    _fitness_value = self._calc_fitness_value_of_sub_route(_inserted_sub_route, b_open_vrp, target)
                    if _fitness_value > _best_fitness_value:
                        _best_fitness_value = _fitness_value
                        _best_sub_route = _inserted_sub_route
        return _best_sub_route

    @DeprecationWarning
    def _local_search_save_all(self, chromosome, sort=True):
        """
        局部搜索算法，返回所有邻域解
        :param sort:
        :param chromosome:
        :return:
        """
        _neighbor_solutions = []
        _chromosome_len = len(chromosome)
        for _i in range(1, _chromosome_len - 1):
            for _j in range(_i + 1, _chromosome_len):
                _chromosome_switched = copy.deepcopy(chromosome)
                _chromosome_switched[_i], _chromosome_switched[_j] = _chromosome_switched[_j], _chromosome_switched[_i]
                _fitness = self._calc_fit(_chromosome_switched)
                _neighbor_solutions.append((_chromosome_switched, _fitness))
        if sort:
            _neighbor_solutions = sorted(_neighbor_solutions, key=lambda item: item[1])
        return _neighbor_solutions

    def _correct_pickup_and_delivery(self, sub_route: list):
        """
        :param sub_route: 这里sub_route头部有depot，末尾不包括depot
        纠正chromosome的先取后送错误
        :return:
        """
        for _i, _node in enumerate(sub_route):
            if self._data["nodes_attr_map"].get(_node, None) == self._NodeEnum.SHOP:
                _second_node = self._data["shop_client_map"][_node]
                _j = sub_route.index(_second_node)
                # 如果shop的index在client的index之后，则交换节点
                if _i > _j:
                    sub_route[_i], sub_route[_j] = sub_route[_j], sub_route[_i]
        return sub_route

    def _check_feasible(self, solution: Chromosome) -> bool:
        """

        :param route:
        :return:
        """
        if solution.fitness.pd_penalty_count > 0 or solution.fitness.cap_penalty_count > 0:
            if solution.fitness.pd_penalty_count > 0 and solution.fitness.cap_penalty_count > 0:
                print("不符合取送约束与容量约束!")
                raise Exception("不符合取送约束与容量约束")
            elif solution.fitness.pd_penalty_count > 0:
                print("不符合取送约束!")
                raise Exception("不符合取送约束")
            elif solution.fitness.cap_penalty_count > 0:
                print("不符合容量约束!")
                raise Exception("不符合容量约束")
            print("不符合约束!")
            raise Exception("不符合约束!")
            return False
        return True

    @DeprecationWarning
    def __solve_with_few_nodes(self):
        """

        :param threshold_node_num: 当节点数少于threshold时，使用穷举算法求解
        :return:
        """

        _all_routes_without_depot = permutations(list(range(1, len(self._data['demands']))))
        _all_solutions = []
        for _route_without_depot in _all_routes_without_depot:
            _route = [0] + list(_route_without_depot)
            _all_solutions.append((_route, self._calc_fit(_route, True)))
        _all_solutions.sort(key=lambda x: x[1])
        for _solution in _all_solutions:
            if self._check_feasible(_solution[0]):
                return _solution[0], _solution[1]
        return False, False

    def solve_vrp(self, time_graph, pickups_deliveries, time_windows, demands, depot, binding, num_vehicles, capacity,
                  distance_matrix, service_time, b_return_iter_cost=False, new_orders_nodes=None,
                  dispatched_orders_nodes=None):
        """

        :return:
        """
        # TODO: 加入输入上一轮解，以此通过启发式方法，将新订单的两个节点插入上一轮的解中，生成初始解
        _time_0 = time()
        _iter_record = []  # 用于存储每轮迭代后的best_solution的cost
        _iter_without_penalty_record = []  # 用于存储每轮迭代后的best_solution的cost（忽略penalty）
        _iter_chromosome_record: list[MA.Chromosome] = []  # 用于存储每轮迭代的染色体（包含适应度）
        self.create_data_model(time_graph, pickups_deliveries, time_windows, demands, depot, binding, num_vehicles,
                               capacity, distance_matrix, service_time, new_orders_nodes, dispatched_orders_nodes)
        _iter_population = self._gen_init_sol()
        _best_solution: MA.Chromosome | None = None
        self._terminate_fitness_equal_count = 0
        for _ in range(self._generation_num):
            _iter_population, _solution = self._iteration(_iter_population)
            if _best_solution is None:
                _best_solution = _solution
            elif _solution.fitness.fitness_value > _best_solution.fitness.fitness_value:
                _best_solution = _solution
                self._terminate_fitness_equal_count = 0
            else:
                self._terminate_fitness_equal_count += 1
                if self._b_terminate_by_fitness_equal and \
                        self._terminate_fitness_equal_count >= self._terminate_fitness_equal_time:
                    break
            if self.__b_debug_info_print:
                print("\n_best_solution:", _best_solution.route, " fitness:",
                      _best_solution.fitness.fitness_value.__round__(6),
                      " real_value:", _best_solution.fitness.real_value.__round__(2),
                      "\n_curt_solution:", _solution.route, " fitness:", _solution.fitness.fitness_value.__round__(6),
                      " real_value:", _solution.fitness.real_value.__round__(2))

            # debug
            # print("\n_best_solution:", _best_solution.route, " fitness:",
            #       _best_solution.fitness.fitness_value.__round__(6),
            #       " real_value:", _best_solution.fitness.real_value.__round__(2), " fatal?penalty?:",
            #       _best_solution.fitness.b_have_fatal_penalty, _best_solution.fitness.b_have_penalty, "t_p_count:",
            #       _best_solution.fitness.tw_penalty_count.__round__(2), "s",
            #       "\n_curt_solution:", _solution.route, " fitness:", _solution.fitness.fitness_value.__round__(6),
            #       " real_value:", _solution.fitness.real_value.__round__(2), " fatal?penalty?:",
            #       _solution.fitness.b_have_fatal_penalty, _solution.fitness.b_have_penalty, "t_p_count:",
            #       _solution.fitness.tw_penalty_count.__round__(2), "s", "\ttime:", time() - _time_0)  # debug
            if b_return_iter_cost:
                _iter_record.append(_best_solution.fitness.fitness_value)
                _iter_without_penalty_record.append(_best_solution.fitness.real_value)
                _iter_chromosome_record.append(_best_solution)
                # while len(_iter_record)>300 and len(_iter_record)<self._generation_num:
                #     _iter_record.append(_best_solution.fitness.fitness_value)
                #     _iter_without_penalty_record.append(_best_solution.fitness.real_value)
                if len(_iter_chromosome_record) >= self._generation_num:
                    break
        if self.__b_debug_info_print:
            print("result:", _best_solution.route, _best_solution.fitness.fitness_value,
                  _best_solution.fitness.real_value)

        if b_return_iter_cost:
            self.clean_cache()
            return _iter_chromosome_record
            # return _best_solution.route, _best_solution.fitness.fitness_value, _iter_record, _iter_without_penalty_record
        if self._check_feasible(_best_solution):
            self.clean_cache()
            return _best_solution.route, int(1 / _best_solution.fitness.fitness_value)
        else:
            self.clean_cache()
            return False

    def _perfect_print(self, route):
        """
        将route转换为depot为负值的route，仅用作打印
        :param route:
        :return:
        """
        _route_for_print = []
        for _i in range(len(route)):
            _route_for_print.append(route[_i] - self._data["num_vehicles"] + 1)
        return _route_for_print

    def _check_order_in_same_sub_route(self, route):
        """

        :param route:
        :return:
        """
        return
        _bit_list = [0] * 107
        for _node in route:
            _bit_list[_node] += 1
            if _node != 0 and _bit_list[_node] > 1:
                _split_routes = self._split_route_into_sub_routes(route, True)
                raise Exception("len(route):", len(route), "_split_routes:", _split_routes, "repeated node:", _node)

        if len(route) != 116:
            raise Exception("len(route):", len(route))
        _split_routes = self._split_route_into_sub_routes(route, True)
        for _sub_route in _split_routes:
            for _node in _sub_route:
                if _node in self._data["shop_nodes"]:
                    _second = None
                    for _order in self._data["pickups_deliveries"]:
                        if _node == _order[0]:
                            _second = _order[1]
                            break
                    try:
                        _second_idx = _sub_route.index(_second)
                    except Exception:
                        _second_idx = -1
                        raise Exception("_sub_route:", _sub_route, "_order:", (_node, _second), "\n", "_split_routes:",
                                        _split_routes)

    def _iteration(self, population: list[Chromosome]) -> tuple[list[Chromosome], Chromosome]:
        """
        迭代
        :param population:
        :return:
        """
        _one_iter_solutions: list[MA.Chromosome] = []
        # Choose Top
        _one_iter_solutions += self._choose_top(population, self._choose_top_percent)
        # N Niches
        _niches = self._segment_into_niches(population, self._num_of_niches)
        # Dynamic Probability
        self.__crossover_equal_count = 0
        if self._dynamic_probability:
            _prob_variation = min(
                self._cross_over_prob - 0.1,
                math.sin(
                    min(self._terminate_fitness_equal_count / (self._terminate_fitness_equal_time / 2),
                        1) / 2 * math.pi) * self._cross_over_prob
            )
        else:
            _prob_variation = 0
        _cross_over_prob = self._cross_over_prob - _prob_variation
        _mut_prob = self._mut_prob + _prob_variation
        __total = 0
        # Roulette Wheel Selection & Cross Over
        for _niche in _niches:
            _niche_offsprings = []
            for _parents_indices in self._rou_wheel_sel(int(len(_niche) * _cross_over_prob // 2), _niche):
                _niche_offsprings = self._cross_over_and_cal_fit(_parents_indices, _niche)
                _one_iter_solutions += _niche_offsprings
                # TODO:局部搜索放在这部分，对各小生境按适应度排序，对优秀的局部搜索
                __total += 1

        # Mutation
        _mut_solutions = []
        for _ in range(int(self._population_size * _mut_prob)):
            _choose_mutation = random.randint(0, len(_one_iter_solutions) - 1)
            _mutation_chromosome = self._mutation_2_opt_and_cal_fit(_one_iter_solutions[_choose_mutation].route)
            _mut_solutions.append(_mutation_chromosome)
            # if False and self._terminate_fitness_equal_count > self._terminate_fitness_equal_time // 2:
            #     for _ in range(max(self._terminate_fitness_equal_count - self._terminate_fitness_equal_time // 2,
            #                        self._data["num_vehicles"])):
            #         _mutation_chromosome = self._mutation_2_opt_and_cal_fit(_mutation_chromosome.route)
            #         _mut_solutions.append(_mutation_chromosome)
        _mut_solutions = sorted(_mut_solutions, key=lambda x: x.fitness.fitness_value, reverse=True)[
                         :int(self._population_size * _mut_prob)]
        _one_iter_solutions += _mut_solutions
        _one_iter_solutions_len = len(_one_iter_solutions)
        # Local Search
        for _ in range(self._population_size - _one_iter_solutions_len):
            _choose_localsearch = random.randint(0, _one_iter_solutions_len - 1)
            _local_search_result: MA.Chromosome | int = self._cache.local_search_map.get(
                _one_iter_solutions[_choose_localsearch].route.__str__(), -1)
            if _local_search_result == -1:
                _local_search_result = self._local_search(_one_iter_solutions[_choose_localsearch].route,
                                                          self._b_open_vrp, self._target)
                self._cache.local_search_map[_local_search_result.route.__str__()] = _local_search_result
            _one_iter_solutions.append(_local_search_result)

        # if self._terminate_fitness_equal_count < self._terminate_fitness_equal_time // 2:
        #     _one_iter_solutions = sorted(_one_iter_solutions, key=lambda x: x.fitness.fitness_value,
        #                                  reverse=True)  # True为适应度从大到小，只对mutation后的所有个体按适应度从大到小进行局部搜索
        #     for _i in range(self._population_size - _one_iter_solutions_len):
        #         _local_search_result: MA.Chromosome | int = self._cache.local_search_map.get(
        #             _one_iter_solutions[_i].route.__str__(), -1)
        #         if _local_search_result == -1:
        #             _local_search_result =self._local_search(_one_iter_solutions[_i].route,self._b_open_vrp,self._target)
        #             self._cache.local_search_map[_local_search_result.route.__str__()] = _local_search_result
        #         _one_iter_solutions.append(_local_search_result)
        # else:
        #     _mut_solutions = sorted(_mut_solutions, key=lambda x: x.fitness.fitness_value,
        #                             reverse=True)
        #     for _i in range(self._population_size - _one_iter_solutions_len):
        #         _local_search_result: MA.Chromosome | int = self._cache.local_search_map.get(
        #             _mut_solutions[_i].route.__str__(), -1)
        #         if _local_search_result == -1:
        #             _local_search_result=self._local_search(_mut_solutions[_i].route,self._b_open_vrp,self._target)
        #             self._cache.local_search_map[_local_search_result.route.__str__()] = _local_search_result
        #         _one_iter_solutions.append(_local_search_result)

        # print("len(_one_iter_solutions):", len(_one_iter_solutions))
        _best_solution: MA.Chromosome | None = None
        _best_fitness_value = -1
        for _sol in _one_iter_solutions:
            if _sol.fitness.fitness_value > _best_fitness_value:
                _best_solution = _sol
                _best_fitness_value = _sol.fitness.fitness_value
        if self.__b_debug_info_print:
            for _solution in _one_iter_solutions:
                self._check_order_in_same_sub_route(_solution.route)
        return _one_iter_solutions, _best_solution

    def clean_cache(self):
        """
        求解结束后，清空运算缓存
        :return:
        """
        self._cache.clean()
        del self._data
        gc.collect()
        self._data = {}


if __name__ == '__main__':
    conv = Converter(instance_id=1)
    data = conv.data

    time1 = time()
    MA = MA(seed=111, population=1000, niche_num=1, terminate_by_fitness_equal=False, open_vrp=False,
            target=MA.TargetEnum.TIME,
            debug_info=False)
    MA.change_parameters(need_correct_pickup_delivery=True, shift_cross_and_mutation_on=False,
                         dynamic_probability=True,
                         iter_time=100, niche_num=5, is_ga=False)

    MA.solve_vrp(data["time_matrix"], data["pickups_deliveries"], data["time_windows"], data["demands"], data["depot"],
                 data["binding"], data["num_vehicles"], data["vehicle_capacities"], data["distance_matrix"],
                 data["service_time"])

    print("time:", time() - time1)
