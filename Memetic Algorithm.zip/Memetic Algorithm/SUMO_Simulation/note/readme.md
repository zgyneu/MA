state设定：

空置置为-1

0:时间戳 percent

1~4：新订单shop(x,y)、新订单client(x,y) percent

n个骑手

每个骑手：骑手pos(x,y percent) ; 背包已装 n/limit  percent ;路径链 

node_pos(x,y,remaintime,mark percent * 20) 注：node为shop时，mark为-1,remaintime=-1, node为package或client时，mark为1  共计:2+1+4*20）