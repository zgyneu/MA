map0={0:"a",1:"b",2:"c",3:"d"}

for key,value in map0.items():
    print("first: ",key," + ",value)
    if key%2==0:
        pop_key=map0.pop(key)
        print("pop key : ",pop_key)