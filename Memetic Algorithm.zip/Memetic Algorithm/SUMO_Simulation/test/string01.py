str="425: {"
num=0
for char in str:
    if '0'<= char <= '9':
        num=num*10
        num+=int(char)
print(num)