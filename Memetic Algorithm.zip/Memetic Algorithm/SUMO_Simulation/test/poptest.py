path=[1,2,3,4,5,6]

for i in [0]+path:
    if i==2:
        path.remove(i)
    print(i)

print(path)