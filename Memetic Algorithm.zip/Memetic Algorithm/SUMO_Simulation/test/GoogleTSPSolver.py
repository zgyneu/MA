'''
Created on Dec 25, 2020

@author: guangyuzou
'''
"""Simple Pickup Delivery Problem (PDP)."""

from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp
import sys
import math

def create_data_model():
    """Stores the data for the problem."""
    data = {}
    data['distance_matrix'] = [
        [
            0, 1, 2, 3
        ],
        [
            1, 0, 4, 5
        ],
        [
            2, 4, 0, 6
        ],
        [
            3, 5, 6, 0
        ]
    ]
    data['demands'] = [0, 1, 1, -1]
    data['vehicle_capacities'] = [2]
    data['pickups_deliveries'] = [
        [1, 3],
        [2, 3]
    ]
    data['time_windows'] = [
        (0, 0),  # depot
        (0, 6),  # 1
        (0, 2),  # 2
        (0, 100),  # 3
    ]
    data['num_vehicles'] = 1
    data['depot'] = 0
    return data

class GVRPWrapper(object):
    def __init__(self, graph, constraints, curLoad, tick, s):
        self._node2Index = {}
        self._index2Node = {}
        i = 1
        for node in graph.keys():
            if node == s:
                self._node2Index[node] = 0
                self._index2Node[0] = node
            else:
                self._node2Index[node] = i
                self._index2Node[i] = node
                i += 1
        self._data = {}  
        self._data['distance'] = []
        for i in range(len(self._index2Node)):
            self._data['distance'].append([sys.maxsize]*len(self._index2Node))
            for j in range(len(self._index2Node)):
                if i == j:
                    self._data['distance'][i][j] = 0
                else:
                    dist = graph[self._index2Node[i]][self._index2Node[j]]
                    self._data['distance'][i][j] = sys.maxsize if math.isinf(dist) else dist
        self._data['demands'] = [0]*len(self._index2Node)
        for node, demand in constraints.getLoadLmt()[1].items():
            if node in self._node2Index:
                self._data['demands'][self._node2Index[node]] = demand
        self._data['demands'][self._node2Index[s]] = curLoad
        
        self._data['vehicle_capacities'] = [constraints.getLoadLmt()[0]]
                
        self._data['pickups_deliveries'] = []    
        for key, values in constraints.getSeq().items():
            for value in values:
                if key in self._node2Index and value in self._node2Index:
                    self._data['pickups_deliveries'].append([self._node2Index[value], self._node2Index[key]])
                    
        self._data['time_windows'] = []
        for i in range(len(self._node2Index)):
            if self._index2Node[i] in constraints.getTimeLmt():
                self._data['time_windows'].append((0, constraints.getTimeLmt()[self._index2Node[i]]-tick))
            else:
                self._data['time_windows'].append((0, max(constraints.getTimeLmt().values())-tick))
        self._data['time_windows'][0] = (0,0)
    
        self._data['num_vehicles'] = 1
        self._data['depot'] = self._node2Index[s]
        
    def solve(self):
        solver = GORTsp(self._data['distance'], self._data['demands'], self._data['vehicle_capacities'], self._data['pickups_deliveries'], self._data['time_windows'], self._data['depot'])
        solution = solver.solve()
        if solution:
#             solver.print_solutionTime(solution)
            route = solver.route(solution)
            if route[0] == 0:
                return (float('inf'), [])
            else:
                return (route[0],[self._index2Node[i] for i in route[1]])
        else:
            return (float('inf'), [])
        
class GORTsp(object):
    def __init__(self, distMat, demands, capacity, pickDeliver, timewindow, deportI):
        self._data = {}
        self._data['distance_matrix']  = distMat
        self._data['demands'] = demands
        self._data['vehicle_capacities'] = capacity
        self._data['pickups_deliveries'] = pickDeliver
        self._data['time_windows'] = timewindow
        self._data['depot'] = deportI
        self._data['num_vehicles'] = 1
        self._initSolver()
        
    def solve(self):
        sol = self._routing.SolveWithParameters(self._search_parameters)
#         print(self.route(sol))
        return sol
        
    def _initSolver(self):
            # Create the routing index manager.
        self._manager = pywrapcp.RoutingIndexManager(len(self._data['distance_matrix']),
                                               self._data['num_vehicles'], self._data['depot'])
    
        # Create Routing Model.
        self._routing = pywrapcp.RoutingModel(self._manager)
    
    
        # Define cost of each arc.
        def distance_callback(from_index, to_index):
            """Returns the manhattan distance between the two nodes."""
            # Convert from routing variable Index to distance matrix NodeIndex.
            from_node = self._manager.IndexToNode(from_index)
            to_node = self._manager.IndexToNode(to_index)
            return self._data['distance_matrix'][from_node][to_node]
    
        transit_callback_index = self._routing.RegisterTransitCallback(distance_callback)
        self._routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
    
        
        # Add Time Windows constraint.
        time = 'Time'
        self._routing.AddDimension(
            transit_callback_index,
            0,  # allow waiting time
            3600*24,  # maximum time per vehicle
            False,  # Don't force start cumul to zero.
            time)
        time_dimension = self._routing.GetDimensionOrDie(time)
        # Add time window constraints for each location except depot.
        for location_idx, time_window in enumerate(self._data['time_windows']):
            if location_idx == 0:
                continue
            index = self._manager.NodeToIndex(location_idx)
            time_dimension.CumulVar(index).SetRange(int(time_window[0]), int(time_window[1]))
        # Add time window constraints for each vehicle start node.
        for vehicle_id in range(self._data['num_vehicles']):
            index = self._routing.Start(vehicle_id)
            time_dimension.CumulVar(index).SetRange(self._data['time_windows'][0][0],
                                                    self._data['time_windows'][0][1])
    
        # Instantiate route start and end times to produce feasible times.
        for i in range(self._data['num_vehicles']):
            self._routing.AddVariableMinimizedByFinalizer(
                time_dimension.CumulVar(self._routing.Start(i)))
            self._routing.AddVariableMinimizedByFinalizer(
                time_dimension.CumulVar(self._routing.End(i)))
        
        # Define Transportation Requests.
        for request in self._data['pickups_deliveries']:
            pickup_index = self._manager.NodeToIndex(request[0])
            delivery_index = self._manager.NodeToIndex(request[1])
            self._routing.AddPickupAndDelivery(pickup_index, delivery_index)
            self._routing.solver().Add(
                self._routing.VehicleVar(pickup_index) == self._routing.VehicleVar(delivery_index))
            self._routing.solver().Add(
                time_dimension.CumulVar(pickup_index) <= time_dimension.CumulVar(delivery_index))
            
        # Add Capacity constraint.
        def demand_callback(from_index):
            """Returns the demand of the node."""
            # Convert from routing variable Index to demands NodeIndex.
            from_node = self._manager.IndexToNode(from_index)
            return self._data['demands'][from_node]
    
        demand_callback_index = self._routing.RegisterUnaryTransitCallback(
            demand_callback)
        self._routing.AddDimensionWithVehicleCapacity(
            demand_callback_index,
            0,  # null capacity slack
            self._data['vehicle_capacities'],  # vehicle maximum capacities
            True,  # start cumul to zero
            'Capacity')
    
        # Setting first solution heuristic.
        self._search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        self._search_parameters.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
        
    def route(self, solution):
        ret = []
        totalCost = 0
        index = self._routing.Start(0)
        while not self._routing.IsEnd(index):
            ret.append(self._manager.IndexToNode(index))
            previous_index = index
            index = solution.Value(self._routing.NextVar(index))
            totalCost += self._routing.GetArcCostForVehicle(previous_index, index, 0)
        return (totalCost, ret)

    def print_solution(self, solution):
        """Prints solution on console."""
        total_distance = 0
        for vehicle_id in range(self._data['num_vehicles']):
            index = self._routing.Start(vehicle_id)
            plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
            route_distance = 0
            while not self._routing.IsEnd(index):
                plan_output += ' {} -> '.format(self._manager.IndexToNode(index))
                previous_index = index
                index = solution.Value(self._routing.NextVar(index))
                route_distance += self._routing.GetArcCostForVehicle(
                    previous_index, index, vehicle_id)
            plan_output += '{}\n'.format(self._manager.IndexToNode(index))
            plan_output += 'Distance of the route: {}m\n'.format(route_distance)
            print(plan_output)
            total_distance += route_distance
        print('Total Distance of all routes: {}m'.format(total_distance))

    def print_solutionTime(self, solution):
        """Prints solution on console."""
        time_dimension = self._routing.GetDimensionOrDie('Time')
        total_time = 0
        for vehicle_id in range(self._data['num_vehicles']):
            index = self._routing.Start(vehicle_id)
            plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
            while not self._routing.IsEnd(index):
                time_var = time_dimension.CumulVar(index)
                plan_output += '{0} Time({1},{2}) -> '.format(
                    self._manager.IndexToNode(index), solution.Min(time_var),
                    solution.Max(time_var))
                index = solution.Value(self._routing.NextVar(index))
            time_var = time_dimension.CumulVar(index)
            plan_output += '{0} Time({1},{2})\n'.format(self._manager.IndexToNode(index),
                                                        solution.Min(time_var),
                                                        solution.Max(time_var))
            plan_output += 'Time of the route: {}min\n'.format(
                solution.Min(time_var))
            print(plan_output)
            total_time += solution.Min(time_var)
        print('Total time of all routes: {}min'.format(total_time))

def main():
    """Entry point of the program."""
    # Instantiate the data problem.
    data = create_data_model()
    solver = GORTsp(data['distance_matrix'], data['demands'], data['vehicle_capacities'], data['pickups_deliveries'],data['time_windows'], 0)
    solver.print_solution(solver.solve())

#     # Create the routing index manager.
#     manager = pywrapcp.RoutingIndexManager(len(data['distance_matrix']),
#                                            data['num_vehicles'], data['depot'])
# 
#     # Create Routing Model.
#     routing = pywrapcp.RoutingModel(manager)
# 
# 
#     # Define cost of each arc.
#     def distance_callback(from_index, to_index):
#         """Returns the manhattan distance between the two nodes."""
#         # Convert from routing variable Index to distance matrix NodeIndex.
#         from_node = manager.IndexToNode(from_index)
#         to_node = manager.IndexToNode(to_index)
#         return data['distance_matrix'][from_node][to_node]
# 
#     transit_callback_index = routing.RegisterTransitCallback(distance_callback)
#     routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)
# 
#     # Add Distance constraint.
#     dimension_name = 'Distance'
#     routing.AddDimension(
#         transit_callback_index,
#         0,  # no slack
#         3000,  # vehicle maximum travel distance
#         True,  # start cumul to zero
#         dimension_name)
#     distance_dimension = routing.GetDimensionOrDie(dimension_name)
#     distance_dimension.SetGlobalSpanCostCoefficient(100)
# 
#     
#     # Add Time Windows constraint.
#     time = 'Time'
#     routing.AddDimension(
#         transit_callback_index,
#         0,  # allow waiting time
#         30000,  # maximum time per vehicle
#         False,  # Don't force start cumul to zero.
#         time)
#     time_dimension = routing.GetDimensionOrDie(time)
#     # Add time window constraints for each location except depot.
#     for location_idx, time_window in enumerate(data['time_windows']):
#         if location_idx == 0:
#             continue
#         index = manager.NodeToIndex(location_idx)
#         time_dimension.CumulVar(index).SetRange(time_window[0], time_window[1])
#         print(time_dimension.CumulVar(index))
#     # Add time window constraints for each vehicle start node.
#     for vehicle_id in range(data['num_vehicles']):
#         index = routing.Start(vehicle_id)
#         time_dimension.CumulVar(index).SetRange(data['time_windows'][0][0],
#                                                 data['time_windows'][0][1])
# 
#     # Instantiate route start and end times to produce feasible times.
#     for i in range(data['num_vehicles']):
#         print(routing.Start(i), routing.End(i))
#         routing.AddVariableMinimizedByFinalizer(
#             time_dimension.CumulVar(routing.Start(i)))
#         routing.AddVariableMinimizedByFinalizer(
#             time_dimension.CumulVar(routing.End(i)))
#     
#     # Define Transportation Requests.
#     for request in data['pickups_deliveries']:
#         pickup_index = manager.NodeToIndex(request[0])
#         delivery_index = manager.NodeToIndex(request[1])
#         routing.AddPickupAndDelivery(pickup_index, delivery_index)
#         routing.solver().Add(
#             routing.VehicleVar(pickup_index) == routing.VehicleVar(
#                 delivery_index))
#         routing.solver().Add(
#             distance_dimension.CumulVar(pickup_index) <=
#             distance_dimension.CumulVar(delivery_index))
#         
#     # Add Capacity constraint.
#     def demand_callback(from_index):
#         """Returns the demand of the node."""
#         # Convert from routing variable Index to demands NodeIndex.
#         from_node = manager.IndexToNode(from_index)
#         return data['demands'][from_node]
# 
#     demand_callback_index = routing.RegisterUnaryTransitCallback(
#         demand_callback)
#     routing.AddDimensionWithVehicleCapacity(
#         demand_callback_index,
#         0,  # null capacity slack
#         data['vehicle_capacities'],  # vehicle maximum capacities
#         True,  # start cumul to zero
#         'Capacity')
# 
#     # Setting first solution heuristic.
#     search_parameters = pywrapcp.DefaultRoutingSearchParameters()
#     search_parameters.first_solution_strategy = (
#         routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
# 
#     # Solve the problem.
#     solution = routing.SolveWithParameters(search_parameters)
    
    solver = GORTsp(data['distance_matrix'], data['demands'], data['vehicle_capacities'],data['pickups_deliveries'], data['time_windows'], data['depot'])
    solution = solver.solve()
    # Print solution on console.
    if solution:
        solver.print_solution( solution)
        solver.print_solutionTime(solution)


if __name__ == '__main__':
    main()