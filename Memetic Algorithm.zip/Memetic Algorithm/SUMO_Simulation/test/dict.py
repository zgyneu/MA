d={}
key0="0"
key00="0"
key01="1"
da={}
da[key00]=[0,0]
da[key01]=[0,1]
d[key0]=da
print(d)
key1='1'
key00='0'
key01='1'
da={}
da[key00]=[1,2]
da[key01]=[2,3]
d[key1]=da
print(d)


