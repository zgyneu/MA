num="a"

inner=num
print(inner)
num="b"
print(inner)
c=22
print(c.__str__())