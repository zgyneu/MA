state=[-1]*83
state[:3]=[0,1,2]
print(state)