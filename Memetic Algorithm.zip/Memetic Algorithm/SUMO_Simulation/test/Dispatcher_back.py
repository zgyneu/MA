class Dispatcher:
    """
    Dispatcher类，主要功能有：
    ①初始化调度平台，调用Netsim类、Ordersim类、Couriersim类并初始化
    ②开放调度算法接口
    构造函数：
    Dispatcher()
    接口函数：
    1 ：reset()                      重置所有骑手、订单的非固定参数
    2 ：edgetime()                   通过edge获取该edge所需时间
    3 ：findpath()                   通过src和dst两条edge，获取途径的所有edge的列表
    4 ：updateallcouriersstate()     更新所有骑手状态
    5 ：updatecourierstate()         更新指定骑手的状态
    6 ：dispatchtocourier()          将订单分配给特定骑手
    7 ：getcouriernum()              获取骑手个数
    8 ：edgetimepercent()            通过途径edge的时间，及初始offset和终点offset，获取途径此部分所需时间
    9 ：calctime()                   计算从初始边及offset到终点边及offset所需时间
    10：step()                       步进到下一订单生成时间，并更新状态
    11：getcreatetime()              获取订单创建时间
    接口变量：
    Dispatcher.courierNum               骑手个数
    Dispatcher.net                      路网对象
    Dispatcher.ordersCenter             订单中心对象
    Dispatcher.orders                   所有订单列表
    Dispatcher.orderNum                 订单数量
    Dispatcher.lastOrderTime            最后一个订单分配时间
    Dispatcher.newOrderEventLine        订单时间线列表
    Dispatcher.orderLine                当前时间
    Dispatcher.couriersCenter
    """

    def __init__(self):
        """
        构造函数
        """
        from Netsim import Netsim
        from Ordersim import OrdersCenter
        from Couriersim import CouriersCenter
        from TSP import TSP

        """以下为初始化参数"""
        self._beginTimeStr = "2016-5-18 10:00:01"  # 订单开始时间
        self._endTimeStr = "2016-5-18 10:59:59"  # 订单结束时间

        self.courierNum = 15  # 骑手个数
        self._parkingTimeConst = 5  # 骑手等待顾客取餐的时间
        self._ordersTimeLimit = 30 * 60  # 所有订单的允许时限
        self._tsp = TSP()
        """以上为初始化参数"""
        self.net = Netsim(check_map=False, override=False)
        self.ordersCenter = OrdersCenter(begin_str=self._beginTimeStr, end_str=self._endTimeStr,
                                         time_limit=self._ordersTimeLimit)
        self.orders = self.ordersCenter.get_orders()
        self.runOrders = []
        self.orderNum = self.ordersCenter.get_orders_num()
        self.lastOrderTime = self.ordersCenter.get_last_order_time()
        print("此时间段内订单数量为：", self.orderNum)
        self.newOrderEventLine = self.ordersCenter.get_new_order_event_line()
        self._newOrder = None
        self._state = None
        self.orderLine = 0
        self._bind_orders_with_parks_offset()
        self.couriersCenter = CouriersCenter(courierNum=self.courierNum, packagelimit=3)
        self.couriers = self.couriersCenter.get_couriers()
        self._bind_couriers_with_edge()
        self._edgeTravelTimeMap = self.net.get_time_map()
        self._edgesTravelPassMap = self.net.get_pass_map()

        self.orderCount=0

    def reset(self):
        """
        重置所有骑手、订单的非固定参数
        :return:
        """
        self.couriersCenter.reset()
        self.ordersCenter.reset()
        self.orders = self.ordersCenter.get_orders()
        self.runOrders = []
        self.newOrderEventLine = self.ordersCenter.get_new_order_event_line()
        self._newOrder = None
        self._state = None
        self.orderLine = 0
        self.update_all_states()
        print("len(self.orders):",len(self.orders))
        self.orderCount = 0
        return None

    def _edge_travel_time_map_func(self, edge):
        """
        通过edge获取该edge所需时间
        :param edge: edge
        :return: float
        """
        edge = str(edge)
        return self._edgeTravelTimeMap[edge]

    def _edges_travel_pass_map_func(self, src, dst):
        """
        通过src和dst两条edge，获取途径的所有edge的列表
        :param src:起始edge
        :param dst:终点edge
        :return:list
        """
        src = str(src)
        dst = str(dst)
        return self._edgesTravelPassMap[src][dst]

    def update_all_couriers_state(self, delta_time):
        """
        更新所有骑手状态
        :param delta_time:经过的时间
        :return:void
        """
        for i in self.couriers.keys():
            self.update_courier_state(i, delta_time)
            # self.updatenodes(i)

    def generate_graph(self, nodes):
        """
        给定节点，构造并返回有向图，注意：对角线和第一列均设定为0
        :return: graph
        """
        g = []
        for i in range(len(nodes)):
            r = []  # 每一行
            for j in range(len(nodes)):
                if i == j or j == 0:
                    r.append(0)  # 第一列及对角线均设定为0
                else:
                    r.append(self.calc_time(nodes[i][0], nodes[j][0], nodes[i][1], nodes[j][1]) + (
                        self._parkingTimeConst if nodes[j][-1] == 1 else 0))
            g.append(r)
        return g

    def generate_tsp_solver_params(self, nodes, s_base, c_base):
        """
        根据nodes、s_base、c_base构造并返回tsp_solver所需的参数信息
        :param c_base: 节点list中顾客节点的起始索引
        :param s_base: 节点list中商家节点的起始索引
        :param nodes: 节点list
        :return: graph,pickups_deliveries,time_windows,demands
        """
        pickups_deliveries = []
        time_windows = []
        demands = []
        orders_queue_len = c_base - s_base
        # print("c_base:", c_base, " s_base:", s_base, " orders_queue_len:", orders_queue_len)
        for i, node in nodes.items():
            if i == 0:
                time_windows.append((0, 1))
                demands.append(0)
            elif 0 < i < s_base:  # package indexs
                time_windows.append((0, node[2].update_last_and_remain_time(self.orderLine)))
                demands.append(-1)
                demands[0] += 1
            elif s_base <= i < c_base:  # shop indexs
                time_windows.append((0, node[2].update_last_and_remain_time(self.orderLine)))
                demands.append(1)
                pickups_deliveries.append([i, i + orders_queue_len])
            else:  # client indexs
                time_windows.append((0, node[2].update_last_and_remain_time(self.orderLine)))
                demands.append(-1)
        graph = self.generate_graph(nodes)
        # print("graph",graph)
        # print("pickups_deliveries",pickups_deliveries)
        # print("time_windows",time_windows)
        # print("demands",demands)
        return graph, pickups_deliveries, time_windows, demands

    def update_nodes(self, courier_id, only_return):
        """

        :param courier_id:
        :return:
        """
        courier = self.couriers[courier_id]
        current_edge = courier.get_current_edge()
        current_percent = courier.get_current_edge_percent()
        package_queue = courier.get_packages_queue()
        orders_queue = courier.get_orders_queue()
        nodes = {0: [current_edge, current_percent]}
        p_base = 1
        s_base = 1 + len(package_queue)
        c_base = s_base + len(orders_queue)
        for i, p in enumerate(package_queue):
            nodes[p_base + i] = [p.get_client_edge_idx(), p.get_client_off_percent(), p, i, 1]  # 末位1代表client
        for i, s in enumerate(orders_queue):
            nodes[s_base + i] = [s.get_shop_edge_idx(), s.get_shop_off_percent(), s, i, 0]  # 末位0代表shop
        for i, c in enumerate(orders_queue):
            nodes[c_base + i] = [c.get_client_edge_idx(), c.get_client_off_percent(), c, i, 1]  # 末位1代表client
        if not only_return:
            courier.set_nodes(nodes)
        return nodes, s_base, c_base

    def tsp_route(self, courier_id):
        """

        :return:
        """
        courier = self.couriers[courier_id]
        nodes, s_base, c_base = self.update_nodes(courier_id, only_return=True)
        graph, pickups_deliveries, time_windows, demands = self.generate_tsp_solver_params(nodes, s_base, c_base)
        # print("who:", courier_id)
        # print("time_windows:", time_windows)
        # print("pickups_deliveries:", pickups_deliveries)
        # print("demands:", demands)
        # print("nodes_length:", len(nodes))
        path, cost = self._tsp.solve_tsp(graph, pickups_deliveries, time_windows, demands)
        if path:
            courier.set_graph(graph)
            courier.set_path(path)
            courier.set_nodes(nodes)
            return True
        else:
            return False

    def update_courier_state(self, courier_id, delta_time):
        """
        更新指定骑手的状态
        :param delta_time:
        :param courier_id:骑手id
        :return:
        """

        if delta_time == 0:
            return

        courier = self.couriers[courier_id]
        status = courier.get_status()

        if status == "WaitingOrder":
            return

        package_queue = courier.get_packages_queue()
        orders_queue = courier.get_orders_queue()
        parking_time = courier.get_parking_time()

        old_nodes = courier.get_nodes()
        old_path = courier.get_path()
        nodes_len = len(old_nodes)
        delta_remain_time = float(delta_time)
        time_elapse = 0
        break_out_cycle_flag = False
        # for i, node in old_nodes.items():
        prev_node = old_nodes[0]
        for i in [0] + courier.get_path():
            if break_out_cycle_flag:  # 跳出外层循环
                break
            if i == 0:  # i==0为骑手所在位置
                continue
            else:
                node = old_nodes[i]
                heading_order = node[2]
                # print("heading:", heading_order)
                if status == "WaitingClient" and parking_time > delta_remain_time:  # 如果当前正等待顾客取餐，且行动时间不足
                    parking_time -= delta_remain_time
                    courier.set_parking_time(parking_time)
                    break
                elif status == "WaitingClient" and parking_time <= delta_remain_time:  # 如果当前正等待顾客取餐，且行动时间足够
                    delta_remain_time -= parking_time
                    time_elapse += parking_time
                    parking_time = -1
                    status = None
                    courier.set_parking_time(parking_time)
                    courier.set_status(status)
                    # print("package remove heading:", heading_order)
                    package_queue.remove(heading_order)
                    old_path.pop(0)
                    old_nodes.pop(i)
                    heading_order.set_status("Done")
                    self.ordersCenter.add_completed_order(heading_order, self.orderLine + time_elapse)
                    self.orderCount+=1
                    continue
                pass_edges = self.find_path(prev_node[0], node[0])
                pass_edges_len = len(pass_edges)
                src_percent = prev_node[1]
                dst_percent = node[1]
                prev_node = node
                if pass_edges_len == 1:  # 当节点与骑手在同一个edge时（包括骑手超越节点，此时骑手往回跑）
                    edge = pass_edges[0]
                    edge_time = self.edge_time(edge)
                    need_time = self.edge_time_percent(edge_time, src_percent, dst_percent)
                    if need_time > delta_remain_time:  # 骑手在此edge到达node前结束行动
                        if src_percent > dst_percent:
                            src_percent -= delta_remain_time / edge_time
                        else:
                            src_percent += delta_remain_time / edge_time
                        current_percent = src_percent
                        courier.set_current_edge_percent(current_percent)
                        break
                    else:  # 骑手在此edge到达node
                        delta_remain_time -= need_time
                        time_elapse += need_time
                        current_percent = dst_percent
                        courier.set_current_edge_percent(current_percent)
                        if node[-1] == 1:  # 如果是客户节点
                            if self._parkingTimeConst > delta_remain_time:  # 如果是客户节点，且行动时间不足
                                parking_time = self._parkingTimeConst - delta_remain_time
                                courier.set_parking_time(parking_time)
                                status = "WaitingClient"
                                courier.set_status(status)
                                break
                            else:  # 如果是客户节点，且行动时间足够
                                delta_remain_time -= self._parkingTimeConst
                                parking_time = -1
                                courier.set_parking_time(parking_time)
                                status = None
                                courier.set_status(status)
                                # print("package remove heading:", heading_order)
                                package_queue.remove(heading_order)
                                old_path.pop(0)
                                old_nodes.pop(i)
                                heading_order.set_status("Done")
                                self.ordersCenter.add_completed_order(heading_order, self.orderLine + time_elapse)
                                self.orderCount+=1
                                if len(old_path) == 0:
                                    status = "WaitingOrder"
                                    courier.set_status(status)
                                    break
                                continue
                        else:  # 如果是商家节点
                            parking_time = -1
                            courier.set_parking_time(parking_time)
                            status = None
                            courier.set_status(status)
                            # print("order remove heading:", heading_order)
                            orders_queue.remove(heading_order)
                            old_path.pop(0)
                            old_nodes.pop(i)
                            # print("package add heading:", heading_order)
                            package_queue.append(heading_order)
                            continue

                else:  # 当节点与骑手之间有多条边
                    for j, edge in enumerate(pass_edges):
                        edge_time = self.edge_time(edge)
                        need_time = edge_time
                        edge_src_percent = 0.0
                        edge_dst_percent = 1.0
                        if j == 0:
                            edge_src_percent = src_percent
                            need_time = self.edge_time_percent(edge_time, src_percent=src_percent)
                        elif j == pass_edges_len - 1:
                            edge_dst_percent = dst_percent
                            need_time = self.edge_time_percent(edge_time, dst_percent=dst_percent)
                        if need_time > delta_remain_time:  # 骑手在此edge到达dst前结束行动
                            edge_src_percent += delta_remain_time / edge_time
                            current_edge = edge
                            current_percent = edge_src_percent
                            courier.set_current_edge_percent(current_percent)
                            courier.set_current_edge(current_edge)
                            delta_remain_time = 0
                            break_out_cycle_flag = True
                            break
                        else:  # 骑手在此edge到达dst
                            delta_remain_time -= need_time
                            time_elapse += need_time
                            if j == pass_edges_len - 1:  # 如果到达节点
                                current_edge = edge
                                current_percent = edge_dst_percent
                                courier.set_current_edge_percent(current_percent)
                                courier.set_current_edge(current_edge)
                                if node[-1] == 1:  # 如果是客户节点
                                    if self._parkingTimeConst > delta_remain_time:  # 如果是客户节点，且行动时间不足
                                        parking_time = self._parkingTimeConst - delta_remain_time
                                        courier.set_parking_time(parking_time)
                                        status = "WaitingClient"
                                        courier.set_status(status)
                                        delta_remain_time = 0
                                        break_out_cycle_flag = True
                                        break
                                    else:  # 如果是客户节点，且行动时间足够
                                        delta_remain_time -= self._parkingTimeConst
                                        time_elapse += self._parkingTimeConst
                                        parking_time = -1
                                        courier.set_parking_time(parking_time)
                                        status = None
                                        courier.set_status(status)
                                        # print("package remove heading:", heading_order)
                                        package_queue.remove(heading_order)
                                        old_path.pop(0)
                                        old_nodes.pop(i)
                                        heading_order.set_status("Done")
                                        self.ordersCenter.add_completed_order(heading_order,
                                                                              self.orderLine + time_elapse)
                                        self.orderCount += 1
                                        if len(old_path) == 0:
                                            status = "WaitingOrder"
                                            courier.set_status(status)
                                            break
                                        continue
                                else:  # 如果是商家节点
                                    parking_time = -1
                                    courier.set_parking_time(parking_time)
                                    status = None
                                    courier.set_status(status)
                                    # print("order remove heading:", heading_order)
                                    orders_queue.remove(heading_order)
                                    old_path.pop(0)
                                    old_nodes.pop(i)
                                    # print("package add heading:", heading_order)
                                    package_queue.append(heading_order)
                                    continue
                            else:  # 如果未到达节点（只走完了这条边）
                                continue

        old_nodes[0] = [courier.get_current_edge(), courier.get_current_edge_percent()]
        # print("pos percent:",self.net.getcordspercentbyedgeandoff(old_nodes[0][0],old_nodes[0][1]))
        courier.set_nodes(old_nodes)
        courier.set_packages_queue(package_queue)
        courier.set_orders_queue(orders_queue)
        courier.set_path(old_path)
        self.update_state(courier_id)

    def update_all_states(self):
        for courier_id in self.couriers.keys():
            self.update_state(courier_id)

    def update_state(self, courier_id):
        courier = self.couriers[courier_id]
        nodes = courier.get_nodes()
        path = courier.get_path()
        x_percent, y_percent = self.net.get_percent_by_edge_and_off(courier.get_current_edge(),
                                                                    courier.get_current_edge_percent())
        p_percent = len(courier.get_packages_queue()) / courier.get_package_limit()
        state = [-1] * 83
        state[:3] = [x_percent, y_percent, p_percent]
        for i, p in enumerate(path):
            node = nodes[p]
            node_edge_idx = node[0]
            node_off_percent = node[1]
            mark = 1 if node[-1] else -1  # client置1，shop置-1
            if mark == 1:
                remain_percent = node[2].update_last_and_remain_time(self.orderLine) / node[2].get_time_limit()
            else:
                remain_percent = -1
            x_percent, y_percent = self.net.get_percent_by_edge_and_off(node_edge_idx, node_off_percent)
            state[3 + i * 4:3 + (i + 1) * 4] = [x_percent, y_percent, remain_percent, mark]
        courier.set_state(state)

    def dispatch_to_courier(self, courier_id, new_order):
        """
        将订单分配给特定骑手
        :param new_order:新订单
        :param courier_id:骑手id
        :return:void
        """

        courier = self.couriers[courier_id]
        new_order.state = self._state
        new_order.action = courier_id
        courier.accept_new_order(new_order)
        if self.tsp_route(courier_id):  # 有解则分配，无解则抛弃
            new_order.set_status("Dispatched")
            if courier.get_status() == "WaitingOrder":
                courier.set_status(None)
            self.ordersCenter.add_to_dispatched_orders(new_order)
            self.update_state(courier_id)
        else:
            new_order.set_status("Dismiss")
            # print("Dismiss")
            self.ordersCenter.add_to_dismissed_orders(new_order)
            courier.pop_new_order()
            new_order.reward = -1  # 如果该分配不符合 time_window 则置reward为-1
            self.orderCount += 1

        # self.updatecourierstate(courier_id, delta_time=0)

    def _bind_orders_with_parks_offset(self):
        """
        初始化所有订单
        :return:void
        """
        parkoffpercentmap = self.net.get_park_off_percent_map()
        parktoedgemap = self.net.get_park_to_edge_map()
        for order in self.orders:
            order.set_shop_edge_and_off_percent(edge=parktoedgemap[order.get_shop_park_idx()],
                                                percent=parkoffpercentmap[order.get_shop_park_idx()])
            order.set_client_edge_and_off_percent(edge=parktoedgemap[order.get_client_park_idx()],
                                                  percent=parkoffpercentmap[order.get_client_park_idx()])
        self.ordersCenter.set_const_orders_deep_copy(self.orders)
        del parkoffpercentmap
        del parktoedgemap

    def _bind_couriers_with_edge(self):
        """
        初始化所有骑手
        :return:void
        """
        revedgesmap = self.net.get_rev_edge_map()
        edgesidx = list(revedgesmap.keys())[:self.courierNum]
        for i, courier in self.couriers.items():
            courier.set_init_edge_and_off_percent(edge=edgesidx[i])

        del revedgesmap

    def find_path(self, src_edge, dst_edge):
        """
        通过src和dst两条edge，获取途径的所有edge的列表
        :param src_edge: src所在的edge
        :param dst_edge: dst所在的edge
        :return: 起点到终点途径的edge列表
        """
        return self._edges_travel_pass_map_func(src_edge, dst_edge)

    def get_courier_num(self):
        """
        获取骑手个数
        :return:int
        """
        return self.courierNum

    def get_order_num(self):
        """

        :return:
        """
        return self.orderNum

    def edge_time(self, edge):
        """
        通过edge获取该edge所需时间
        :param edge:
        :return:
        """
        return self._edge_travel_time_map_func(edge)

    def edge_time_percent(self, time, src_percent=0.0, dst_percent=1.0):
        """
        通过途径edge的时间，及初始offset和终点offset，获取途径此部分所需时间
        :param time:途径整条edge的时间
        :param src_percent:初始offset
        :param dst_percent:终点offset
        :return:float
        """
        return abs(dst_percent - src_percent) * time

    def calc_time(self, src_edge, dst_edge, src_percent=0.0, dst_percent=1.0):
        """
        计算从初始边及offset到终点边及offset所需时间
        :param src_edge: src所在的edge
        :param src_percent: src所在edge的百分比（注意，1.0-percent是需要途径的比例）
        :param dst_edge: dst所在的edge
        :param dst_percent: dst所在edge的百分比
        :return: 从起点位置到终点所需时间
        """

        edges = self.find_path(src_edge, dst_edge)
        if len(edges) == 0:
            print("地图数据错误，有未连通的边 ", src_edge, " => ", dst_edge, " ，请检查并重新生成地图数据")
            return None
        elif len(edges) == 1:
            return abs(dst_percent - src_percent) * self._edge_travel_time_map_func(src_edge)
        else:
            time_total = 0
            for i, edge in enumerate(edges):
                if i == 0:
                    time_total += self._edge_travel_time_map_func(src_edge) * (1.0 - src_percent)
                elif i == len(edges) - 1:
                    time_total += self._edge_travel_time_map_func(dst_edge) * dst_percent
                else:
                    time_total += self._edge_travel_time_map_func(edge)
            return time_total

    def collect_states(self, new_order):
        """
        0:时间戳percent 1~4:新订单shop(x,y)、新订单client(x,y) percent
        5+n*83:各骑手state
        :return:
        """
        state = [-1] * (5 + self.courierNum * 83)
        # print("len state1:", len(state))
        # print("self._courierNum:",self._courierNum)
        time_percent = self.orderLine / self.lastOrderTime
        shop_x_percent, shop_y_percent = self.net.get_percent_by_edge_and_off(new_order.get_shop_edge_idx(),
                                                                              new_order.get_shop_off_percent())
        client_x_percent, client_y_percent = self.net.get_percent_by_edge_and_off(new_order.get_client_edge_idx(),
                                                                                  new_order.get_client_off_percent())
        state[:5] = [time_percent, shop_x_percent, shop_y_percent, client_x_percent, client_y_percent]
        for n, courier in self.couriers.items():
            # print("len(courier.getstate()):",len(courier.getstate()))
            state[(5 + n * 83):(5 + (n + 1) * 83)] = courier.get_state()
        # print("collect state:",state)
        # print("len state:",len(state))
        return state

    def step(self, action=None, action_prob=None):
        """
        步进到下一订单生成时间，并更新状态
        :return:tuple
        """
        _state = []
        _reward = []
        _done = False
        available_actions = [1] * self.courierNum
        available_actions = [i for i, x in enumerate(available_actions) if x == 1]
        if action:  # 如果有分派，则分派，没有则直接执行到新的时间点
            self.dispatch_to_courier(action, self._newOrder)
            self._newOrder = None
            self._state = None

        order = self.ordersCenter.new_order()  # 新订单，先运行到新时间点，并返回state
        if order:
            self.runOrders.append(order)
            time_line = self.newOrderEventLine.pop(0)
            delta_time = time_line - self.orderLine
            self.orderLine = time_line
            self.update_all_couriers_state(delta_time)
            _state = self.collect_states(new_order=order)
            self._state = _state
            self._newOrder = order
        else:  # 已分配完所有订单
            self.update_all_couriers_state(delta_time=2400 * 60)
            _done = True
            print("runOrders reward:")
            for order in self.runOrders:
                print(order.reward)
            print("self.ordercount:", self.orderCount)
        return _state, _done, available_actions

    def display(self):
        """
        for test
        :return:
        """
        for i in self.couriers.keys():
            self.display_one(i)

    def display_one(self, courier_id):
        """
        for test
        :param courier_id:
        :return:
        """
        if courier_id != 0:
            return
        courier = self.couriers[courier_id]
        print("骑手 %2d status: %14s edge: %4d off: %6.2f" % (
            courier.get_id(), courier.get_status(), courier.get_current_edge(), courier.get_current_edge_percent()), end="  ")
        nodes = courier.get_nodes()
        path = courier.get_path()
        path = [0] + path
        for i in range(len(path)):
            if i == 0:
                continue
            else:
                need_time = self.calc_time(nodes[path[i - 1]][0], nodes[path[i]][0], nodes[path[i - 1]][1],
                                           nodes[path[i]][1])
                edges_len = len(self.find_path(nodes[path[i - 1]][0], nodes[path[i]][0]))
                print("=== %6.2f s and %3d,edges ===>  %4d" % (need_time, edges_len,
                                                               nodes[path[i]][2].get_client_edge_idx() if nodes[path[i]][
                                                                   -1] else
                                                               nodes[path[i]][2].get_shop_edge_idx()), end="  ")
        print("")


if __name__ == '__main__':
    from random import randint
    import time

    dispatcher = Dispatcher()
    dispatcher.reset()
    done = False
    while True:

        time.sleep(0.1)
        dispatcher.display()
        done = dispatcher.step(randint(0, dispatcher.get_courier_num() - 1))
        print("order:", dispatcher.ordersCenter.get_dispatched_orders_num())

        if done:
            dispatcher.reset()
            break
