import random

for i in range(200):
    print(random.randint(0, 14))