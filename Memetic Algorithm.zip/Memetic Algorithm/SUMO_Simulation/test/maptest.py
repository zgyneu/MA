m = {5: 0, 6: 1, 2: 2}

m = sorted(m.items(), key=lambda d: d[0])
print(m)

for k,v in m:
    print(k,v)