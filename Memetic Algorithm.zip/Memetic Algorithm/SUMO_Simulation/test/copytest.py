import copy

path0=[1,2,3,4]
path1=copy.copy(path0)

print(path0,path1)

path0=[2]

print(path0,path1)