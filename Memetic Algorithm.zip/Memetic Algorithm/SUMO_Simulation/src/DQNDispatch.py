# -*- coding: utf-8 -*-
"""
@Time ： 2020/7/28 19:28
@Auth ： Xiangyu Kong
@File ： DQN.py
@IDE  ： PyCharm
@Info ： .
"""
import sys
import time
import json
import pandas as pd
import matplotlib
from matplotlib import pyplot as plt

matplotlib.rcParams['font.size'] = 18
matplotlib.rcParams['figure.titlesize'] = 18
matplotlib.rcParams['figure.figsize'] = [9, 7]
matplotlib.rcParams['font.family'] = ['KaiTi']
matplotlib.rcParams['axes.unicode_minus'] = False

plt.figure()

import collections
import random
import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, optimizers, losses
from Dispatcher_Periodic import Dispatcher

tf.random.set_seed(2333)
np.random.seed(2333)
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
assert tf.__version__.startswith('2.')

dispatcher = Dispatcher()
TrainOrderNum = dispatcher.ORDERS_CENTER.orderNum
# Hyperparameters
learning_rate = 0.0002
gamma = 0.99  # 激励衰减因子
buffer_limit = TrainOrderNum * 100  # O2O.TrainOrderNum*50
trainTimes = 100  # 训练回合数   20000
batch_size = 32  # batch size
sample_number = 0
if TrainOrderNum <= batch_size * 2:
    sample_number = batch_size
else:
    sample_number = TrainOrderNum // batch_size // 2 * batch_size

layer1_weight = 512
layer2_weight = 2048
Interval_by_order = True

newNet = True  # 仅在使用新参数后的第一次训练置为True，之后置为False，否则将覆盖训练的网络变量
training = True  # 训练数据时为True，测试时为False
saveNet = True  # 是否保存本次训练的网络

minTime = float('inf')  # 训练过程中，最小的回合耗时
minEpoch = 0  # 记录训练过程中，最小的回合耗时在哪个epoch
timeStamp = time.strftime("%Y%m%d%H%M", time.localtime(time.time()))


def mkdir(path):
    """创建文件夹"""
    path = path.strip()
    path = path.rstrip("\\")
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        print(path, " 文件夹创建成功")
        return True
    else:
        print(path, "目录已存在")
        return False


print_interval = 20
if not training:
    newNet = False
    trainTimes = 1
    saveNet = False
    print_interval = 1

# GPU显存占用设置，防止同时跑多组训练时发生冲突
gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
tf.config.experimental.set_virtual_device_configuration(
    gpus[0],
    [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=512)]
)


class ReplayBuffer():
    # 经验回放池
    def __init__(self):
        # 双向队列
        self.buffer = collections.deque(maxlen=buffer_limit)

    def put(self, transition):
        self.buffer.append(transition)

    def sample(self, n):
        # 从回放池采样n个5元组
        mini_batch = random.sample(self.buffer, n)
        s_lst, a_lst, r_lst, s_prime_lst, done_mask_lst = [], [], [], [], []
        # 按类别进行整理
        for transition in mini_batch:
            s, a, r, s_prime, done_mask = transition
            s_lst.append(s)
            a_lst.append([a])
            r_lst.append([r])
            s_prime_lst.append(s_prime)
            done_mask_lst.append([done_mask])
        # 转换成Tensor
        # print("s_lst:",s_lst)
        # print("a_lst:",a_lst)
        # print("r_lst:",r_lst)
        # print("s_prime_lst:",s_prime_lst)
        # print("done_mask_lst",done_mask_lst)
        return tf.constant(s_lst, dtype=tf.float32), \
               tf.constant(a_lst, dtype=tf.int32), \
               tf.constant(r_lst, dtype=tf.float32), \
               tf.constant(s_prime_lst, dtype=tf.float32), \
               tf.constant(done_mask_lst, dtype=tf.float32)

    def size(self):
        return len(self.buffer)


class Qnet(keras.Model):
    def __init__(self):
        # 创建Q网络，输入为状态向量，输出为动作的Q值
        super(Qnet, self).__init__()
        self.fc1 = layers.Dense(layer1_weight, kernel_initializer='he_normal')
        self.fc2 = layers.Dense(layer2_weight, kernel_initializer='he_normal')
        self.fc3 = layers.Dense(dispatcher.COURIERS_CENTER.courierNum, kernel_initializer='he_normal')

    def call(self, x, training=None):
        x = tf.nn.relu(self.fc1(x))
        x = tf.nn.relu(self.fc2(x))
        x = self.fc3(x)
        return x

    def sample_action(self, s, epsilon, availableActions):
        # 送入状态向量，获取策略: [4]
        s = tf.constant(s, dtype=tf.float32)

        # s: [4] => [1,4]
        s = tf.expand_dims(s, axis=0)
        # print("s1: ",s)
        out = self(s)[0]
        # print("out:",out)
        out = tf.gather(out, availableActions, axis=0)
        coin = random.random()
        # 策略改进：e-贪心方式
        if coin < epsilon:
            # epsilon大的概率随机选取
            return random.choice(availableActions)
        else:  # 选择Q值最大的动作
            return int(availableActions[tf.argmax(out)])


def train(q, q_target, memory, optimizer):
    # 通过Q网络和影子网络来构造贝尔曼方程的误差，
    # 并只更新Q网络，影子网络的更新会滞后Q网络
    huber = losses.Huber()
    for i in range(50):  # 训练50次
        # 从缓冲池采样
        s, a, r, s_prime, done_mask = memory.sample(sample_number)
        # print("len(s): ",len(s)," s:",s)
        # print("a:",a)
        # print("r:",r)
        # print("s_prime:",s_prime)
        # print("done:",done_mask)
        with tf.GradientTape() as tape:
            # s: [b, 4]
            q_out = q(s)  # 得到Q(s,a)的分布
            # print(q_out)
            # gather_nd需要的坐标参数，indices:[b, 2]
            indices = tf.expand_dims(tf.range(a.shape[0]), axis=1)
            indices = tf.concat([indices, a], axis=1)
            # print(indices)
            q_a = tf.gather_nd(q_out, indices)  # 动作的概率值, [b]
            q_a = tf.expand_dims(q_a, axis=1)  # [b]=> [b,1]
            # print(q_a)
            # 得到Q(s',a)的最大值，它来自影子网络！ [b,4]=>[b,2]=>[b,1]
            max_q_prime = tf.reduce_max(q_target(s_prime), axis=1, keepdims=True)
            # 构造Q(s,a_t)的目标值，来自贝尔曼方程
            target = r + gamma * max_q_prime * done_mask
            # 计算Q(s,a_t)与目标值的误差
            loss = huber(q_a, target)
        # 更新网络，使得Q(s,a_t)估计符合贝尔曼方程
        grads = tape.gradient(loss, q.trainable_variables)
        # for p in grads:
        #     print(tf.norm(p))
        # print(grads)
        optimizer.apply_gradients(zip(grads, q.trainable_variables))


def main():
    global trainTimes
    q = Qnet()  # 创建Q网络
    q_target = Qnet()  # 创建影子网络
    if not newNet:
        q.load_weights('../models/q-weights.ckpt')
        q_target.load_weights('../models/q_target-weights.ckpt')
    else:
        for src, dest in zip(q.variables, q_target.variables):
            dest.assign(src)  # 影子网络权值来自Q
    memory = ReplayBuffer()  # 创建回放池
    returns = []  # 统计总回报
    meanTimes = []  # 平均每单完成时间
    efficiency_record = []
    Record = []
    RecordPerNEpisodes = []
    # PerN=10 # 每 N episodes 存储一下运行记录 ['action', 'score', 'time']
    today = timeStamp
    path = "../record/segment/" + today
    mkdir(path)
    totalTime = 0  # 一段时间内所有订单完成总时间
    score = 0.0
    optimizer = optimizers.Adam(lr=learning_rate)
    n_epi = 0
    while n_epi < trainTimes:  # 训练次数
        # epsilon概率也会8%到1%衰减，越到后面越使用Q值最大的动作
        print("当前训练回合：", n_epi + 1, "/", trainTimes)
        print("time:", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time())))  # debug
        actionCollector = []
        scoreCollector = []
        timeCollector = []
        if training:  # 作为训练时，贪婪几率>0
            if newNet:
                epsilon = max(0.01, 0.08 - 0.1 * (n_epi / trainTimes))
            else:
                epsilon = max(0.01, 0.08 - 0.1 * (n_epi / trainTimes))
        else:  # 测试时，贪婪几率=0
            epsilon = 0
        s = dispatcher.reset()  # 复位环境
        availableActions = []
        while True:  # 一个回合最大时间戳
            if s:
                # print("s:",s," availableActions:",availableActions)
                action = q.sample_action(s, epsilon, availableActions)
                # print("action:",action)
                # print("Debug info: action ",action)
                next_state, done, availableActions = dispatcher.step(action)
                print(action, " ", end="")  # debug
            else:
                next_state, done, availableActions = dispatcher.step()

            s = next_state  # 刷新状态
            if done:  # 回合结束
                # print("len(dispatcher.runOrders):",len(dispatcher.ORDERS_CENTER.dispatchedOrders))
                efficiency = len(dispatcher.ORDERS_CENTER.completedOrders) / dispatcher.ORDERS_CENTER.orderNum
                for i, order in enumerate(dispatcher.ORDERS_CENTER.dispatchedOrders):
                    if i != len(dispatcher.ORDERS_CENTER.dispatchedOrders) - 1:
                        m_done_mask = 1.0
                        m_next_state = dispatcher.ORDERS_CENTER.dispatchedOrders[i + 1].state
                    else:
                        m_done_mask = 0.0
                        m_next_state = order.state
                    m_state = order.state
                    m_action = order.action
                    m_reward = order.reward
                    m_last = order.last / 60
                    actionCollector.append(m_action)
                    scoreCollector.append(m_reward)
                    timeCollector.append(m_last)  # 单位分钟
                    score += m_reward
                    totalTime += m_last
                    if training:
                        memory.put((m_state, m_action, m_reward, m_next_state, m_done_mask))

                print("actionCollector :", actionCollector)
                Record.append([actionCollector, scoreCollector, timeCollector, efficiency])
                RecordPerNEpisodes.append([actionCollector, scoreCollector, timeCollector, efficiency])
                n_epi += 1
                break

        if memory.size() > (batch_size if newNet else batch_size * 80) and training:  # 缓冲池只有大于200就可以训练   batch_size
            train(q, q_target, memory, optimizer)

        if (n_epi + 1) % print_interval == 0 and n_epi != 0:
            returns.append(score / print_interval)
            meanTimes.append(totalTime / print_interval / TrainOrderNum)
            efficiency_record.append(efficiency / print_interval)
            print(
                "# of episode :{}, avg score : {:.1f}, avg time : {:.1f}, min avg time : {:.1f} at : {},buffer size : {}, " \
                "epsilon : {:.1f}%" \
                    .format(n_epi + 1, score / print_interval, totalTime / print_interval / TrainOrderNum,
                            minTime / TrainOrderNum, minEpoch, memory.size(), epsilon * 100))

            for src, dest in zip(q.variables, q_target.variables):
                dest.assign(src)  # 影子网络权值来自Q

            keys = ['action', 'score', 'time', 'efficiency']
            rec = [dict(zip(keys, item)) for item in RecordPerNEpisodes]
            str_json = json.dumps(rec, indent=2, ensure_ascii=False)
            with open("../record/segment/%s/%s.json" % (today, n_epi + 1), "w") as jf:
                jf.write(str_json)
                jf.close()
            RecordPerNEpisodes.clear()
            score = 0.0
            efficiency = 0.0
            totalTime = 0
    if training and saveNet:
        # 训练完成后，保存网络
        q.save_weights('../models/q-weights.ckpt')
        q_target.save_weights('../models/q_target-weights.ckpt')

    plot_path = "dqn-tf-o2o-%s" % timeStamp
    mkdir("../plots/%s" % plot_path)

    info_path = '../plots/%s/info-%s-%s.txt' % (plot_path, ('train' if training else 'test'), timeStamp)
    with open(info_path, "w", encoding='UTF-8') as train_info:
        print(
            'Train date:', timeStamp, '\n',
            'New net:\t', newNet, '\n',
            'Order number:\t', TrainOrderNum, '\n',
            'Courier number:\t',dispatcher.COURIERS_CENTER.courierNum,'\n',
            'Courier package limit:\t',dispatcher.COURIERS_CENTER.packageLimit,'\n',
            'Begin time:\t', dispatcher.begin_time_str, '\n',
            'End time:\t', dispatcher.end_time_str, '\n',
            'Learning rate:\t', learning_rate, '\n',
            'Gamma:\t', gamma, '\n',
            'Train times:\t', trainTimes, '\n',
            'Batch size:\t', batch_size, '\n',
            'Layer1 weight:\t', layer1_weight, '\n',
            'Layer2 weight:\t', layer2_weight, '\n',
            'Interval by order:\t', Interval_by_order, '\n',
            file=train_info)

        sys.stdout.flush()
        train_info.close()

    plt.figure()
    plt.plot(np.arange(len(returns)) * print_interval, np.array(returns))
    plt.plot(np.arange(len(returns)) * print_interval, np.array(returns), 's')
    plt.xlabel('回合数')
    plt.ylabel('总回报')
    plt.savefig('../plots/%s/dqn-tf-o2o-score-%s-%s.svg' % (plot_path, ('train' if training else 'test'), timeStamp))

    plt.figure()
    plt.plot(np.arange(len(meanTimes)) * print_interval, np.array(meanTimes))
    plt.plot(np.arange(len(meanTimes)) * print_interval, np.array(meanTimes), 's')
    plt.xlabel('回合数')
    plt.ylabel('平均每单完成时间(分钟)')
    plt.savefig('../plots/%s/dqn-tf-o2o-avgtime-%s-%s.svg' % (plot_path, ('train' if training else 'test'), timeStamp))

    plt.figure()
    plt.plot(np.arange(len(efficiency_record)) * print_interval, np.array(efficiency_record))
    plt.plot(np.arange(len(efficiency_record)) * print_interval, np.array(efficiency_record), 's')
    plt.xlabel('回合数')
    plt.ylabel('有效率')
    plt.savefig(
        '../plots/%s/dqn-tf-o2o-efficiency-%s-%s.svg' % (plot_path, ('train' if training else 'test'), timeStamp))

    keys = ['action', 'score', 'time', 'efficiency']
    rec = [dict(zip(keys, item)) for item in Record]
    str_json = json.dumps(rec, indent=2, ensure_ascii=False)
    with open("../record/Record-%s-%s.json" % (('train' if training else 'test'), timeStamp), "w") as jf:
        jf.write(str_json)

    # times = [x[-1] for x in Record]
    # epoch = list(range(len(times)))
    # data = dict(zip(epoch, times))
    # df = pd.DataFrame(data)
    # df.plot.box(title="every order's completion time")
    # plt.xlabel('回合数')
    # plt.ylabel('订单完成时间')
    # plt.grid(linestyle="--", alpha=0.3)
    # plt.savefig('../plots/dqn-tf-o2o-boxplot-%s-%s.svg' % (('train' if training else 'test'), timeStamp))


if __name__ == '__main__':
    main()
    print("end")
