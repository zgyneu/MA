def mkdir(path):
    """创建文件夹"""
    import os
    path = path.strip()
    path = path.rstrip("\\")
    is_exists = os.path.exists(path)
    if not is_exists:
        os.makedirs(path)
        print(path, " 文件夹创建成功")
        return True
    else:
        print(path, "目录已存在")
        return False


def avg_list(list_data):
    list_len = len(list_data)
    return sum_list(list_data) / list_len


def sum_list(list_data):
    list_sum = 0
    for e in list_data:
        list_sum += e
    return list_sum


def avg_per_n_epochs(list_sum, list_len):
    return list_sum / list_len


def visualize():
    trend_date = '202101241238'
    trend_files_dir_base_path = '../record/segment/'
    trend_files_dir_path = trend_files_dir_base_path + trend_date + '/'  # for test
    import json
    import os
    print("Processing : 正在读取json文件")
    json_dir = os.scandir(trend_files_dir_path)
    json_files = []
    for f in json_dir:
        json_files.append(f.name)
    json_dir.close()
    json_files = sorted(json_files, key=lambda item: int(item.partition(".")[0]))
    avg_score_data = []
    avg_time_data = []
    avg_efficiency_data = []
    for file in json_files:
        with open(trend_files_dir_path + file, 'r', encoding='UTF-8') as f:
            file_data = json.load(f)
            # epochs_len = len(file_data)
            sum_score_data = []
            sum_time_data = []
            efficiency_data = []
            for epoch_data in file_data:
                sum_score_data.append(sum_list(epoch_data['score']))
                sum_time_data.append(sum_list(epoch_data['time']))
                efficiency_data.append(epoch_data['efficiency'])
            f.close()
            avg_score_data.append(avg_list(sum_score_data))
            avg_time_data.append(avg_list(sum_time_data) / 60)
            avg_efficiency_data.append(avg_list(efficiency_data))
    mkdir("../plots/%s" % 'dqn-tf-o2o-' + trend_date)
    plot_trend(avg_score_data, trend_date, '总回报', 'score')
    plot_trend(avg_time_data, trend_date, '平均每单完成时间(分钟)', 'avgtime')
    plot_trend(avg_efficiency_data, trend_date, '有效率', 'efficiency')


def plot_trend(plot_data, trend_date, y_label, unique_name, print_interval=20):
    import matplotlib
    from matplotlib import pyplot as plt
    import numpy as np
    matplotlib.rcParams['font.size'] = 18
    matplotlib.rcParams['figure.titlesize'] = 18
    matplotlib.rcParams['figure.figsize'] = [9, 7]
    matplotlib.rcParams['font.family'] = ['KaiTi']
    matplotlib.rcParams['axes.unicode_minus'] = False
    plt.figure()
    plt.plot(np.arange(len(plot_data)) * print_interval, np.array(plot_data))
    plt.plot(np.arange(len(plot_data)) * print_interval, np.array(plot_data), '.')
    plt.xlabel('回合数')
    plt.ylabel(y_label)
    plt.savefig('../plots/%s/dqn-tf-o2o-%s-%s-%s.svg' % ('dqn-tf-o2o-' + trend_date, unique_name, 'train', trend_date))


if __name__ == '__main__':
    visualize()
