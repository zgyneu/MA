from Ordersim import Order


# Couriersim模块共有CouiersCenter和Courier两个类
class CouriersCenter:
    """
    CouriersCenter类，主要功能有：
    ①：给定骑手个数并初始化所有骑手
    ②：新的episode重置所有骑手非固定参数
    ③：托管所有骑手对象
    构造函数：
    CouriersCenter(courierNum, packagelimit)
    接口函数：
    1 ：reset()                  重置所有骑手非固定参数
    接口变量：
    CouriersCenter.couriers         所有骑手的map，id => courier
    CouriersCenter.courierNum       所有骑手数量
    CouriersCenter.packageLimit     所有骑手携带容量上限
    """

    def __init__(self, courier_num, package_limit=3, parking_time=5):
        """
        构造函数
        :param courier_num: 骑手个数
        :param package_limit: 骑手携带容量限制
        :param parking_time：骑手等待顾客时间
        """
        self.parkingTimeConst = parking_time
        self.couriers = {}  # id => courier
        self.courierNum = courier_num
        self.packageLimit = package_limit
        for i in range(courier_num):
            self.couriers[i] = Courier(i, package_limit, 0)

    def reset(self):
        """
        对所有托管的骑手重置非固定参数
        :return:void
        """
        for courier in self.couriers.values():
            courier.reset()


class Courier:
    """
    Courier类，主要功能有：
    ①：定义并初始化骑手骑手
    ②：重置骑手非固定参数
    构造函数：
    Courier(vehid, packagelimit, initedge)
    接口函数：
    1 ：reset()                      重置非固定参数
    2 ：setinitedgeandoffpercent()   设置初始边和offset
    接口变量：
    Courier.id                              骑手id
    Courier.packageLimit                    骑手容量限制
    Courier.parkingTime                     在等待顾客取餐的时间,-1表示未处于等待顾客取餐
    Courier.packagesQueue                   骑手携带的订单列表
    Courier.ordersQueue                     骑手尚未携带的订单列表
    Courier.nodes                           骑手的路径节点map
    Courier.path                            骑手的路径列表
    Courier.graph                           骑手节点有向图
    Courier.status                          骑手状态，默认"WaitingOrder"，此外还有"WaitingClient"，其余配送状态为None
    Courier.currentEdge                     当前所在edge
    Courier.currentEdgePercent              当前所在edge的offset percent
    Courier.headingOrder                    正在前往的Order
    Courier.state                           存储骑手各自的state
    """

    def __init__(self, vehid, packagelimit, initedge):
        """
        构造函数
        :param vehid: 骑手id
        :param packagelimit: 骑手携带容量限制
        :param initedge: 骑手初始生成所在的边
        """
        self.id = vehid
        self.packageLimit = packagelimit
        self._initEdge = initedge
        self._initOff = 0

        """以下为每episode须重新初始化的参数"""
        self.parkingTime = -1  # 在等待顾客取餐的时间,-1表示未处于等待顾客取餐
        self.waitingOrder = None  # 在等待顾客取餐的订单
        self.packagesQueue: list[Order] = []  # 可携带订餐上限为 self._packageLimit
        self.ordersQueue = []  # 订单队列
        self.path = []  # 骑手的路线列表，每个元素对应nodes的key,注意nodes的[0]对应骑手当前位置，所以path取[1:]
        self.currentEdge = self._initEdge  # 当前所在edge
        self.currentEdgePercent = self._initOff  # 当前所在edge的offset percent
        self.state = []  # 存储骑手各自的state

        """以上为每episode须重新初始化的参数"""

    def reset(self):
        """
        重置非固定参数
        :return:void
        """
        self.parkingTime = -1
        self.waitingOrder = None  # 在等待顾客取餐的订单
        self.ordersQueue = []
        self.packagesQueue: list[Order] = []
        self.path = []
        self.currentEdge = self._initEdge
        self.currentEdgePercent = self._initOff
        self.state = []

    def set_init_edge_and_off_percent(self, edge, offset=0):
        """
        设置初始边和offset
        :return:void
        """
        self._initEdge = edge
        self._initOff = offset
        self.currentEdge = self._initEdge
        self.currentEdgePercent = self._initOff
