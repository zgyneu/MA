class Netsim:
    """
    Netsim模块Netsim类，主要功能有：
    ①：给入路网数据，利用SUMO生成各edge到所有edge的二维列表，每个元素为：途径的edge列表
    ②：给入路网数据，利用SUMO生成各edge跑下来需要花费的时间，每个元素为：该edge跑下来花费的时间
    ③：托管路网、停车场、路径等数据
    构造函数：
    Netsim(checkmap, override, src0, src1, src2, dst0, dst1)
    接口函数：
    1 ：get_cords_by_edge_and_off(self, edge_idx, off_percent)           通过给edge idx和off percent得到坐标
    2 ：get_cords_percent_by_edge_and_off(self, edge_idx, off_percent)   通过给edge idx和off percent得到坐标
    接口变量：
    Netsim.edgeTravelTimeMap        各edge走完需要花费的时间的一维字典
    Netsim.edgeTravelDistanceMap    各edge长度的一维字典
    Netsim.edgesTravelPassMap       从src边走到dst边所经过的edge列表，二维字典
    Netsim.parksOffsetPercentMap    idx => offset%
    """

    def __init__(self, check_map=False, override=False, src0="../mapdata/EdgesMap.json",
                 src1="../mapdata/ParksMap.json",
                 src2="../mapdata/Parks2EdgesMap.json",
                 dst0="../simmapdata/EdgeTravelTimeMap.json",
                 dst1="../simmapdata/EdgesTravelPassMap.json",
                 dst2="../simmapdata/EdgesTravelDistanceMap.json"):
        """
        构造函数
        参数说明：
        :param check_map: 是否需要检测地图信息，防止路网某些edge彼此不通
        :param override: 是否覆写或新建存在磁盘的数据
        :param src0: 读取 EdgesMap.json 文件位置，如 "../mapdata/EdgesMap.json"
        :param src1: 读取 ParksMap.json 文件位置，如 "../mapdata/ParksMap.json"
        :param src2: 读取 Parks2EdgesMap.json 文件位置，如 "../mapdata/Parks2EdgesMap.json"
        :param dst0: 写入 EdgeTravelTimeMap.json 文件位置，如 "../simmapdata/EdgeTravelTimeMap.json"
        :param dst1: 写入 EdgesTravelPassMap.json 文件位置，如 "../simmapdata/EdgesTravelPassMap.json"
        """
        import os
        import sys
        if 'SUMO_HOME' in os.environ:
            tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
            sys.path.append(tools)
        else:
            sys.exit("please declare environment variable 'SUMO_HOME'")

        from sumolib import checkBinary  # noqa
        import traci  # noqa

        error_map = False
        self._edgesList = []
        self._edgesPath = src0
        self._parksPath = src1
        self._parksToEdgesPath = src2
        self._edgeTravelTimeMapPath = dst0
        self._edgeTravelPassMapPath = dst1
        self._edgeTravelDistanceMapPath = dst2
        self._net = None
        self._netBoundary = []
        self._edgesMap = {}  # id => idx
        self.revEdgesMap = {}  # idx => id
        self._parksMap = {}  # id => idx
        self._revParksMap = {}  # idx => id
        self.parkToEdgeMap = {}  # idx => idx
        self._edgeToParkMap = {}  # idx => idx
        self._constVehSpeed = 5.56  # 电瓶车按速度20kph->5.56m/s  25kph->6.94m/s  15kph->4.17m/s

        # public:
        self.edgeTravelTimeMap = {}  # 各edge走完需要花费的时间的一维字典
        self.edgeTravelDistanceMap = {}  # 各edge长度的一维字典
        self.edgesTravelPassMap = {}  # 从src边走到dst边所经过的edge列表，二维字典
        self.parksOffsetPercentMap = {}  # idx => offset%

        if check_map != 0:
            error_map = self._check_map()
        if not error_map:
            self._load_edges()
            self._load_parks()
            self._load_parks_to_edges()
            self._init_sumolib()
            if override:
                self._sim_run()
                if self._recheck_map() == 0:
                    self._write_json()
                else:
                    print("Wrong map !")
                    self._write_json()
                    return
            else:
                self._read_json()
        else:
            print("Wrong map !")
            return

    def _load_edges(self):
        """
        通过读取EdgesMap.json文件，得到数据格式如下：
            "id": "-168715095#0", "idx": 0, "laneLength": 150.77, "centerPos": [5974.922210696449, 4321.256202151077]
        :update:①self._edgesList 边列表；②self._edgesMap 边id => idx； ③self._revEdgesMap 边idx => id .
        :return: void
        """
        from json import load as jload

        with open(self._edgesPath, 'r', encoding='UTF-8') as f:  # 导入所有edge数据
            edges_data = jload(f)
            f.close()
        for item in edges_data:
            self._edgesList.append(item["id"])
            self._edgesMap[item["id"]] = item["idx"]
            self.revEdgesMap[item["idx"]] = item["id"]
            self.edgeTravelTimeMap[item["idx"]] = item["laneLength"] / self._constVehSpeed
            self.edgeTravelDistanceMap[item["idx"]] = item["laneLength"]
        del edges_data

    def _load_parks(self):
        """
        通过读取ParksMap.json文件，得到数据格式如下：
            "id": "277313423#1", "idx": 0, "lane": "277313423#1_0", "off": 1, "Pos2D": [10679.54868859781, 4772.965636314679], "off%": 0.0086
        :update:①self._parksMap 停车场id => idx； ②self._revParksMap 停车场idx => id; ③self._parksOffSetPercent 停车场idx => offset% .
        :return:void
        """
        from json import load as jload

        with open(self._parksPath, 'r', encoding='UTF-8') as f:  # 导入所有park数据
            parks_data = jload(f)
            f.close()
        for item in parks_data:
            self._parksMap[item["id"]] = item["idx"]
            self._revParksMap[item["idx"]] = item["id"]
            self.parksOffsetPercentMap[item["idx"]] = item["off%"]
        del parks_data

    def _load_parks_to_edges(self):
        """
        通过读取Parks2EdgesMap.json文件，得到数据格式如下：
            "pId": "277313423#1", "eId": "277313423#1"
        :update:①self._parkToEdgeMap 停车场id => 边id； ②self._edgeToParkMap 边id => 停车场id .
        :return:void
        """
        from json import load as jload

        with open(self._parksToEdgesPath, 'r', encoding='UTF-8') as f:  # 导入所有park数据
            parks_to_edges_data = jload(f)
            f.close()
        for item in parks_to_edges_data:
            self.parkToEdgeMap[item["pIdx"]] = item["eIdx"]
            self._edgeToParkMap[item["eIdx"]] = item["pIdx"]
        del parks_to_edges_data

    def _sim_run(self):
        """
        调用traci跑图
        :update: ①self._edgeTravelTimeMap 边时间 边idx => time； ②self._edgesTravelPassMap 边到边经过的边列表 [边idx][边idx] => 边列表
        :return:void
        """
        from sumolib import checkBinary  # noqa
        import traci  # noqa

        print("启动SUMO跑图中...")
        traci.start([checkBinary('sumo'), "-c", "../osm/osm.sumocfg", "-W", "true"])
        total_edge = len(self._edgesList)
        for n, e_0 in enumerate(self._edgesList):
            print("\r已完成：%.2f%%" % (float(n) / total_edge * 100), end="")
            idx_e_0 = self._edgesMap[e_0]
            # test_count = 0    # for quick test self._edgeTravelTimeMap[idx_e_0] = traci.simulation.findRoute(e_0,
            # e_0, "moto_motorcycle").travelTime  # edge => time
            e_0_map = {}
            for e_1 in self._edgesList:
                idx_e_1 = self._edgesMap[e_1]
                idx_edges = []
                for e in traci.simulation.findRoute(e_0, e_1, "moto_motorcycle").edges:
                    idx_edges.append(self._edgesMap[e])
                e_0_map[idx_e_1] = idx_edges
                # test_count += 1       # for quick test
                # if test_count > 5:        # for quick test
                #     break     # for quick test
            self.edgesTravelPassMap[idx_e_0] = e_0_map
        traci.close()
        print("跑图完成")

    def _write_json(self):
        """
        将self._edgeTravelTimeMap和self._edgesTravelPassMap写入../simmapdata/目录下
        读取格式：
        with open(jsonFilePath, 'r', encoding='UTF-8') as f:
            jsonData = json.load(f)
            f.close()
        :return:void
        """
        from json import dumps as jdumps
        from json import dump as jdump

        print("跑图信息写入磁盘...")
        self._edgeTravelTimeMapPath = "../simmapdata/EdgeTravelTimeMap.json"
        self._edgeTravelPassMapPath = "../simmapdata/EdgesTravelPassMap.json"
        self._edgeTravelDistanceMapPath = "../simmapdata/EdgesTravelDistanceMap.json"
        # j_edge_travel_time_map = jdumps(self.edgeTravelTimeMap, indent=2, ensure_ascii=False)
        # j_edge_travel_pass_map = jdumps(self.edgesTravelPassMap, indent=2, ensure_ascii=False)
        # j_edge_travel_distance_map = jdumps(self.edgeTravelDistanceMap, indent=2, ensure_ascii=False)
        # with open(self._edgeTravelTimeMapPath, 'w') as f:
        #     f.write(j_edge_travel_time_map)
        #     f.close()
        # with open(self._edgeTravelPassMapPath, 'w') as f:
        #     f.write(j_edge_travel_pass_map)
        #     f.close()
        # with open(self._edgeTravelDistanceMapPath, 'w') as f:
        #     f.write(j_edge_travel_distance_map)
        #     f.close()
        with open(self._edgeTravelTimeMapPath, 'w') as f:
            jdump(self.edgeTravelTimeMap, f, indent=2, ensure_ascii=False)
            f.close()
        with open(self._edgeTravelPassMapPath, 'w') as f:
            jdump(self.edgesTravelPassMap, f, indent=2, ensure_ascii=False)
            f.close()
        with open(self._edgeTravelDistanceMapPath, 'w') as f:
            jdump(self.edgeTravelDistanceMap, f, indent=2, ensure_ascii=False)
            f.close()
        print("写入完毕")

    def _check_map(self):
        """
        检测.net.xml边之间是否有无法连同
        :return: count 无法连通数
        """
        from sumolib import checkBinary  # noqa
        import traci  # noqa

        traci.start([checkBinary('sumo'), "-c", "../osm/osm.sumocfg", "-W", "true"])
        count = 0
        for n_0, e_0 in enumerate(self._edgesList):
            for n_1, e_1 in enumerate(self._edgesList):
                vid = str(n_0) + '->' + str(n_1)
                try:
                    traci.route.add(vid, e_0)
                    traci.vehicle.add(vid, e_0, "moto_motorcycle", depart=0)
                    traci.vehicle.changeTarget(vid, e_1)
                    traci.simulation.findRoute(e_0, e_1, "moto_motorcycle")
                except:
                    count += 1
                    print(vid)
                    print("第 ", count, " 处", "地图数据错误，有未连通的边 ", e_0, " => ", e_1, " ，请检查并重新生成地图数据")
                    print("src_edge:", e_0)
                    print("dst_edge:", e_1)

        traci.close()
        if count:
            print("共 ", count, " 个无法连接的edge对。")
        else:
            print("地图文件检测通过")
        return count

    def _recheck_map(self):
        """

        :return:
        """
        _error_count = 0
        _error_map = {}
        _debug_info = []
        _debug_info_report_path = "../simmapdata/debug_info/debug_info.txt"
        # for _test in range(10):  # for test
        #     self.edgesTravelPassMap.pop(_test)
        _park_edges = list(set(self.parkToEdgeMap.values()))
        _map_length = len(_park_edges)
        for _i in _park_edges:
            _error_map[_i] = 0
        for _i in _park_edges:
            for _j in _park_edges:
                try:
                    _edges_list = self.edgesTravelPassMap[_i][_j]
                except:
                    _error_map[_i] += 1
                    _error_map[_j] += 1
                    _edges_list = []
                if len(_edges_list) == 0:
                    _error_count += 1
                    print("第 ", _error_count, " 处", "地图数据错误，有未连通的边 ", _i, " => ", _j, " ，请检查并重新生成地图数据")
                    _debug_info.append("第 %6d   处地图数据错误，有未连通的边 %5d => %5d ，请检查并重新生成地图数据" % (_error_count, _i, _j))
                    print("src_edge:", self.revEdgesMap[_i])
                    print("dst_edge:", self.revEdgesMap[_j])
                    _debug_info.append("src_edge: %s  =>  dst_edge: %s " % (self.revEdgesMap[_i], self.revEdgesMap[_j]))
                    print()
        if _error_count == 0:
            print("地图检测无误")
        else:
            print("地图检测有误")
            _debug_info.append("\n")
            for _i, _j in _error_map.items():
                if _j > _map_length * 1 / 3:
                    print("该边错误：", self.revEdgesMap[_i])
                    _debug_info.append("该边错误： %s " % (self.revEdgesMap[_i]))
            with open(_debug_info_report_path, "w",
                      encoding='UTF-8') as _debug_file:  # ParksMap输出,键：park的ID，值：0~len(park)，作为训练使用的随机数据
                for _info in _debug_info:
                    print(_info, file=_debug_file)
                _debug_file.close()
        return _error_count

    def _stream_json_load(self, file):
        """
        流式读取json（为了读取大型json文件不爆内存），只应用于二层嵌套字典
        :param file: 要读取的json文件
        :return: dict(注意：key为字符串，最底层value为整型list)，举例：{'0': {'0': [0, 0], '1': [0, 1]}, '1': {'0': [1, 2], '1': [2, 3]}}
        """
        _parentheses_level = 0  # 处理大括号，每读取到一个 '{'则 +1，每读取到一个 '}'则 -1 ，注意：先处理大括号，值==2时，外层插入新的空字典
        _bracket_flag = False  # 处理中括号，读到 '['则置True，读到']'置False，注意：先处理中括号，
        _outer_dict_data = {}  # 待返回值，最外层大字典
        _outer_key = None  # 最外层大字典的键
        _inner_dict_data = {}  # 内层字典，作为最外层大字典的值
        _inner_key = None  # 内层字典的键
        _list_data = []  # 存储最内层值
        for _line in file:
            _number_flag = False  # 标记此行有数字
            _number_store = 0  # 用于存储数字
            for _char in _line:
                if _number_flag and ('0' <= _char <= '9'):
                    _number_store = _number_store * 10 + int(_char)
                elif '0' <= _char <= '9':
                    _number_store = int(_char)
                    _number_flag = True
                elif _char == '{' and _parentheses_level == 1:  # 新的内层字典，本身也作为key，字符串形式
                    _outer_key = _number_store.__str__()
                    _inner_dict_data = {}
                    _parentheses_level += 1
                elif _char == '{':  # 起始
                    _parentheses_level += 1
                elif _char == '}' and _parentheses_level == 2:  # 内层字典结束
                    _outer_dict_data[_outer_key] = _inner_dict_data
                    _parentheses_level -= 1
                elif _char == '}':  # 结束
                    _parentheses_level -= 1
                elif _char == '[':  # 声明新的空列表，字符串形式的key
                    _bracket_flag = True
                    _inner_key = _number_store.__str__()
                    _list_data = []
                    _number_flag = False
                elif _char == ']':  # 新列表结束，key:string ; value:list
                    _bracket_flag = False
                    _inner_dict_data[_inner_key] = _list_data

            if _bracket_flag and _number_flag:
                _list_data.append(_number_store)

        return _outer_dict_data

    def _read_json(self):
        """
        当已生成map数据，即可通过该方法读取磁盘数据到内存
        :return:Bool
        """
        from os.path import exists as exists
        from json import load as load
        if not exists(self._edgeTravelTimeMapPath):
            print(self._edgeTravelTimeMapPath, " 路径不存在！")
            return False
        if not exists(self._edgeTravelPassMapPath):
            print(self._edgeTravelPassMapPath, " 路径不存在！")
            return False
        with open(self._edgeTravelTimeMapPath, 'r', encoding='UTF-8') as f:
            self.edgeTravelTimeMap = load(f)
            f.close()
        with open(self._edgeTravelPassMapPath, 'r', encoding='UTF-8') as f:
            # self.edgesTravelPassMap = load(f)
            self.edgesTravelPassMap = self._stream_json_load(f)
            f.close()
        # print(self._edgeTravelTimeMap)
        # print(self._edgesTravelPassMap)
        print("已读取map数据")
        if len(self.edgeTravelTimeMap) != len(self._edgesList) or len(self.edgesTravelPassMap) != len(
                self._edgesList):
            print("simmapdata数据与mapdata数据不匹配，请覆写simmapdata数据")
            return False
        else:
            return True

    def _init_sumolib(self):
        """
        初始化sumolib信息
        :return:
        """
        from sumolib.net import readNet
        self._net = readNet("../osm/osm.net.xml")  # 解析.net.xml
        self._netBoundary = self._net.getBoundary()  # [xmin,ymin,xmax,ymax]

    def get_cords_by_edge_and_off(self, edge_idx, off_percent):
        """
        通过给edge idx和off percent得到坐标
        :return:cords [x,y]
        """
        from sumolib.geomhelper import positionAtShapeOffset

        edge = self._net.getEdge(self.revEdgesMap[edge_idx])
        lane = edge.getLane(0)
        shape = lane.getShape()
        length = lane.getLength()
        off = length * off_percent
        return positionAtShapeOffset(shape, off)

    def get_percent_by_edge_and_off(self, edge_idx, off_percent):
        """
        通过给edge idx和off percent得到坐标
        :return: cords percent [x,y]
        """
        pos = self.get_cords_by_edge_and_off(edge_idx, off_percent)
        return (pos[0] - self._netBoundary[0]) / (self._netBoundary[2] - self._netBoundary[0]), (
                pos[1] - self._netBoundary[1]) / \
               (self._netBoundary[3] - self._netBoundary[1])


if __name__ == '__main__':
    test = Netsim(check_map=True, override=True)
    # print(test.edgesTravelPassMap)
