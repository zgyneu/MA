# -*- coding: utf-8 -*-
"""
@Time ： 2020/6/16 23:03
@Auth ： Xiangyu Kong
@File ： gaode2sumo02.py
@IDE  ： PyCharm
@Info :  对可行交叉路口增加红绿灯

"""

import json
import os
import re
import subprocess
import sys
import time

import sumolib


class Poi:
    """Poi对象具有:地址、坐标属性；多个Poi对应一个park（区分商家/客户）"""

    def __init__(self, addr, coords, isShop, boundary):
        self._addr = addr
        self._coords = coords
        self._order = None
        self._x = coords[0]
        self._y = coords[1]
        self._isShop = isShop
        self._linkParkArea = None
        self._linkPoly = None
        self._inBoundary = False
        if self._x < boundary[0] or self._x < boundary[1] or self._y > boundary[2] or self._y > boundary[3]:
            self._inBoundary = False
        else:
            self._inBoundary = True

    def setOrder(self, order):
        """设定POI所属Order"""
        self._order = order

    def getOrder(self):
        """返回POI所属Order"""
        return self._order

    def setLinkPoly(self, poly):
        """设定POI到park之间的poly"""
        self._linkPoly = poly

    def getLinkPoly(self):
        """返回POI到park之间的poly"""
        return self._linkPoly

    def isShop(self):
        """POI是商家地址？并返回BOOL值"""
        return self._isShop

    def inBoundary(self):  # [xmin,ymin,xmax,ymax]
        """检测POI是否在边界内，并返回BOOL值"""
        return self._inBoundary

    def getAddr(self):
        """返回地址"""
        return re.sub(u'([^\u4e00-\u9fa5\u0030-\u0039\u0041-\u005a\u0061-\u007a])', "", self._addr)

    def getCoords(self):
        """返回坐标"""
        return self._coords

    def getX(self):
        """返回x坐标"""
        return self._x

    def getY(self):
        """ 返回y坐标 """
        return self._y


class ParkArea:
    """ParkArea对象具有:车道对象、偏移量属性；与poi是一对多关系"""

    def __init__(self, lane, offset, poi):
        if lane:
            self._lane = lane
            self._offset = offset
            self._startPos = 0
            self._endPos = 0
            self._parkGather = self.getEdgeId()  # 在同一条edge上的park聚集为一个park,以当前edge命名
            # self._parkGatherPos=[-12,-1]
            if self._lane.getLength() < 11:
                self._startPos = 0
                self._endPos = self._lane.getLength()
            elif self._offset - 5 < 0:
                self._startPos = 1
                self._endPos = self._startPos + 11
            elif self._offset + 5 > self._lane.getLength():
                self._endPos = -1  # self._lane.getLength()*0.9
                self._startPos = self._endPos - 11  # self._endPos-11
            else:
                self._startPos = self._offset - 5.5
                self._endPos = self._offset + 5.5
            self._pois = []
            self._orders = []
            self.add(poi)
            self._isShop = poi.isShop()
            if self.isShop():
                self._id = "shop_" + poi.getOrder().getId()
            else:
                self._id = "client_" + poi.getOrder().getId()

    def getId(self):
        """返回ParkArea对象 ID"""
        return self._id

    def isShop(self):
        """ParkArea对象包含的都是商家地址？并返回BOOL值"""
        return self._isShop

    def getPois(self):
        """返回ParkArea对象对应的所有POI"""
        return self._pois

    def add(self, poi):
        """将poi加入到该停车场"""
        if self._pois:
            self._id += "_" + poi.getOrder().getId()
        self._pois.append(poi)
        self._orders.append(poi.getOrder())

    def getCoords(self):
        """返回坐标"""
        return sumolib.geomhelper.positionAtShapeOffset(self._lane.getShape(), self._offset)

    def getLane(self):
        """返回车道对象"""
        return self._lane

    def getLaneId(self):
        """返回车道ID"""
        return self._lane.getID()

    def getEdge(self):
        """返回所在edge对象"""
        return self._lane.getEdge()

    def getEdgeId(self):
        """返回所在edge对象的ID"""
        return self._lane.getEdge().getID()

    def getParkGather(self):
        """在同一条edge上的park聚集为一个park,以当前edge命名"""
        return self._parkGather

    def getOffset(self):
        """ 返回偏移量 """
        return self._offset

    def getOffsetPercent(self):
        """"""
        return self._offset / self._lane.getLength()

    def getStartPos(self):
        """ 返回ParkArea起始Pos """
        return self._startPos

    def getEndPos(self):
        """ 返回ParkArea结束Pos """
        return self._endPos

    def getCenterPos(self):
        """ 返回ParkArea中间Pos """
        if (self._startPos + self._endPos) / 2 > 0:
            return (self._startPos + self._endPos) / 2
        else:
            return (self._startPos + self._endPos) / 2 + self._lane.getLength()

    def getCenterCoords(self):
        """ 返回ParkArea中间坐标（只用于PolyLine标记） """
        return sumolib.geomhelper.positionAtShapeOffset(self._lane.getShape(), self.getCenterPos())


class ParkCenter:
    """ParkCenter对象包括:id、startPos、endPos"""

    def __init__(self, id, park, startPos=1, endPos=12):
        self._id = id
        self._park = park
        self._lane = self.getLane()
        # self._centerPos = self._lane.getLength()/2
        # self._startPos = max(2,self._centerPos-6)
        # self._endPos = min(self._lane.getLength(),self._centerPos+6)
        self._startPos = startPos
        self._endPos = endPos
        self._offset = startPos
        self.startCoords = self.getCoords()

    def getId(self):
        return self._id

    def getStartPos(self):
        return self._startPos

    def getEndPos(self):
        return self._endPos

    def getLane(self):
        return self._park.getLane()

    def getLaneId(self):
        return self._park.getLaneId()

    def getCenterPos(self):
        return self._park.getCenterPos()

    def getCoords(self):
        """返回坐标"""
        return sumolib.geomhelper.positionAtShapeOffset(self._lane.getShape(), self._offset)


class Order:
    """Order对象包含:id、createTime、Poi_start、Poi_start对象"""

    def __init__(self, id, createTime, start, end):
        self._id = id
        self._createTime = eval(createTime)
        self._start = start
        self._end = end
        self._isDiscarded = False  # 该订单内是否有POI超界
        self._shopPark = None
        self._shopParkLane = None
        self._clientPark = None
        self._clientParkLane = None
        self._createTimeOffset = self._createTime
        self._inBoundary = False
        if self._start.inBoundary() and self._end.inBoundary():
            self._inBoundary = True
        else:
            self._inBoundary = False

    def isDiscarded(self):
        """返回该Order是否被弃用"""
        return self._isDiscarded

    def inBoundary(self):
        """返回该Order是否在边界内"""
        return self._inBoundary

    def getId(self):
        """返回Order ID"""
        return self._id

    def getCreateTime(self):
        """返回Order CreateTime"""
        return self._createTime

    def setCreateTimeOffset(self, earliestTime):
        """设定Order的订单创建时间偏移量，单位秒"""
        self._createTimeOffset = self._createTime - earliestTime

    def getCreateTimeOffset(self):
        """返回Order的订单创建时间偏移量，单位秒"""
        return self._createTimeOffset

    def getStart(self):
        """返回Poi_start对象"""
        return self._start

    def getEnd(self):
        """返回Poi_end对象"""
        return self._end

    def getStartAddr(self):
        """返回Poi_start对象的地址"""
        return self._start.getAddr()

    def getStartCoords(self):
        """返回Poi_start对象的坐标"""
        return self._start.getCoords()

    def getEndAddr(self):
        """返回Poi_end对象的地址"""
        return self._end.getAddr()

    def getEndCoords(self):
        """返回Poi_end对象的坐标"""
        return self._end.getCoords()

    def setShopPark(self, park):
        """设定商户parkArea及所在的Lane"""
        self._shopPark = park
        self._shopParkLane = park.getLane()

    def setClientPark(self, park):
        """设定客户parkArea及所在的Lane"""
        self._clientPark = park
        self._clientParkLane = park.getLane()

    def getShopPark(self):
        """返回商户parkArea"""
        return self._shopPark

    def getClientPark(self):
        """返回客户parkArea"""
        return self._clientPark

    def getShopParkId(self):
        """返回商户parkArea ID"""
        return self._shopPark.getId()

    def getClientParkId(self):
        """返回客户parkArea ID"""
        return self._clientPark.getId()

    def getShopParkLane(self):
        """返回商户parkArea所在Lane"""
        return self._shopParkLane

    def getClientParkLane(self):
        """返回客户parkArea所在Lane"""
        return self._clientParkLane

    def getShopParkEdge(self):
        """返回商户parkArea所在Edge"""
        return self._shopParkLane.getEdge()

    def getClientParkEdge(self):
        """返回客户parkArea所在Edge"""
        return self._clientParkLane.getEdge()

    def getDepartPos(self):
        """返回商户parkArea所在Lane的Offset"""
        return self._shopPark.getCenterPos()

    def getArrivalPos(self):
        """返回客户parkArea所在Lane的Offset"""
        return self._clientPark.getCenterPos()


class Addin:
    """Addin对象包含:Poi对象、PolyLine对象、ParkArea对象"""

    def __init__(self, poi, polyline=None, parkarea=None):
        self._poi = poi
        self._polyline = polyline
        self._parkarea = parkarea
        self._inrange = True if parkarea else False
        self._color = ("green", "blue") if self._inrange else ("magenta", None)

    def getAddr(self):
        """返回Poi地址"""
        return self._poi.getAddr()

    def getParkAreaStartPos(self):
        """返回ParkAreaStartPos"""
        return self._parkarea.getStartPos()

    def getParkAreaEndPos(self):
        """返回ParkAreaEndPos"""
        return self._parkarea.getEndPos()

    def getPoiColor(self):
        """返回Poi对象颜色"""
        return self._color[0]

    def getPolyLineColor(self):
        """返回PolyLine对象颜色"""
        return self._color[1]

    def getPoiCoords(self):
        """返回Poi对象坐标"""
        return self._poi.getCoords()

    def getPoiX(self):
        """返回Poi对象x坐标"""
        return self._poi.getX()

    def getPoiY(self):
        """返回Poi对象y坐标"""
        return self._poi.getY()

    def getParkAreaCoords(self):
        """返回ParkArea对象坐标"""
        return self._parkarea.getCoords()

    def getParkAreaLaneID(self):
        """返回ParkArea对象所在车道ID"""
        return self._parkarea.getLaneID()

    def getPolyLineShape(self):
        """返回PolyLine的shape坐标数组"""
        return self._polyline.getShape()

    def getPolyLineShapeStr(self):
        """返回PolyLine的shape坐标字符串"""
        shape = self.getPolyLineShape()
        li = []
        for node in shape:
            li.append(node.__str__().strip('()').replace(' ', ''))
        return ' '.join(li)


class PolyLine:
    """PolyLine对象包含:Poi位置坐标、ParkArea位置坐标;对应到1个poi上"""

    def __init__(self, poicoords, parkareacoords):
        if parkareacoords:
            self._poicoords = poicoords
            self._parkareacoords = parkareacoords

    def poiCoords(self):
        """返回Poi位置坐标"""
        return self._poicoords

    def parkAreaCoords(self):
        """返回ParkArea位置坐标"""
        return self._parkareacoords

    def getShape(self):
        """返回PolyLine的shape坐标数组"""
        return [self._poicoords, self._parkareacoords]

    def getPolyLineShapeStr(self):
        """返回PolyLine的shape坐标字符串"""
        shape = self.getShape()
        li = []
        for node in shape:
            li.append(node.__str__().strip('()').replace(' ', ''))
        return ' '.join(li)


class Grids:
    """将net划分为网格，方便就近搜索，Grids的grids[][]包含所有的park"""

    def __init__(self, boundary, delta):  # boundary:[xmin,ymin,xmax,ymax]
        self._delta = delta
        self._boundary = boundary
        self._gridX = int((boundary[2] - boundary[0]) // gridDelta + 1)
        self._gridY = int((boundary[3] - boundary[1]) // gridDelta + 1)
        self._grids = []
        for y in range(self._gridY):
            self._grids.append([])
            for x in range(self._gridX):
                self._grids[y].append([])

    def add(self, park):
        """将停车场根据坐标放入网格"""
        x = int((park.getCoords()[0] - self._boundary[0]) // self._delta)
        y = int((park.getCoords()[1] - self._boundary[1]) // self._delta)
        self._grids[y][x].append(park)

    def getClosestPark(self, poi, radius):
        """给定Poi对象，得到周边最近的park，要做到商家/客户分离"""
        closestParks = []
        x = int((poi.getX() - self._boundary[0]) // self._delta)
        y = int((poi.getY() - self._boundary[1]) // self._delta)
        xmin = x - 1 if x > 0 else x
        ymin = y - 1 if y > 0 else y
        xmax = x + 1 if x < self._gridX - 1 else x
        ymax = y + 1 if y < self._gridY - 1 else y
        for i in range(ymin, ymax + 1):
            for j in range(xmin, xmax + 1):
                closestParks += self._grids[y][x]
        minDist = float("inf")
        minPark = None
        for park in closestParks:
            if poi.isShop() != park.isShop():
                continue
            else:
                dist = sumolib.geomhelper.distance(park.getCoords(), poi.getCoords())
                if dist < minDist:
                    minPark = park
                    minDist = dist
        if minDist <= radius:
            return minPark
        else:
            return None


if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("please declare environment variable 'SUMO_HOME'")

netPath = "../osm/osm.net.xml"
jsonDirPath = "../gaodedata/"
parkingFilePath = "../osm/ParkingArea.add.xml"
parkingWithPoiAndPolyFilePath = "../osm/ParkingWithPoiAndPoly.add.xml"
netWithTlsPath = "../osm/osmWithTls.net.xml"
rouPath = "../osm/osm.rou.xml"
netccftPath = "../osm/osm.netccfg"
density = 1  # 默认为1，当设置值大于1时，加入的Order的起送时间间隔会缩短为相应倍数
deltaTimeLimit = False  # 是否过滤指定时间区间的Order
timeStart = '2016-05-01 00:00:00'
timeEnd = '2016-05-20 23:59:59'
time0 = time.time()

# See at https://sumo.dlr.de/docs/Definition_of_Vehicles,_Vehicle_Types,_and_Routes.html#abstract_vehicle_class
# "pedestrian"  for vTypes[5]
# "delivery"    for vTypes[11]
# "motorcycle"  for vTypes[14]
# "moped"       for vTypes[15]
# "bicycle"     for vTypes[16]
vTypes = ["private", "emergency", "authority", "army", "vip", "pedestrian", "passenger", "hov", "taxi", "bus", "coach",
          "delivery", "truck", "trailer", "motorcycle", "moped", "bicycle", "evehicle", "tram", "rail_urban", "rail",
          "rail_electric", "rail_fast", "ship", "custom1", "custom2"]
parkLaneVTypeIndexes = [14, 15]  # 允许放置parkArea的车辆类型 indexes
noTlsEgeVTypeIndexes = [5, 11, 14, 15, 16]  # 不允许放置TLS的车辆类型 indexes
tlsEgeVTypeIndexes = [i for i in range(len(vTypes)) if i not in noTlsEgeVTypeIndexes]  # 允许放置TLS的车辆类型 indexes

# ----------------------------------------- 1.0、获取所有可行车道 -----------------------------------------------#
net = sumolib.net.readNet(netPath)  # 解析.net.xml
boundary = net.getBoundary()  # [xmin,ymin,xmax,ymax]
gridDelta = 200  # 将net划分为网格，方便就近搜索，网格单元边长
grids = Grids(boundary, gridDelta)
edges = net.getEdges(withInternal=False)
lanes = []  # 车道对象 列表,注意，只取每条边的第0(最外层)车道
allowLanes = []  # 同时允许motorcycle和moped车辆通行的车道
allowEdges = []  # 同时允许motorcycle和moped车辆通行的edge
disallowLanes = []  # 不能同时允许motorcycle和moped车辆通行的车道
tlsEges = []  # 需要放置TLS的ege 列表，例如包含火车道或客车道相连的ege
noTlsEges = []  # 不需要放置TLS的ege 列表，例如包含人行道或电动车道相连的ege，但注意，但凡车道允许列表中包含大型车辆，则必须放置TLS
for e in edges:
    l = e.getLane(0)
    lanes.append(l)
    if False not in [l.allows(vTypes[i]) for i in parkLaneVTypeIndexes]:
        allowLanes.append(l)
        allowEdges.append(l.getEdge().getID())
    else:
        disallowLanes.append(l)
    if True in [e.allows(vTypes[i]) for i in tlsEgeVTypeIndexes]:
        tlsEges.append(e)
    else:
        noTlsEges.append(e)

edgesMap = dict(list(enumerate(allowEdges)))  # 所有可行edges生成的dict
edgesMap = dict(zip(edgesMap.values(), edgesMap.keys()))  # key:edge的ID，value:0~n
# print(edgesMap)
# print(len(allowLanes))    # for test
# print(len(lanes))         # for test
# print(len(tlsEges))       # for test
# print(len(noTlsEges))     # for test
# print()


# ----------------------------------------- 1.1、获取所有需要生成TLS的junction -----------------------------------------------#
time1_0 = int(time.time())
print("Processing : 正在处理TLS数据")
tlsExists = [tls.getID() for tls in net.getTrafficLights()]  # 已生成的红绿灯对象

nodes = net.getNodes()
tlsNode = []
for n in nodes:
    connectedEges = n.getIncoming() + n.getOutgoing()
    # 核心判断：1.该路口不在已生成红绿灯对象列表；2.路口连接edge数大于4；2.路口连接的edge有任意一条可行车⬇
    if n.getID() not in tlsExists and len(connectedEges) > 4 and [True for e in connectedEges if e in tlsEges]:
        tlsNode.append(n.getID())
print("Processing : TLS数据处理完成 , 使用 %d (s)" % int(time.time() - time1_0))
# -------------------  2、解析.json，获取所有Poi并转换为平面坐标x,y   ---------------------#
time2_0 = int(time.time())
if deltaTimeLimit:
    timeStartStamp = time.mktime(time.strptime(timeStart, "%Y-%m-%d %H:%M:%S"))
    timeEndStamp = time.mktime(time.strptime(timeEnd, "%Y-%m-%d %H:%M:%S"))
else:
    timeStartStamp = 0
    timeEndStamp = float("inf")
print("Processing : 正在读取json文件")
jsonDir = os.scandir(jsonDirPath)
jsonFiles = []
jsonData = []
for f in jsonDir:
    jsonFiles.append(f.name)
jsonDir.close()
jsonFiles = sorted(jsonFiles, key=lambda item: int(item.partition("_")[2].partition(".")[0]))
# jsonFiles = ["save_0.json"]  # for quick test
for file in jsonFiles:
    with open(jsonDirPath + file, 'r', encoding='UTF-8') as f:
        jsonData += json.load(f)
        f.close()

pois = []  # 包含所有POI对象
orders = []  # 包含所有Order对象

for i in range(len(jsonData)):  ############调试时，这里整除以100
    if float(jsonData[i][1]["createTime"]) >= timeStartStamp and float(jsonData[i][1]["createTime"]) <= timeEndStamp:
        pois.append(
            Poi(jsonData[i][2]["addrSrc"], (net.convertLonLat2XY(jsonData[i][2]["lng"], jsonData[i][2]["lat"])), True,
                boundary))
        pois.append(
            Poi(jsonData[i][3]["addrDst"], (net.convertLonLat2XY(jsonData[i][3]["lng"], jsonData[i][3]["lat"])), False,
                boundary))
        poisLen = len(pois)
        order = Order(jsonData[i][0]["id"], jsonData[i][1]["createTime"], pois[poisLen - 2], pois[poisLen - 1])
        pois[poisLen - 2].setOrder(order)
        pois[poisLen - 1].setOrder(order)
        orders.append(order)
print("Processing : 读取json文件数据完成 , 使用 %d (s)" % int(time.time() - time2_0))

# -------------------  3、遍历所有Order，获取距离Poi最近的可行车道，及距离最近处的offset和position ---------------------#
time3_0 = int(time.time())
print("Processing : 正在处理订单数据")
ordersValid = []  # 包含所有这样的order对象：1.始末POI均inboundary 2.始末POI均在最大radius内能找到可绑定的lane
ordersInvalid = []  # 包含以上之外的order对象
parks = []
parksGatherMap = {}
parksCenters = []
polyLines = []
radius = [50, 250, 500]  # 离最近道路超出0.5km即剔除该POI及其ORDER
for order in orders:  # 遍历所有order
    if order.inBoundary():  # 1.order在boundary内
        bothFindLane = True  # 该order的两个Poi是否都能在最大radius内找到可绑定的lane
        orderPois = [order.getStart(), order.getEnd()]
        closestLanes = []
        for poi in orderPois:
            findLane = False  # 该Poi是否能在最大radius内找到可绑定的lane
            neighborlanes = []
            for r in radius:
                neighborlanes = net.getNeighboringLanes(poi.getX(), poi.getY(), r, includeJunctions=False)
                if neighborlanes:
                    allAllowed = False
                    removeList = []
                    for neigh in neighborlanes:
                        if neigh[0] in allowLanes:
                            allAllowed = True
                        else:
                            removeList.append(neigh)
                    if allAllowed:
                        findLane = True  # 该Poi至少可绑定一条lane
                        for neigh in removeList:
                            neighborlanes.remove(neigh)
                        break
                else:
                    continue
            if not findLane:
                bothFindLane = False
                break
            else:
                closestLane = None
                minDist = float("inf")
                for lane, dist in neighborlanes:
                    if dist < minDist:
                        closestLane = lane
                        minDist = dist
                closestLanes.append(closestLane)
        if bothFindLane:
            for i in range(2):
                park = grids.getClosestPark(orderPois[i], 200)  # 在poi的200米范围内找parkarea
                if not park:  # 如果不能找到就近park，则创建新的park
                    closestShape = closestLanes[i].getShape()  # 最近车道的车道线条(坐标数组)
                    closestOffset = sumolib.geomhelper.polygonOffsetWithMinimumDistanceToPoint(orderPois[i].getCoords(),
                                                                                               closestShape)  # 最近车道最近距离点的offset
                    park = ParkArea(closestLanes[i], closestOffset, orderPois[i])
                    grids.add(park)  # 将park加入到grids
                    parks.append(park)
                else:
                    park.add(orderPois[i])
                if parksGatherMap.get(park.getEdgeId()) is None:
                    parkCenter = ParkCenter(park.getParkGather(), park)
                    parksGatherMap[park.getEdgeId()] = parkCenter
                    parksCenters.append(parkCenter)
                polyLine = PolyLine(orderPois[i].getCoords(), park.getCenterCoords())
                orderPois[i].setLinkPoly(polyLine)
                polyLines.append(polyLine)
                if i == 0:
                    order.setShopPark(park)
                else:
                    order.setClientPark(park)
            ordersValid.append(order)
        else:
            ordersInvalid.append(order)
    else:
        ordersInvalid.append(order)

parksCentersMap = dict(list(enumerate(parksCenters)))  # 所有parksCenters生成的dict
parksCentersMap = dict(zip(parksCentersMap.values(), parksCentersMap.keys()))  # key:parksCenter的ID，value:0~n

parksMap = dict(list(enumerate(parks)))  # 所有可行parks生成的dict
parksMap = dict(zip(parksMap.values(), parksMap.keys()))  # key:park的ID，value:0~n
ordersValidSorted = sorted(ordersValid, key=lambda item: item.getCreateTimeOffset())  # 对所有订单，以创建时间先后排序

with open("../mapdata/EdgesMap.json", "w",
          encoding='UTF-8') as jsonFile:  # EdgesMap输出,键：edge的ID，值：0~len(edges)，作为训练使用的随机数据
    print("[", file=jsonFile)
    n = len(edgesMap)
    for id in edgesMap:
        edgesMapJson = {"id": id, "idx": edgesMap[id], "laneLength": net.getEdge(id).getLane(0).getLength(),
                        "centerPos": sumolib.geomhelper.positionAtShapeOffset(net.getEdge(id).getLane(0).getShape(),
                                                                              net.getEdge(id).getLane(
                                                                                  0).getLength() * 0.5),
                        "beginPos": sumolib.geomhelper.positionAtShapeOffset(net.getEdge(id).getLane(0).getShape(), 0),
                        "endPos": sumolib.geomhelper.positionAtShapeOffset(net.getEdge(id).getLane(0).getShape(),
                                                                           net.getEdge(id).getLane(0).getLength())}
        if edgesMap[id] == n - 1:
            print(json.dumps(edgesMapJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(edgesMapJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

with open("../mapdata/ParksMap.json", "w",
          encoding='UTF-8') as jsonFile:  # ParksMap输出,键：park的ID，值：0~len(park)，作为训练使用的随机数据
    print("[", file=jsonFile)
    n = len(parksMap)
    for park in parksMap:
        parksMapJson = {"id": park.getId(), "idx": parksMap[park], "lane": park.getLaneId(), "off": park.getStartPos(),
                        "Pos2D": park.getCoords(), "off%": park.getOffsetPercent()}
        if parksMap[park] == n - 1:
            print(json.dumps(parksMapJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(parksMapJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

with open("../mapdata/Parks2EdgesMap.json", "w",
          encoding='UTF-8') as jsonFile:  # Parks2EdgesMap输出,键：park的ID，值：对应在edge的ID，作为训练使用的随机数据
    print("[", file=jsonFile)
    n = len(parksMap)
    for park in parksMap:
        parks2EdgesMapJson = {"pId": park.getId(), "pIdx": parksMap[park], "eId": park.getEdgeId(),"eIdx":edgesMap[park.getEdgeId()]}
        if parksMap[park] == n - 1:
            print(json.dumps(parks2EdgesMapJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(parks2EdgesMapJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

# with open("./osm/ParksMap.json", "w", encoding='UTF-8') as jsonFile:  # ParksMap输出,键：park的ID，值：0~len(parks)，作为训练使用的随机数据
#     print("[", file=jsonFile)
#     n = len(parksMap)
#     for park in parksMap:
#         parksMapJson = {"id": park.getId(), "idx": parksMap[park], "lane": park.getLaneId(), "off": park.getStartPos()}
#         if parksMap[park] == n - 1:
#             print(json.dumps(parksMapJson, ensure_ascii=False), file=jsonFile)
#         else:
#             print(json.dumps(parksMapJson, ensure_ascii=False) + ",", file=jsonFile)
#     print("]", file=jsonFile)
#     sys.stdout.flush()
#     jsonFile.close()
#
# with open("./osm/Parks2EdgesMap.json", "w",
#           encoding='UTF-8') as jsonFile:  # Parks2EdgesMap输出,键：park的ID，值：对应在edge的ID，作为训练使用的随机数据
#     print("[", file=jsonFile)
#     n = len(parksMap)
#     for park in parksMap:
#         parks2EdgesMapJson = {"pId": park.getId(), "eId": park.getEdgeId()}
#         if parksMap[park] == n - 1:
#             print(json.dumps(parks2EdgesMapJson, ensure_ascii=False), file=jsonFile)
#         else:
#             print(json.dumps(parks2EdgesMapJson, ensure_ascii=False) + ",", file=jsonFile)
#     print("]", file=jsonFile)
#     sys.stdout.flush()
#     jsonFile.close()

with open("../mapdata/OrderData.json", "w",
          encoding='UTF-8') as jsonFile:  # 有效订单按序输出，作为训练使用的随机数据，shop和client均使用index值(0~len(***))
    print("[", file=jsonFile)
    for orderVld in ordersValidSorted:
        orderJson = {"id": orderVld.getId(), "sIdx": parksMap[orderVld.getShopPark()],
                     "cIdx": parksMap[orderVld.getClientPark()]}
        if orderVld == ordersValidSorted[-1]:
            print(json.dumps(orderJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(orderJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

with open("../mapdata/statis/ValidOrders.json", "w", encoding='UTF-8') as jsonFile:  # 有效订单导出统计
    print("[", file=jsonFile)
    for orderVld in ordersValid:
        orderJson = {"id": orderVld.getId(), "shop": orderVld.getStartAddr(), "client": orderVld.getEndAddr()}
        if orderVld == ordersValid[-1]:
            print(json.dumps(orderJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(orderJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

with open("../mapdata/statis/InvalidOrders.json", "w", encoding='UTF-8') as jsonFile:  # 无效订单导出统计
    print("[", file=jsonFile)
    for orderIvd in ordersInvalid:
        orderJson = {"id": orderIvd.getId(), "shop": orderIvd.getStartAddr(), "client": orderIvd.getEndAddr()}
        if orderIvd == ordersInvalid[-1]:
            print(json.dumps(orderJson, ensure_ascii=False), file=jsonFile)
        else:
            print(json.dumps(orderJson, ensure_ascii=False) + ",", file=jsonFile)
    print("]", file=jsonFile)
    sys.stdout.flush()
    jsonFile.close()

print("Processing : %5d/%5d/%5d （有效订单/失效订单/总订单数）" % (len(ordersValid), len(ordersInvalid), len(orders)))
earliestTime = float("inf")  # 第一个订单开始时间
latestTime = -1  # 最后一个订单开始时间
for order in ordersValid:
    if order.getCreateTime() < earliestTime:
        earliestTime = order.getCreateTime()
    if order.getCreateTime() > latestTime:
        latestTime = order.getCreateTime()

for order in ordersValid:
    order.setCreateTimeOffset(earliestTime)  # 所有订单以0秒为起点，单位秒

duration = latestTime - earliestTime + 1  # 持续时间，单位秒
print("Duration :  %5d (s)" % (duration))
print("Processing : 订单数据处理完成, 使用 %d (s)" % int(time.time() - time3_0))
# print(len(ordersValidSorted))
# for order in ordersValidSorted:
#     print(order.getCreateTimeOffset())

# print(len(ordersValid))
# print(len(ordersInvalid))
# print(len(orders))

# -------------------  4、将所有parkingArea、PolyLine、Poi数据写入.add.xml文件 ---------------------#
with open(parkingFilePath, "w", encoding='UTF-8') as parkFile:  # 单独把ParkingArea信息写入 ParkingFilePath 的.add.xml文件
    print(
        '<additional xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/additional_file.xsd">',
        file=parkFile)
    n = len(parksCenters)
    for i in range(n):
        print(
            '\t<parkingArea id="%s" lane="%s" startPos="%.2f" endPos="%.2f" roadsideCapacity="10" friendlyPos="1" />' % (
                parksCenters[i].getId(), parksCenters[i].getLaneId(), parksCenters[i].getStartPos(),
                parksCenters[i].getEndPos()), file=parkFile)
        # parkPois = parksCenters[i].getPois()
    print("</additional>", file=parkFile)
    sys.stdout.flush()
    parkFile.close()

with open(parkingWithPoiAndPolyFilePath, "w",
          encoding='UTF-8') as addFile:  # 把ParkingArea以及POI和Polyline信息写入 ParkingWithPoiAndPolyFilePath 的.add.xml文件
    print(
        '<additional xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/additional_file.xsd">',
        file=addFile)
    n = len(parks)
    for i in range(n):
        print(
            '\t<parkingArea id="%s" lane="%s" startPos="%.2f" endPos="%.2f" roadsideCapacity="10" friendlyPos="1" />' % (
                parks[i].getId(), parks[i].getLaneId(), parks[i].getStartPos(),
                parks[i].getEndPos()), file=addFile)
        parkPois = parks[i].getPois()
        for j in range(len(parkPois)):
            print('\t<poly id="%s_%s_poly_%s" color="%s" fill="0" layer="128.00" shape="%s" />' % (
                ("shop" if parks[i].isShop() else "client"), parkPois[j].getAddr(), parkPois[j].getOrder().getId(),
                "blue",
                parkPois[j].getLinkPoly().getPolyLineShapeStr()),
                  file=addFile)
            print('\t<poi id="%s_%s_poi_%s" color="%s" layer="202.00" x="%.2f" y="%.2f" />' % (
                ("shop" if parks[i].isShop() else "client"), parkPois[j].getAddr(), parkPois[j].getOrder().getId(),
                "green", parkPois[j].getX(),
                parkPois[j].getY()),
                  file=addFile)
    print("</additional>", file=addFile)
    sys.stdout.flush()
    addFile.close()

# -------------------  5、生成路由文件 osm.rou.xml ---------------------#
# def generate_routefile():
# N = duration  # number of time steps
with open(rouPath, "w", encoding='UTF-8') as routes:
    print(
        '<?xml version="1.0" encoding="UTF-8"?>',
        file=routes)
    print(
        '<routes xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/routes_file.xsd">',
        file=routes)
    print(
        '<vType id="moto_motorcycle" vClass="motorcycle"/>',
        file=routes)
    for order in ordersValidSorted:
        print(
            '    <trip id="%s" type="moto_motorcycle" color="%s" depart="%i" from="%s" departLane="%s" departPos="%f" to="%s" arrivalLane="%s" arrivalPos="%f" />' % (
                order.getId(), "blue", order.getCreateTimeOffset() / density, order.getShopParkEdge().getID(), "first",
                order.getDepartPos(), order.getClientParkEdge().getID(), 0, order.getArrivalPos()
            ), file=routes)
    print("</routes>", file=routes)
    sys.stdout.flush()
    routes.close()

# -------------------  6、调用netconvert生成带有TLS的.net.xml ---------------------#
# subprocess.call(
#     ["netconvert", "-s", netPath, "-o", netWithTlsPath, "--ignore-errors.edge-type", "--tls.default-type",
#      "actuated",
#      "--tls.set", ','.join(tlsNode)],shell=True)
with open(netccftPath, "w", encoding='UTF-8') as netc:
    print(
        '<?xml version="1.0" encoding="UTF-8"?>',
        file=netc)
    print(
        '<configuration xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="http://sumo.dlr.de/xsd/routes_file.xsd">',
        file=netc)
    print(
        """\t<input>\n\t\t<type-files value="C:\Program%20Files%20(x86)\Eclipse\Sumo\data\\typemap\osmNetconvert.typ.xml"/>\n\t\t<sumo-net-file value="osm.net.xml"/>\n\t</input>""",
        file=netc)
    print(
        """\t<output>\n\t\t<output-file value="osmWithTls.net.xml"/>\n\t</output>""",
        # \n\t\t<output.street-names value="true"/>\n\t\t<output.original-names value="true"/>
        file=netc)
    print(
        """\t<processing>\n\t\t<roundabouts.guess value="true"/>\n\t</processing>""",
        # <geometry.remove value="true"/>\n\t\t
        file=netc)
    # print(
    #     """\t<building_defaults>\n\t\t<default.lanenumber value="2"/>\n\t</building_defaults>""",
    #     file=netc)
    print(
        """\t<tls_building>\n\t\t<tls.discard-simple value="true"/>\n\t\t<tls.join value="true"/>\n\t\t<tls.guess-signals value="true"/>\n\t\t<tls.default-type value="actuated"/>\n\t\t<tls.set value="%s"/>\n\t</tls_building>""" % (
            ','.join(tlsNode)),
        file=netc)
    # print(
    #     """\t<ramp_guessing>\n\t\t<ramps.guess value="true"/>\n\t</ramp_guessing>""",
    #     file=netc)
    print(
        """\t<junctions>\n\t\t<junctions.corner-detail value="5"/>\n\t\t<no-internal-links value="true"/>\n\t</junctions>""",
        # <junctions.join value="true"/>\n\t\t
        file=netc)
    print(
        """\t<report>\n\t\t<verbose value="true"/>\n\t</report>""",
        file=netc)
    print("</configuration>", file=netc)
    sys.stdout.flush()
    netc.close()
subprocess.call(
    ["netconvert", "-c", netccftPath])

print("Processing : 处理完成, 共使用 %d (s)" % int(time.time() - time0))
