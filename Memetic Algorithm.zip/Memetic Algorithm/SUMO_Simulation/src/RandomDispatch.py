from random import seed
from random import randint
from Dispatcher_Periodic import Dispatcher
import time

dispatcher = Dispatcher()

def main(sd):
    print("seed:",sd)
    seed(sd)
    s = dispatcher.reset()
    done = False
    while True:
        time.sleep(0.1)
        # dispatcher.display()
        if s:
            s, done, _ = dispatcher.step(randint(0, dispatcher.COURIERS_CENTER.courierNum - 1))
        else:
            s, done, _ = dispatcher.step()
        # print("order:", dispatcher.ORDERS_CENTER.get_dispatched_orders_num())
        # print()
        if dispatcher.ORDERS_CENTER.orders is []:
            print("done")
        if done:
            dispatcher.reset()
            break
    print("done")


if __name__ == '__main__':
    sd = 17
    while True:
        main(sd)
        sd += 1
