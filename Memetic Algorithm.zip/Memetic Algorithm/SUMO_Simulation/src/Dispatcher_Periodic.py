import copy
import gc
import random
import time
import os
from multiprocessing import Pool

from Netsim import Netsim
from Ordersim import OrdersCenter, Order, OrderStatusEnum
from Couriersim import CouriersCenter
from VRP_Algs.Memetic_Algorithm_vrp import MA
from VRP_Algs.Simulated_Annealing_vrp import SA
from VRP_Algs.Tabu_Search_vrp import TS


def gen_dir() -> str:
    from time import strftime
    # img_dir_name = time.strftime("%Y_%m_%d_%H_%M")

    img_dir_name = strftime("%Y_%m_%d_%H_%M")
    os.mkdir("../../Img/" + img_dir_name)
    os.mkdir("../../Img/" + img_dir_name + "/process")
    os.mkdir("../../Img/" + img_dir_name + "/parameters")
    return "../../Img/" + img_dir_name


class Dispatcher:
    """
    Dispatcher类，周期时间步进，主要功能有：
    ①初始化调度平台，调用Netsim类、Ordersim类、Couriersim类并初始化
    ②开放调度算法接口
    构造函数：
    Dispatcher()
    接口函数：
    1 ：reset()                      重置所有骑手、订单的非固定参数

    接口变量：
    Dispatcher.TSP                      TSP
    Dispatcher.NET                      路网对象
    Dispatcher.ORDERS_CENTER             订单中心对象
    Dispatcher.COURIERS_CENTER           骑手中心对象

    """

    def __init__(self, seed, solver_name: str, process_dir, parameter_dir, allow_orders_to_be_reassigned):
        """
        构造函数
        """

        """以下为初始化参数"""
        # self.begin_time_str = "2016-5-18 9:00:01"  # 订单开始时间
        self.begin_time_str = "2016-5-18 11:50:01"  # 订单开始时间
        self.end_time_str = "2016-5-18 12:20:59"  # 订单结束时间
        self.seed = seed
        self.process_dir = process_dir
        self.parameter_dir = parameter_dir
        _init_courier_num = 20  # 骑手个数
        parking_time_const = 0  # 骑手等待顾客取餐的时间
        orders_time_limit = 30 * 60  # 所有订单的允许时限
        """以上为初始化参数"""
        self.Solver_Name = solver_name
        match self.Solver_Name:
            case "NMA":
                self.Solver = MA(seed=seed, population=500, iter_time=200, penalty_coefficient=100000, niche_num=6,
                                 terminate_by_fitness_equal=False, open_vrp=True, target=MA.TargetEnum.TIME, speed=1,
                                 allow_orders_to_be_reassigned=allow_orders_to_be_reassigned)
                self.Solver.change_parameters(need_correct_pickup_delivery=True, shift_cross_and_mutation_on=False,
                                              dynamic_probability=True,
                                              iter_time=200, niche_num=6, is_ga=False)
            case "MA":
                self.Solver = MA(seed=seed, population=500, iter_time=200, penalty_coefficient=100000, niche_num=1,
                                 terminate_by_fitness_equal=False, open_vrp=True, target=MA.TargetEnum.TIME, speed=1,
                                 allow_orders_to_be_reassigned=allow_orders_to_be_reassigned)
                self.Solver.change_parameters(need_correct_pickup_delivery=True, shift_cross_and_mutation_on=False,
                                              dynamic_probability=False,
                                              iter_time=200, niche_num=1, is_ga=False)
            case "GA":
                self.Solver = MA(seed=seed, population=500, iter_time=200, penalty_coefficient=100000, niche_num=1,
                                 terminate_by_fitness_equal=False, open_vrp=True, target=MA.TargetEnum.TIME, speed=1,
                                 allow_orders_to_be_reassigned=allow_orders_to_be_reassigned)
                self.Solver.change_parameters(need_correct_pickup_delivery=True, shift_cross_and_mutation_on=False,
                                              dynamic_probability=False,
                                              iter_time=200, niche_num=1, is_ga=True)
            case "SA":
                self.Solver = SA(seed=seed, iter_time=200, penalty_coefficient=100000, terminate_by_fitness_equal=False,
                                 open_vrp=False, target=SA.TargetEnum.TIME, debug_info=False)
            case "TS":
                self.Solver = TS(seed=seed, iter_time=200, penalty_coefficient=100000, terminate_by_fitness_equal=False,
                                 open_vrp=True, target=TS.TargetEnum.TIME, debug_info=False)

        self.NET = Netsim(check_map=False, override=False)

        self.ORDERS_CENTER = OrdersCenter(begin_str=self.begin_time_str, end_str=self.end_time_str,
                                          time_limit=orders_time_limit)
        self.COURIERS_CENTER = CouriersCenter(courier_num=_init_courier_num, package_limit=10,
                                              parking_time=parking_time_const)

        print("此时间段内订单数量为：", self.ORDERS_CENTER.orderNum)
        for _order in self.ORDERS_CENTER.orders:
            print(_order.createTimePoint)
        self._bind_orders_with_parks_offset()

        self._bind_couriers_with_edge()

        self._edgeTravelTimeMap = self.NET.edgeTravelTimeMap
        self._edgesTravelPassMap = self.NET.edgesTravelPassMap

        self.timeLine = 0  # 时间线
        self.time_interval_for_dispatch = 30  # 默认每60秒分配一次积攒的订单
        self.newOrders: list[Order] = []  # 新订单

    def reset(self):
        """
        重置所有骑手、订单的非固定参数
        :return:全局state
        """
        self.COURIERS_CENTER.reset()
        self.ORDERS_CENTER.reset()
        self.timeLine = 0
        self.newOrders = []
        # return self._collect_states(new_order=None)

    def _edge_travel_time_map_func(self, edge):
        """
        通过edge获取该edge所需时间
        :param edge: edge
        :return: float
        """
        edge = str(edge)
        return self._edgeTravelTimeMap[edge]

    def _edges_travel_pass_map_func(self, src, dst):
        """
        通过src和dst两条edge，获取途径的所有edge的列表
        :param src:起始edge
        :param dst:终点edge
        :return:list
        """
        src = str(src)
        dst = str(dst)
        return self._edgesTravelPassMap[src][dst]

    def _bind_orders_with_parks_offset(self):
        """
        初始化所有订单，并备份订单列表
        :return:void
        """
        for _order in self.ORDERS_CENTER.orders:
            _order.shopEdgeIdx = self.NET.parkToEdgeMap[_order.shopParkIdx]
            _order.shopParkOffsetPercent = self.NET.parksOffsetPercentMap[_order.shopParkIdx]
            _order.clientEdgeIdx = self.NET.parkToEdgeMap[_order.clientParkIdx]
            _order.clientParkOffsetPercent = self.NET.parksOffsetPercentMap[_order.clientParkIdx]
            _order.constWaitingClientTime = self.COURIERS_CENTER.parkingTimeConst
            self.ORDERS_CENTER.order_id_to_order_map[_order.id] = _order
        self.ORDERS_CENTER.set_const_orders_deepcopy(self.ORDERS_CENTER.orders)

    def _bind_couriers_with_edge(self):
        """
        初始化所有骑手
        :return:void
        """
        edges_idx = list(self.NET.revEdgesMap.keys())[:self.COURIERS_CENTER.courierNum]
        for i, courier in self.COURIERS_CENTER.couriers.items():
            courier.set_init_edge_and_off_percent(edge=edges_idx[i])

    @DeprecationWarning
    def dispatch_to_courier(self, courier_id, new_order):
        """
        将订单分配给特定骑手
        :param new_order:新订单
        :param courier_id:骑手id
        :return:void
        """
        _courier = self.COURIERS_CENTER.couriers[courier_id]
        self.ORDERS_CENTER.dispatchedOrders.append(new_order)
        new_order.action = courier_id
        _courier.ordersQueue.append(new_order)
        _solved, _path, _cost, _nodes, _graph = self.tsp_route(courier_id, only_return=True)
        if _solved:
            new_order.status = "Accepted"
            self.ORDERS_CENTER.acceptedOrders.append(new_order)
            if _courier.status == "WaitingOrder":
                _courier.status = None
            _courier.nodes = _nodes
            _courier.path = _path
            _courier.graph = _graph
            # print("debug_info:      courier_id:", courier_id, " Accepted")    # debug
        else:
            new_order.status = "Dismissed"
            self.ORDERS_CENTER.dismissedOrders.append(new_order)
            _courier.ordersQueue.remove(new_order)
            new_order.reward = -1
            # print("debug_info:      courier_id:", courier_id, " Dismissed")    # debug

    @DeprecationWarning
    def tsp_dispatch(self, new_order):
        """
        基于tsp分配
        :param new_order:
        :return:分配的骑手
        """
        _min_cost = float('inf')
        _min_cost_courier_id = None
        _min_cost_path = None
        _min_cost_nodes = None
        _min_cost_graph = None
        for _courier_id, _courier in self.COURIERS_CENTER.couriers.items():
            _courier.ordersQueue.append(new_order)
            _solved, _path, _cost, _nodes, _graph = self.tsp_route(_courier_id, only_return=True)
            if _solved:
                if _cost < _min_cost:
                    _min_cost = _cost
                    _min_cost_courier_id = _courier_id
                    _min_cost_path = _path
                    _min_cost_graph = _graph
                    _min_cost_nodes = _nodes
            _courier.ordersQueue.remove(new_order)
        if _min_cost_courier_id is not None:
            _courier = self.COURIERS_CENTER.couriers[_min_cost_courier_id]
            _courier.ordersQueue.append(new_order)
            _courier.nodes = _min_cost_nodes
            _courier.path = _min_cost_path
            _courier.graph = _min_cost_graph
            if _courier.status == "WaitingOrder":
                _courier.status = None
            new_order.status = "Accepted"
            self.ORDERS_CENTER.acceptedOrders.append(new_order)
        else:
            new_order.status = "Dismissed"
            self.ORDERS_CENTER.dismissedOrders.append(new_order)
            new_order.reward = -1
        new_order.action = _min_cost_courier_id
        print(_min_cost_courier_id)
        return _min_cost_courier_id

    @DeprecationWarning
    def nearest_dispatch(self, new_order):
        """
        基于订单商家离骑手最近分配，分配给最近骑手，如果不满足30分钟送达，则依次分配给次近骑手
        :param new_order:
        :return:分配的骑手
        """
        distance_map = {}  # key:骑手与商家的距离，value：骑手id
        distance_sorted_list = []
        soluble = False  # 是否有可行骑手
        _nearest_courier_id = None
        order_edge = new_order.shopEdgeIdx
        order_off = new_order.shopParkOffsetPercent
        for _courier_id, _courier in self.COURIERS_CENTER.couriers.items():
            distance_map[
                self.calc_time(_courier.currentEdge, order_edge, _courier.currentEdgePercent, order_off)[
                    0]] = _courier_id
            distance_sorted_list = sorted(distance_map.items(), key=lambda d: d[0])
        for _distance, _courier_id in distance_sorted_list:
            _courier = self.COURIERS_CENTER.couriers[_courier_id]
            _courier.ordersQueue.append(new_order)
            _solved, _path, _cost, _nodes, _graph = self.tsp_route(_courier_id, only_return=True)
            if _solved:
                soluble = True
                _courier.nodes = _nodes
                _courier.path = _path
                _courier.graph = _graph
                if _courier.status == "WaitingOrder":
                    _courier.status = None
                new_order.status = "Accepted"
                _nearest_courier_id = _courier_id
                self.ORDERS_CENTER.acceptedOrders.append(new_order)
                break
            else:
                _courier.ordersQueue.remove(new_order)
        if not soluble:
            new_order.status = "Dismissed"
            self.ORDERS_CENTER.dismissedOrders.append(new_order)
            new_order.reward = -1
        new_order.action = _nearest_courier_id
        return _nearest_courier_id

    @DeprecationWarning
    def construct_nodes(self, courier_id, only_return):
        """
        构造骑手路径节点map，更新骑手节点map，或者只返回而不更新
        :param only_return:True则只返回而不更新，False则同时更新
        :param courier_id:骑手id
        :return:
        """
        _courier = self.COURIERS_CENTER.couriers[courier_id]
        _current_edge = _courier.currentEdge
        _current_percent = _courier.currentEdgePercent
        _packages_queue = _courier.packagesQueue
        _orders_queue = _courier.ordersQueue
        _nodes = {0: [_current_edge, _current_percent]}
        _p_base = 1
        _s_base = 1 + len(_packages_queue)
        _c_base = _s_base + len(_orders_queue)
        for i, p in enumerate(_packages_queue):
            _nodes[_p_base + i] = [p.clientEdgeIdx, p.clientParkOffsetPercent, p, i, 1]  # 末位1代表client
        for i, s in enumerate(_orders_queue):
            _nodes[_s_base + i] = [s.shopEdgeIdx, s.shopParkOffsetPercent, s, i, 0]  # 末位0代表shop
        for i, c in enumerate(_orders_queue):
            _nodes[_c_base + i] = [c.clientEdgeIdx, c.clientParkOffsetPercent, c, i, 1]  # 末位1代表client
        if not only_return:
            _courier.nodes = _nodes
        return _nodes, _s_base, _c_base

    @DeprecationWarning
    def tsp_route(self, courier_id, only_return):
        """
        执行tsp_solver，生成（且更新）骑手路径、节点、图
        :param only_return: True则只返回而不更新，False则同时更新
        :param courier_id:骑手id
        :return:5元组(BOOL、LIST、FLOAT、MAP、LIST)，是否满足tsp条件，返回bool量，如果满足条件，更新该骑手graph、path、nodes
        """
        _courier = self.COURIERS_CENTER.couriers[courier_id]
        _nodes, _s_base, _c_base = self.construct_nodes(courier_id, only_return=True)
        _graph, _pickups_deliveries, _time_windows, _demands = self.gen_tsp_solver_params(_nodes, _s_base, _c_base)
        print(_time_windows)
        # print("debug_info:      courier_id:", courier_id, "   _time_windows:", _time_windows)  # debug
        _path, _cost = self.TSP.solve_tsp(_graph, _pickups_deliveries, _time_windows, _demands)
        if _path:
            if _courier.status == "WaitingClient":
                # print("before change path:", _path)
                _first_node = _nodes[_path[0]]
                _first_order = _first_node[2]
                if _first_order != _courier.waitingOrder:
                    _waiting_order_index = -1
                    for idx, _node in _nodes.items():
                        if idx == 0:
                            continue
                        if _node[2] == _courier.waitingOrder:
                            _waiting_order_index = idx
                            break
                    _path.remove(_waiting_order_index)
                    _path.insert(0, _waiting_order_index)
            if not only_return:
                _courier.graph = _graph
                _courier.path = _path
                _courier.nodes = _nodes
            return True, _path, _cost, _nodes, _graph
        else:
            return False, None, None, None, None

    @DeprecationWarning
    def _collect_states(self, new_order=None):
        """
        0:时间戳percent 1~4:新订单shop(x,y)、新订单client(x,y) percent
        5+n*43:各骑手state
        :return:
        """
        self._update_all_states()
        _state = [-1] * (5 + self.COURIERS_CENTER.courierNum * 43)
        _time_percent = self.timeLine / self.ORDERS_CENTER.lastOrderTime
        _shop_x_percent = -1
        _shop_y_percent = -1
        _client_x_percent = -1
        _client_y_percent = -1
        if new_order:
            _shop_x_percent, _shop_y_percent = self.NET.get_percent_by_edge_and_off(new_order.shopEdgeIdx,
                                                                                    new_order.shopParkOffsetPercent)
            _client_x_percent, _client_y_percent = self.NET.get_percent_by_edge_and_off(new_order.clientEdgeIdx,
                                                                                        new_order.clientParkOffsetPercent)
        _state[:5] = [_time_percent, _shop_x_percent, _shop_y_percent, _client_x_percent, _client_y_percent]
        for _n, _courier in self.COURIERS_CENTER.couriers.items():
            _state[(5 + _n * 43):(5 + (_n + 1) * 43)] = _courier.state
        if new_order:
            # print("new_order.state = _state")
            new_order.state = _state
        return _state

    @DeprecationWarning
    def _update_all_states(self):
        """
        注意：在此函数执行前，先将self.timeLine更新到最新
        :return:
        """
        for _courier_id in self.COURIERS_CENTER.couriers.keys():
            self._update_courier_state(_courier_id)

    @DeprecationWarning
    def _update_courier_state(self, courier_id):
        _courier = self.COURIERS_CENTER.couriers[courier_id]
        _nodes = _courier.nodes
        _path = _courier.path
        # print("debug_info:      courier:", courier_id)    # debug
        # print("debug_info:      courier_id:", courier_id, "   edge、percent: [", _courier.currentEdge, ",",
        #       _courier.currentEdgePercent, "] _nodes:", _nodes)    # debug
        # print("debug_info:      courier_id:", courier_id, "   path:", _path)    # debug
        # print("debug_info:      courier_id:", courier_id, "   status:", _courier.status)    # debug
        _courier_x_percent, _courier_y_percent = self.NET.get_percent_by_edge_and_off(_courier.currentEdge,
                                                                                      _courier.currentEdgePercent)
        _package_percent = len(_courier.packagesQueue) / _courier.packageLimit
        _state = [-1] * 43
        _state[:3] = [_courier_x_percent, _courier_y_percent, _package_percent]
        for _i, _p in enumerate(_path):
            if _i >= 10:
                break
            _node = _nodes[_p]
            _node_edge_idx = _node[0]
            _node_off_percent = _node[1]
            _mark = 1 if _node[-1] == 1 else -1  # client置1，shop置-1
            if _mark == 1:
                _remain_percent = _node[2].update_time(self.timeLine) / _node[2].timeLimit
            else:
                _remain_percent = -1
            _node_x_percent, _node_y_percent = self.NET.get_percent_by_edge_and_off(_node_edge_idx,
                                                                                    _node_off_percent)
            _state[3 + _i * 4:3 + (_i + 1) * 4] = [_node_x_percent, _node_y_percent, _remain_percent, _mark]
        _courier.state = _state

    @DeprecationWarning
    def gen_tsp_solver_params(self, nodes, s_base, c_base):
        """
        生成tsp_solver所需的参数
        :param nodes:
        :param s_base:
        :param c_base:
        :return:
        """
        _pickups_deliveries = []
        _time_windows = []
        _demands = []
        _orders_queue_len = c_base - s_base
        # print("c_base:", c_base, " s_base:", s_base, " orders_queue_len:", orders_queue_len)
        for _i, _node in nodes.items():
            if _i == 0:
                _time_windows.append((0, 1))
                _demands.append(0)
            elif 0 < _i < s_base:  # package indexs
                time2 = _node[2].update_time(self.timeLine)
                if time2 <= 0 and time2 >= -50:
                    time2 = 5
                _time_windows.append((0, time2))
                _demands.append(-1)
                _demands[0] += 1
            elif s_base <= _i < c_base:  # shop indexs
                time2 = _node[2].update_time(self.timeLine)
                if time2 <= 0 and time2 >= -50:
                    time2 = 5
                _time_windows.append((0, time2))
                _demands.append(1)
                _pickups_deliveries.append([_i, _i + _orders_queue_len])
            else:  # client indexs
                time2 = _node[2].update_time(self.timeLine)
                if time2 <= 0 and time2 >= -50:
                    time2 = 5
                _time_windows.append((0, time2))
                _demands.append(-1)
        _graph = self.gen_graph(nodes)
        return _graph, _pickups_deliveries, _time_windows, _demands

    @DeprecationWarning
    def gen_graph(self, nodes):
        """
        给定节点，构造并返回有向图，注意：对角线和第一列均设定为0
        :return: graph
        """
        _g = []
        for _i in range(len(nodes)):
            _r = []  # 每一行
            for _j in range(len(nodes)):
                if _i == _j or _j == 0:
                    _r.append(0.0)  # 第一列及对角线均设定为0
                else:
                    _r.append(self.calc_time(nodes[_i][0], nodes[_j][0], nodes[_i][1], nodes[_j][1])[0] + (
                        nodes[_j][2].waitingClientTime if nodes[_j][-1] == 1 else 0))
            _g.append(_r)
        return _g

    def calc_time(self, src_edge, dst_edge, src_percent=0.0, dst_percent=1.0):
        """
        计算从初始边及offset到终点边及offset所需时间
        :param src_edge: src所在的edge
        :param src_percent: src所在edge的百分比（注意，1.0-percent是需要途径的比例）
        :param dst_edge: dst所在的edge
        :param dst_percent: dst所在edge的百分比
        :return: 元组(Float,List)从起点位置到终点所需时间，途径各edge各自所需时间的列表（首末除去百分比部分）
        """
        _edges = self.find_path(src_edge, dst_edge)
        _edges_time = []
        _edges_total_time = []
        if len(_edges) == 0:
            print("地图数据错误，有未连通的边 ", src_edge, " => ", dst_edge, " ，请检查并重新生成地图数据")
            print("src_edge:", self.NET.revEdgesMap[src_edge])
            print("dst_edge:", self.NET.revEdgesMap[dst_edge])
            return
        elif len(_edges) == 1:
            _time_total = self._edge_travel_time_map_func(src_edge)
            _time = abs(dst_percent - src_percent) * _time_total
            return _time, [_time], _edges, [_time_total]
        else:
            _time_total = 0
            for _i, _edge in enumerate(_edges):
                if _i == 0:
                    _time = self._edge_travel_time_map_func(src_edge)
                    _edges_total_time.append(_time)
                    _time = _time * (1.0 - src_percent)
                    _time_total += _time
                    _edges_time.append(_time)
                elif _i == len(_edges) - 1:
                    _time = self._edge_travel_time_map_func(dst_edge)
                    _edges_total_time.append(_time)
                    _time = _time * dst_percent
                    _time_total += _time
                    _edges_time.append(_time)
                else:
                    _time = self._edge_travel_time_map_func(_edge)
                    _time_total += _time
                    _edges_time.append(_time)
                    _edges_total_time.append(_time)
            return _time_total, _edges_time, _edges, _edges_total_time

    def find_path(self, src_edge, dst_edge):
        """
        通过src和dst两条edge，获取途径的所有edge的列表
        :param src_edge: src所在的edge
        :param dst_edge: dst所在的edge
        :return: 起点到终点途径的edge列表
        """
        return self._edges_travel_pass_map_func(src_edge, dst_edge)

    @DeprecationWarning
    def sim_step_for_all(self, delta_time):
        """

        :return:
        """
        for courier_id in self.COURIERS_CENTER.couriers.keys():
            # if courier_id == 0:  # debug
            #     print("Time:  ", self.timeLine, " s")
            #     print("begin debug_time")
            #     self.debug_time(courier_id)
            #     print("delta_time:", delta_time)
            self.sim_step(courier_id, delta_time)
            # if courier_id == 0:  # debug
            #     print("after debug_time")
            #     self.debug_time(courier_id)
            #     print()
        self.timeLine += delta_time

    # new
    def generate_all_nodes(self):
        """
        时间线回合开始时，收集所有骑手位置与需求、新老订单（非绑定）位置与时间窗和需求、绑定订单的绑定ID与位置和时间窗及需求
        :return:
        """
        _speed = 1
        _node_id_to_order_id_map: dict[int, int] = {}
        _node_id_bias = self.COURIERS_CENTER.courierNum - 1
        _node_id = 1
        _order_nodes_pos = []  # 在OrdersCenter的dispatchedOrders中，状态为DISPATCHED的订单的节点位置
        _order_nodes_time_windows = []  # 每个节点的时间窗
        _order_nodes_demands = []  # 商户节点+1，客户节点-1
        _pd = []  # 先取后送，每个元素为(取id，送id)
        _new_orders_nodes = []  # 当前时间隙的新订单，元素均为二元列表[[shop_node,customer_node],...]
        # 所有已分配的订单节点，不算绑定节点（已取餐），形如：[[],[5,7],[6,8],[]]，即共4辆车，5,7绑定-3号车，6,8绑定-2号车
        _dispatched_orders_nodes = [[] for _ in range(self.COURIERS_CENTER.courierNum)]
        for _order in self.ORDERS_CENTER.dispatchedOrders:
            if _order.status != OrderStatusEnum.DISPATCHED:
                raise Exception("error!")
            if _order.status == OrderStatusEnum.DISPATCHED:  # 已下单，未被骑手取走（未与骑手绑定）
                _order_nodes_pos.append((_order.shopEdgeIdx, _order.shopParkOffsetPercent))
                _pick_id = _node_id
                _order_nodes_time_windows.append((0, _order.createTimePoint + _order.timeLimit - self.timeLine))
                _node_id_to_order_id_map[_node_id + _node_id_bias] = _order.id
                _order_nodes_demands.append(1)
                _node_id += 1
                _order_nodes_pos.append((_order.clientEdgeIdx, _order.clientParkOffsetPercent))
                _delivery_id = _node_id
                _order_nodes_time_windows.append((0, _order.createTimePoint + _order.timeLimit - self.timeLine))
                _node_id_to_order_id_map[_node_id + _node_id_bias] = _order.id
                _order_nodes_demands.append(-1)
                _node_id += 1
                _pd.append([_pick_id, _delivery_id])
                if _order.isNewOrder == True:
                    _new_orders_nodes.append([_pick_id, _delivery_id])
                else:
                    _dispatched_orders_nodes[_order.dispatchedToCourierID].append([_pick_id, _delivery_id])
        _vehicle_pos = []  # (edge_id,edge_percent)
        _vehicle_time_windows = []
        _vehicle_demands = []
        _binding_nodes_pos = []
        _binding_nodes_time_windows = []
        _binding_nodes_id = []
        _binding_nodes_demands = []
        for _v in self.COURIERS_CENTER.couriers.values():
            _vehicle_pos.append((_v.currentEdge, _v.currentEdgePercent))
            _vehicle_time_windows.append((0, 10 ** 5))
            _vehicle_demands.append(len(_v.packagesQueue))
            _vehicle_binding_nodes_id = []
            for _binding_order in _v.packagesQueue:
                if _binding_order.status != OrderStatusEnum.DELIVERING:
                    raise Exception("error!")
                _binding_nodes_pos.append((_binding_order.clientEdgeIdx, _binding_order.clientParkOffsetPercent))
                _vehicle_binding_nodes_id.append(_node_id)
                _binding_nodes_time_windows.append(
                    (0, _binding_order.createTimePoint + _binding_order.timeLimit - self.timeLine))
                _node_id_to_order_id_map[_node_id + _node_id_bias] = _binding_order.id
                _binding_nodes_demands.append(-1)
                _node_id += 1
            _binding_nodes_id.append(_vehicle_binding_nodes_id)
        _depots = list(range(self.COURIERS_CENTER.courierNum))  # 车辆节点索引
        _all_nodes_pos = _vehicle_pos + _order_nodes_pos + _binding_nodes_pos
        _all_time_windows = _vehicle_time_windows + _order_nodes_time_windows + _binding_nodes_time_windows
        _all_demands = _vehicle_demands + _order_nodes_demands + _binding_nodes_demands
        _service_time = [0] * len(_all_nodes_pos)  # 每个节点服务时间
        _time_matrix = self.generate_graph(_all_nodes_pos, _service_time)[0]
        _distance_matrix = _time_matrix
        return _time_matrix, _pd, _all_time_windows, _all_demands, _depots, _binding_nodes_id, self.COURIERS_CENTER.courierNum, self.COURIERS_CENTER.packageLimit, _distance_matrix, _service_time, _node_id_to_order_id_map, _new_orders_nodes, _dispatched_orders_nodes

    def finish_and_analyze(self):
        for _order in self.ORDERS_CENTER.completedOrders:
            print(_order.createTimePoint, '\t: ', _order.completeTimePoint - _order.createTimePoint, "")

        for _courier in self.COURIERS_CENTER.couriers.values():
            for _order in _courier.packagesQueue:
                print("in pkg:", _order.createTimePoint)
        self.save_simulation_data()

    def save_simulation_data(self):
        """
        保存每次实验模拟仿真的原始数据
        :return:
        """
        import json
        _simulation_orders_map = {}  # 用于存储每个订单的开始时间（键）与实际完成用时（值）
        for _order in self.ORDERS_CENTER.completedOrders:
            _simulation_orders_map[_order.createTimePoint] = _order.completeTimePoint - _order.createTimePoint
        _meta_info_map = {  # 模拟的元信息
            "Solver_Name": self.Solver_Name,
            "Order_Time_Begin": self.begin_time_str,
            "Order_Time_End": self.end_time_str,
            "Courier_Number": self.COURIERS_CENTER.courierNum,
            "Interval_Time": self.time_interval_for_dispatch
        }
        _f = open(self.process_dir + '/' + self.Solver_Name + '_' + "orders_data_" + str(self.seed) + ".json", 'w')
        _process_data = json.dumps(_simulation_orders_map, indent=2, ensure_ascii=False)
        _f.write(_process_data)
        _f.close()
        time.sleep(1)
        _f = open(self.parameter_dir + '/' + self.Solver_Name + '_' + "meta_info_" + str(self.seed) + ".json", 'w')
        _parameter_data = json.dumps(_meta_info_map, indent=2, ensure_ascii=False)
        _f.write(_parameter_data)
        _f.close()

    def run(self):
        def _solution_into_routes(route, depots):
            """
            将求得的解划分为各骑手的路径并返回
            :param route:
            :return:
            """
            _split_routes = []
            _split_index = 0
            _routes_len = len(route)
            for _i, _node in enumerate(route):
                if _i == 0:
                    continue
                if _node in depots:
                    _split_routes.append(route[_split_index:_i])
                    _split_index = _i
                if _i == (_routes_len - 1):
                    _split_routes.append(route[_split_index:])
                    _split_routes_copy = copy.deepcopy(_split_routes)
                    return _split_routes

        _back_split_routes = [[]] * self.COURIERS_CENTER.courierNum  # 用于备份路线，当下一个事件阶段没有新的订单时，继续之前路线前进
        _back_node_id_to_order_id_map = dict()
        while not (len(self.ORDERS_CENTER.completedOrders) == self.ORDERS_CENTER.orderNum):
            self.timeLine += self.time_interval_for_dispatch  # 时间线前进
            # 当所有订单都派发完，且已派发订单都已完成
            # 更新self.ORDERS_CENTER.dispatchedOrders中每个订单的_order.isNewOrder，以前时间隙分配的订单，在当前时间隙为非新订单
            for _order in self.ORDERS_CENTER.dispatchedOrders:
                _order.isNewOrder = False
            # 更新self.ORDERS_CENTER.dispatchedOrders
            _new_dispatch_orders = []
            for _order in self.ORDERS_CENTER.orders:
                if _order.createTimePoint <= self.timeLine:
                    _new_dispatch_orders.append(_order)
                    _order.isNewOrder = True
                    if _order.status != OrderStatusEnum.NOT_DISPATCHED:
                        raise Exception("error!")
                else:
                    break
            # print("_back_split_routes:",_back_split_routes)
            if _new_dispatch_orders:  # 当该时间段没有新订单分配，继续执行之前的路线
                _back_split_routes = [[]] * self.COURIERS_CENTER.courierNum
                for _order in _new_dispatch_orders:
                    self.ORDERS_CENTER.orders.remove(_order)
                    _order.status = OrderStatusEnum.DISPATCHED
                self.ORDERS_CENTER.dispatchedOrders = self.ORDERS_CENTER.dispatchedOrders + _new_dispatch_orders
                _time_mat, _pd, _time_windows, _demands, _depots, _binding_nodes_id, _courier_num, _package_limit, _distance_mat, _service_time, _node_id_to_order_id_map, _new_orders_nodes, _dispatched_orders_nodes = self.generate_all_nodes()
                _solution_route, _ = self.Solver.solve_vrp(_time_mat, _pd, _time_windows, _demands, _depots,
                                                           _binding_nodes_id,
                                                           _courier_num, _package_limit, _distance_mat, _service_time,
                                                           False, _new_orders_nodes, _dispatched_orders_nodes)
                _split_routes = _solution_into_routes(_solution_route, _depots)
                for _sub_route in _split_routes:
                    if len(_sub_route) == 1:
                        break
                    _v_id = -1
                    for _i, _node in enumerate(_sub_route):
                        if _i == 0:
                            _v_id = _node
                        else:
                            self.ORDERS_CENTER.order_id_to_order_map[
                                _node_id_to_order_id_map[_node]].dispatchedToCourierID = _v_id  # 订单分配给某个骑手

                _back_node_id_to_order_id_map = copy.deepcopy(_node_id_to_order_id_map)
                # print("timeline:", self.timeLine, "\t route:", _solution_route)  # debug
                # print("_split_routes:", _split_routes)
                # print("_new_orders_nodes:", _new_orders_nodes)
                # print("_dispatched_orders_nodes:", _dispatched_orders_nodes)
                # print("_binding_nodes_id:", _binding_nodes_id)
                # print("completedOrders:", self.ORDERS_CENTER.completedOrders)
                # print()

                for _v_id in range(_courier_num):
                    _back_split_routes[_v_id] = self._vehicle_run(_v_id, self.time_interval_for_dispatch,
                                                                  _split_routes[_v_id],
                                                                  _node_id_to_order_id_map)
                def calTotalDist(split_routes, time_mat):  
                    totalD = 0
                    for route in split_routes:
                        if len(route) < 2:
                            continue
                        for i in range(len(route)-1):
                            totalD += time_mat[route[i]][route[i+1]]
                    print("Total Dist: {}".format(totalD))  
                calTotalDist(_split_routes, _time_mat)    
                def callGVRP(distance_matrix, time_matrix, num_vehicles, starts, ends, vehicle_capacities, demands, pickups_deliveries, time_windows):
                    pickups_deliveries = list(map(tuple, pickups_deliveries))
                    from GVRPSolver import GVRPSolver
                    data = {}
                    data['distance_matrix'] = distance_matrix
                    data['distance_matrix'] = [list(map(int,i)) for i in data['distance_matrix']]
                    data['num_vehicles'] = num_vehicles
                    data['starts'] = starts
                    data['ends'] = ends
                    for i in range(len(data['distance_matrix'])):
                        for j in range(len(data['distance_matrix'][0])):
                            if j in data['ends']:
                                data['distance_matrix'][i][j] = 0
                    data['vehicle_capacities']=vehicle_capacities
                    data['demands'] = demands
                    data['pickups_deliveries'] = pickups_deliveries
                    data['time_matrix'] = data['distance_matrix']
                    data['time_windows'] = time_windows
                    
                    def writeToCSV(dt, name):
                        import csv
                        with open('../test/data/'+name+'.csv', 'w') as f:
                            write = csv.writer(f)
                            write.writerows(dt)
                    writeToCSV(data['distance_matrix'], 'distance_matrix')
                    writeToCSV([[data['num_vehicles']]], 'num_vehicles')
                    writeToCSV([data['starts']], 'starts')
                    writeToCSV([data['ends']], 'ends')
                    writeToCSV([data['vehicle_capacities']], 'vehicle_capacities')
                    writeToCSV([data['demands']], 'demands')
                    writeToCSV(data['pickups_deliveries'], 'pickups_deliveries')
                    writeToCSV(data['time_windows'], 'time_windows')
                    
                    print(GVRPSolver.solve(data)[0])

                callGVRP(_time_mat, _time_mat, _courier_num, _depots, _depots, [_package_limit for i in range(_courier_num)], _demands, _pd, _time_windows)
            else:
                # print("timeline:", self.timeLine)  # debug
                # print("_back_split_routes:", _back_split_routes)
                for _v_id in range(self.COURIERS_CENTER.courierNum):
                    # print("_back_split_routes in else:",_back_split_routes,"_v_id:",_v_id)
                    _back_split_routes[_v_id] = self._vehicle_run(_v_id, self.time_interval_for_dispatch,
                                                                  _back_split_routes[_v_id],
                                                                  _back_node_id_to_order_id_map)
        self.finish_and_analyze()

    def _vehicle_run(self, vehicle_id, interval_time, sub_route: list, node_id_to_order_id_map: dict[int, int]):
        _back_sub_route = copy.deepcopy(sub_route)
        # 未分配任何订单
        if len(sub_route) == 1:
            # print("return what:", _back_sub_route)
            return _back_sub_route
        _remain_time = interval_time
        _courier = self.COURIERS_CENTER.couriers[vehicle_id]
        for _i in range(len(sub_route) - 1):
            # 1.生成相邻节点位置
            if _i == 0:
                _node_src_pos = (_courier.currentEdge, _courier.currentEdgePercent)
            else:
                _node_src_order = self.ORDERS_CENTER.order_id_to_order_map[node_id_to_order_id_map[sub_route[_i]]]
                if _node_src_order.status == OrderStatusEnum.DELIVERING:
                    _node_src_pos = (_node_src_order.shopEdgeIdx, _node_src_order.shopParkOffsetPercent)
                elif _node_src_order.status == OrderStatusEnum.COMPLETED:
                    _node_src_pos = (_node_src_order.clientEdgeIdx, _node_src_order.clientParkOffsetPercent)
                else:
                    raise Exception("error!")
            _node_dst_order = self.ORDERS_CENTER.order_id_to_order_map[node_id_to_order_id_map[sub_route[_i + 1]]]
            if _node_dst_order.status == OrderStatusEnum.DISPATCHED:
                _node_dst_pos = (_node_dst_order.shopEdgeIdx, _node_dst_order.shopParkOffsetPercent)
            elif _node_dst_order.status == OrderStatusEnum.DELIVERING:
                _node_dst_pos = (_node_dst_order.clientEdgeIdx, _node_dst_order.clientParkOffsetPercent)
            else:
                raise Exception("error!")
            if _node_src_pos[0] != _courier.currentEdge and _node_src_pos[1] != _courier.currentEdgePercent:
                raise Exception("error!")

            # 2.计算得到相邻节点途径边集与时间集
            _need_time, _need_time_list, _edges_list, _edges_total_time_list = self.calc_time(_node_src_pos[0],
                                                                                              _node_dst_pos[0],
                                                                                              _node_src_pos[1],
                                                                                              _node_dst_pos[1])
            # 3.依次遍历两节点间所有边，直到_remain_time小于某边所需时间
            if _need_time <= _remain_time:  # 行动时间足够两节点间的行动
                _remain_time -= _need_time
                _courier.currentEdge = _node_dst_pos[0]
                _courier.currentEdgePercent = _node_dst_pos[1]
                if _node_dst_order.status == OrderStatusEnum.DISPATCHED:  # 已分配但未取货
                    _node_dst_order.status = OrderStatusEnum.DELIVERING
                    self.ORDERS_CENTER.dispatchedOrders.remove(_node_dst_order)
                    _courier.packagesQueue.append(_node_dst_order)
                    _back_sub_route.remove(sub_route[_i + 1])
                elif _node_dst_order.status == OrderStatusEnum.DELIVERING:  # 已取货待配送
                    _node_dst_order.status = OrderStatusEnum.COMPLETED
                    self.ORDERS_CENTER.completedOrders.append(_node_dst_order)
                    _courier.packagesQueue.remove(_node_dst_order)
                    _node_dst_order.complete(self.timeLine, self.time_interval_for_dispatch - _remain_time)
                    _back_sub_route.remove(sub_route[_i + 1])
                else:
                    raise Exception("error!")
                continue
            else:  # 行动时间不足够两节点间行动
                if len(_need_time_list) == 1:  # 当两节点在同一个边
                    if _node_dst_pos[1] >= _node_src_pos[1]:
                        _courier.currentEdgePercent += _remain_time / _edges_total_time_list[0]
                    else:
                        _courier.currentEdgePercent -= _remain_time / _edges_total_time_list[0]
                    return _back_sub_route
                else:
                    for _j in range(len(_need_time_list)):
                        _courier.currentEdge = _edges_list[_j]
                        if _need_time_list[_j] >= _remain_time:  # 不足够行动
                            if _j == 0:
                                _courier.currentEdgePercent += _remain_time / _edges_total_time_list[_j]
                            else:
                                _courier.currentEdgePercent = _remain_time / _edges_total_time_list[_j]
                            return _back_sub_route
                        else:
                            _remain_time -= _need_time_list[_j]
                            continue
        return _back_sub_route
        # 4.如果遍历了该节点所有边，则完成该节点，置位相关状态属性

    # new
    def generate_graph(self, all_nodes_pos: list[tuple[int, float]], service_time):
        _ret_time_matrix = []
        _ret_distance_matrix = []

        for _i, _pos_src in enumerate(all_nodes_pos):
            _distance_vec = []
            _time_vec = []
            for _j, _pos_dst in enumerate(all_nodes_pos):
                if _i == _j:
                    _distance_vec.append(0)
                    _time_vec.append(0)
                else:
                    _time = self.calc_time(_pos_src[0], _pos_dst[0], _pos_src[1], _pos_dst[1])[0]
                    _distance_vec.append(_time)
                    _time_vec.append(_time)
            _ret_time_matrix.append(_time_vec)
            _ret_distance_matrix.append(_distance_vec)
        return _ret_time_matrix, _ret_distance_matrix

    @DeprecationWarning
    def sim_step(self, courier_id, delta_time):
        """
        骑手步进指定delta_time时间
        delta_time为0或骑手此时无订单时，直接跳过
        否则执行delta_time时间

        :param courier_id: 骑手id
        :param delta_time:步进时间
        :return:
        """

        if delta_time == 0:
            return
        _courier = self.COURIERS_CENTER.couriers[courier_id]

        _total_delta_time = delta_time

        for _i in _courier.path:  # 按path顺序进行

            if _i == 0:  # i==0为骑手所在位置
                continue
            else:
                _heading_node = _courier.nodes[_i]
                _heading_order = _courier.nodes[_i][2]
                # if courier_id == 0:  # debug
                #     print("1 _heading_order:", _heading_order)
                #     print("1 _courier.packagesQueue:", _courier.packagesQueue)
                if _courier.status == "WaitingClient" and delta_time < _courier.parkingTime:  # 如果当前正等待顾客取餐，且行动时间不足
                    _courier.parkingTime -= delta_time
                    _heading_order.waitingClientTime = _courier.parkingTime
                    return
                elif _courier.status == "WaitingClient" and delta_time >= _courier.parkingTime:  # 如果当前正等待顾客取餐，且行动时间足够，
                    delta_time -= _courier.parkingTime
                    _courier.parkingTime = 5
                    _courier.status = None
                    _courier.waitingOrder = None
                    # 当前节点完成
                    self.ORDERS_CENTER.completedOrders.append(_heading_order)
                    # _heading_order.update_time(self.timeLine, _total_delta_time - delta_time)
                    _heading_order.complete(self.timeLine, _total_delta_time - delta_time)
                    # if courier_id == 0:  # debug
                    #     print("2 _heading_order:", _heading_order)
                    #     print("2 _courier.packagesQueue:", _courier.packagesQueue)
                    # print("who before:", courier_id)    # debug
                    _courier.packagesQueue.remove(_heading_order)
                    _courier.nodes.pop(_i)
                    _courier.path.remove(_i)
                    # print("who after:", courier_id) # debug
                elif _courier.status is None:  # 如果骑手在行动
                    _need_time, _need_time_list, _edges_list, _edges_total_time = self.calc_time(_courier.currentEdge,
                                                                                                 _heading_node[0],
                                                                                                 _courier.currentEdgePercent,
                                                                                                 _heading_node[1])
                    # if courier_id==0:   # debug
                    #     print("_need_time:",_need_time," _need_time_list:", _need_time_list, " _edges_list:",_edges_list)
                    if delta_time >= _need_time:  # 行动时间足够
                        # if courier_id == 0:  # debug
                        #     print("行动时间足够,_heading_node[0]",_heading_node[0]," delta_time=",delta_time)
                        delta_time -= _need_time
                        _courier.currentEdge = _heading_node[0]
                        _courier.currentEdgePercent = _heading_node[1]
                        _courier.nodes[0] = [_courier.currentEdge, _courier.currentEdgePercent]
                        if _heading_node[-1] == 1:  # 是client
                            _courier.status = "WaitingClient"
                            _courier.waitingOrder = _heading_order
                            # print("_courier.parkingTime:", _courier.parkingTime)    # debug
                            if delta_time >= _courier.parkingTime:  # 足以等到顾客
                                # if courier_id == 0:  # debug
                                #     print("行动等到顾客,_heading_node[0]:", _heading_node[0]," delta_time=",delta_time)
                                delta_time -= _courier.parkingTime
                                _courier.parkingTime = 5
                                _courier.status = None
                                _courier.waitingOrder = None
                                # 当前节点完成
                                self.ORDERS_CENTER.completedOrders.append(_heading_order)
                                # _heading_order.update_time(self.timeLine, _total_delta_time - delta_time)
                                _heading_order.complete(self.timeLine, _total_delta_time - delta_time)
                                # if courier_id == 0:  # debug
                                #     print("3 _heading_order:", _heading_order)
                                #     print("3 _courier.packagesQueue:", _courier.packagesQueue)
                                # print("who before:", courier_id)    # debug
                                _courier.packagesQueue.remove(_heading_order)
                                _courier.nodes.pop(_i)
                                _courier.path.remove(_i)
                                # print("who after:", courier_id) # debug
                            else:  # 不足以等到顾客
                                # if courier_id == 0:  # debug
                                #     print("不足以等到顾客,_heading_node[0]:", _heading_node[0]," delta_time=",delta_time)
                                _courier.parkingTime -= delta_time
                                _heading_order.waitingClientTime = _courier.parkingTime
                                return
                        elif _heading_node[-1] == 0:  # 是shop
                            # 当前节点完成
                            _courier.packagesQueue.append(_heading_order)
                            _courier.ordersQueue.remove(_heading_order)
                            _courier.nodes.pop(_i)
                            _courier.path.remove(_i)
                    else:  # 行动时间不足
                        # if courier_id == 0:  # debug
                        #     print("行动时间不足,_heading_node[0]:", _heading_node[0])
                        #     print("_courier.currentEdge:",_courier.currentEdge)
                        #     print("_courier.currentEdgePercent:",_courier.currentEdgePercent)
                        #     print("_heading_node:",_heading_node)
                        if len(_need_time_list) == 1:  # 骑手当前在node所在edge上
                            _courier.status = None
                            _courier.waitingOrder = None
                            if _heading_node[1] >= _courier.currentEdgePercent:
                                # if courier_id == 0:  # debug
                                #     print("prev:_courier.currentEdgePercent:", _courier.currentEdgePercent)
                                #     print("delta_time / _need_time_list[0]:",delta_time / _edges_total_time[0])
                                _courier.currentEdgePercent += delta_time / _edges_total_time[0]
                                # if courier_id == 0:  # debug
                                #     print("after:_courier.currentEdgePercent:",_courier.currentEdgePercent)
                            else:
                                _courier.currentEdgePercent -= delta_time / _edges_total_time[0]
                            _courier.nodes[0] = [_courier.currentEdge, _courier.currentEdgePercent]
                            return
                        for _j, _edge_time in enumerate(_need_time_list):
                            if delta_time >= _edge_time:
                                delta_time -= _edge_time
                                continue
                            else:
                                _courier.status = None
                                _courier.waitingOrder = None
                                _courier.currentEdge = _edges_list[_j]
                                if _j == 0:
                                    _courier.currentEdgePercent += delta_time / _edges_total_time[_j]
                                else:
                                    _courier.currentEdgePercent = delta_time / _edges_total_time[_j]
                                _courier.nodes[0] = [_courier.currentEdge, _courier.currentEdgePercent]
                                return
        _courier.status = "WaitingOrder"

    @DeprecationWarning
    def step(self, action=None, tsp_dispatch=False, nearest_dispatch=False):
        """
        每秒一单
        先执行分配，再检测本次订单与前一次订单时间是否相同，相同则只更新分配的骑手状态，不让模拟器步进，否则执行分配且模拟器步进
        :param nearest_dispatch: 是否采用就近分配方式
        :param tsp_dispatch: 是否采用tsp分配方式
        :param action:分配的骑手id
        :return:执行或分配后的最新状态
        """
        print("debug_info:      begin_time:", self.timeLine)  # debug
        _state = []
        _reward = []
        _done = False
        _available_actions = [1] * self.COURIERS_CENTER.courierNum
        _available_actions = [i for i, x in enumerate(_available_actions) if x == 1]
        if action is not None:  # 如果有分派，则分派，没有则直接执行到新的时间点
            if tsp_dispatch:
                self.tsp_dispatch(new_order=self.newOrders)
            elif nearest_dispatch:
                self.nearest_dispatch(new_order=self.newOrders)
            else:
                self.dispatch_to_courier(action, self.newOrders)
                self.newOrders.action = action
            self.newOrders = None

        _order, _delta_time = self.ORDERS_CENTER.pop_new_order(self.timeLine)
        if _order:
            # print("debug_info:      order_time: ", _order.createTime)    # debug
            self.sim_step_for_all(_delta_time)
            # self.debug_time(1)  # debug
            _state = self._collect_states(_order)
            self.newOrders = _order
        else:
            _done = True
            # print("after done") # debug
            while not self.ORDERS_CENTER.check_done():
                self.sim_step_for_all(delta_time=1)
        # print("debug_info:      end_time:", self.timeLine)    # debug
        print()
        return _state, _done, _available_actions

    def debug_time(self, courier_id):
        _courier = self.COURIERS_CENTER.couriers[courier_id]
        print("骑手 %2d status: %14s edge: %4d off: %6.2f" % (
            courier_id, _courier.status, _courier.currentEdge, _courier.currentEdgePercent))

        _nodes = _courier.nodes
        _path = _courier.path
        print("path:", _path)
        print("nodes:", _nodes)
        _path = [0] + _path
        for i in range(len(_path)):
            if i == 0:
                continue
            else:
                _need_time, _edges_time, _edges, _ = self.calc_time(_nodes[_path[i - 1]][0], _nodes[_path[i]][0],
                                                                    _nodes[_path[i - 1]][1],
                                                                    _nodes[_path[i]][1])
                _edges_len = len(_edges)
                print("=== %6.2f s and %3d,edges ===>  %4d %s(%10s) off%%%6.2f" % (_need_time, _edges_len,
                                                                                   _nodes[_path[i]][2].clientEdgeIdx if
                                                                                   _nodes[_path[i]][
                                                                                       -1] else
                                                                                   _nodes[_path[i]][2].shopEdgeIdx,
                                                                                   _nodes[_path[i]][2],
                                                                                   "client" if _nodes[_path[i]][
                                                                                                   -1] == 1 else "shop",
                                                                                   _nodes[_path[i]][
                                                                                       2].clientParkOffsetPercent if
                                                                                   _nodes[_path[i]][
                                                                                       -1] else
                                                                                   _nodes[_path[i]][
                                                                                       2].shopParkOffsetPercent),
                      "_edges_time:", _edges_time, "_edges:", _edges)


def mp_run(seed: int, solver_name: str, process_dir, parameter_dir, allow_orders_to_be_reassigned):
    print("solver:", solver_name, " seed:", seed, " start.")
    dispatcher = Dispatcher(seed=seed, solver_name=solver_name, process_dir=process_dir, parameter_dir=parameter_dir,
                            allow_orders_to_be_reassigned=allow_orders_to_be_reassigned)
    dispatcher.run()
    print("solver:", solver_name, " seed:", seed, " finished.")
    gc.collect()


if __name__ == '__main__':

    img_dir = gen_dir()
    process_dir = img_dir + "/process"
    parameter_dir = img_dir + "/parameters"
    solver_names = ["NMA", "MA", "GA", "SA", "TS"]
    solver_name = "NMA"
    allow_orders_to_be_reassigned = False  # 是否允许旧订单二次分配

    process_pool = Pool(1)

    if False:
        for _ in range(6):
            process_pool.apply_async(mp_run, args=(
            random.randint(1,10**5), solver_name, process_dir, parameter_dir, allow_orders_to_be_reassigned))
        process_pool.close()
        process_pool.join()
    elif True:
        mp_run(random.randint(1,10**5), solver_name, process_dir, parameter_dir, allow_orders_to_be_reassigned)

    print("All finished!")
