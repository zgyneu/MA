def mkdir(path):
    """创建文件夹"""
    import os
    path = path.strip()
    path = path.rstrip("\\")
    is_exists = os.path.exists(path)
    if not is_exists:
        os.makedirs(path)
        print(path, " 文件夹创建成功")
        return True
    else:
        print(path, "目录已存在")
        return False


def avg_list(list_data):
    list_len = len(list_data)
    return sum_list(list_data) / list_len


def sum_list(list_data):
    list_sum = 0
    for e in list_data:
        list_sum += e
    return list_sum


if __name__ == '__main__':
    from Dispatcher_Periodic import Dispatcher
    import pandas as pd
    from matplotlib import pyplot as plt
    dispatcher = Dispatcher()
    actionCollector = []
    scoreCollector = []
    timeCollector = []
    s = dispatcher.reset()
    done = False
    while True:
        if s:
            s, done, _ = dispatcher.step(-1, tsp_dispatch=True)
        else:
            s, done, _ = dispatcher.step()

        if done:
            efficiency = len(dispatcher.ORDERS_CENTER.completedOrders) / dispatcher.ORDERS_CENTER.orderNum
            for i, order in enumerate(dispatcher.ORDERS_CENTER.acceptedOrders):
                m_action = order.action
                m_reward = order.reward
                m_last = order.last / 60
                actionCollector.append(m_action)
                scoreCollector.append(m_reward)
                timeCollector.append(m_last)  # 单位分钟
            dispatcher.reset()
            break
    mkdir('../plots/box')
    print("avg score:",avg_list(scoreCollector))
    print("avg time:",avg_list(timeCollector))
    print("efficiency:",efficiency)
    df=pd.DataFrame(timeCollector)
    df.plot.box(title="every order's completion time")
    plt.xlabel('TSP_Based')
    plt.ylabel('completion time')
    plt.grid(linestyle="--", alpha=0.3)
    plt.savefig('../plots/box/tsp.svg')
    print("done")
