from enum import Enum


class OrderStatusEnum(Enum):
    NOT_DISPATCHED = 1
    DISPATCHED = 2
    DELIVERING = 3
    COMPLETED = 4


# Ordersim模块共有OrdersCenter和Order两个类
class OrdersCenter:
    """
    OrderCenter类，主要功能有：
    ①：读取订单数据OrderData.json
    ②：给定时间段，取时间段内的订单数据生成订单对象
    ③：托管所有订单对象
    构造函数：
    OrdersCenter(begin_str, end_str, src)
    接口函数：
    1 ：reset()                  重置所有订单非固定参数
    接口变量：
    Ordersim.orders                     订单列表
    Ordersim.orderNum                   订单数量
    Ordersim.newOrderEventLine          按序存储所有订单生成时间的列表
    Ordersim.lastOrderTime              最后一个订单的开始时间
    Ordersim.dispatchedOrders           已分派的订单列表（无论是否成功）
    Ordersim.dismissedOrders            未能成功分派的订单列表
    Ordersim.acceptedOrders             成功分派的订单列表
    Ordersim.completedOrders            已完成的订单列表
    """

    def __init__(self, begin_str, end_str, src="../mapdata/OrderData.json", time_limit=30 * 60):
        """
        构造函数
        :param begin_str: 字符串格式，时间段起始时间 如：'2016-5-18 10:00:01'
        :param end_str: 字符串格式，时间段结束时间 如：'2016-5-18 10:10:59'
        :param src:订单数据json文件
        :param time_limit: 订单允许时限
        """
        from copy import deepcopy

        self._beginStr = begin_str
        self._endStr = end_str
        self._beginStamp = 0
        self._endStamp = 0
        self._orderDataPath = src
        self._ordersTimeLimit = time_limit
        self._globalTimeInit = 0  # 所有订单（非选择时段内）的最早时间戳
        self._globalTimeEnd = 0  # 所有订单（非选择时段内）的最晚时间戳
        self.orders: list[Order] = []  # 订单列表，每达到新的订单时，pop出队首
        self.order_id_to_order_map:dict[int,Order] = {}
        self.orderNum = 0
        self.newOrderEventLine = []  # 按序存储所有订单生成时间
        self._load_orders()
        self._constOrders = []
        self._constNewOrderEventLine = deepcopy(self.newOrderEventLine)
        self.dispatchedOrders: list[Order] = []  # 存储已生成但未完成（未被骑手取走）的订单对象
        self.completedOrders: list[Order] = []

    def reset(self):
        """
        重置所有订单非固定参数
        :return:void
        """
        from copy import deepcopy

        # for o in self.orders:
        #     o.reset()
        self.newOrderEventLine = deepcopy(self._constNewOrderEventLine)
        self.dispatchedOrders = []
        self.completedOrders = []
        self.orders = deepcopy(self._constOrders)

    def _load_orders(self):
        """
        通过读取OrderData.json文件，得到数据格式如下：
            'id': '14620787667624', 'sIdx': 2, 'cIdx': 2
        :no return: ①self._edgesList 边列表；②self._edgesMap 边id => idx； ③self._revEdgesMap 边idx => id .
        """
        from json import load as load

        with open(self._orderDataPath, 'r', encoding='UTF-8') as f:  # 导入所有edge数据
            orders_data = load(f)
            f.close()
        self._globalTimeInit = orders_data[0]["id"][0:10]
        self._globalTimeEnd = orders_data[-1]["id"][0:10]
        new_init_time = 0
        self._beginStamp = self.time_to_time_stamp(self._beginStr)
        self._endStamp = self.time_to_time_stamp(self._endStr)
        for i, item in enumerate(orders_data):
            if not new_init_time and int(item["id"][0:10]) < self._beginStamp:
                continue
            elif not new_init_time:
                new_init_time = int(item["id"][0:10])
            if item["sIdx"] != item["cIdx"]:
                create_time = int(item["id"][0:10]) - new_init_time
                self.orders.append(
                    Order(item["id"], create_time, item["sIdx"], item["cIdx"], time_limit=self._ordersTimeLimit))
                self.newOrderEventLine.append(create_time)
                if int(item["id"][0:10]) > self._endStamp:
                    self.orderNum = len(self.orders)
                    break
        del orders_data

    def set_const_orders_deepcopy(self, orders):
        """
        设置订单列表的备份
        :return:
        """
        from copy import deepcopy
        self._constOrders = deepcopy(orders)

    def delta_time_order(self, time_line, delta_time=1, pop_all=True):
        """
        首先判断是否还有订单未分配，若没有则返回False，若有则返回True，且第二个元素为订单列表
        :param pop_all: 是否一次性返回所有delta_time时间内的订单列表
        :param delta_time: 查询接下来多少秒内的新订单
        :param time_line:当前时间
        :return:元组，(BOOL,LIST) 第一个元素为是否尚未分配完毕，第二个元素是delta_time内的订单列表
        """
        _new_orders = []
        if self.orders:
            if pop_all:
                while self.orders:
                    if self.orders[0].createTimePoint <= time_line + delta_time:
                        _new_orders.append(self.orders.pop(0))
                    else:
                        break
            else:
                if self.orders[0].createTimePoint <= time_line + delta_time:
                    _new_orders.append(self.orders.pop(0))
            return True, _new_orders
        else:
            return False, []

    def pop_new_order(self, time_line):
        """
        计算下一订单的delta_time，并pop出新订单
        :return:
        """
        _pop_order = None
        _delta_time = None
        if self.orders:
            _pop_order = self.orders.pop(0)
            _delta_time = _pop_order.createTimePoint - time_line
        return _pop_order, _delta_time

    def check_done(self):
        """
        检测订单是否都已完成
        当最后一个订单已分配，且dismissed和completed订单总和等于所有订单数量时，则本轮结束
        :return:
        """
        if not self.orders and len(self.dismissedOrders) + len(self.completedOrders) == self.orderNum:
            return True
        else:
            return False

    @classmethod
    def time_to_time_stamp(cls, time_str):
        """
        时间字符串转时间戳
        :return: stamp
        """
        import time

        time_array = time.strptime(time_str, "%Y-%m-%d %H:%M:%S")
        time_stamp = int(time.mktime(time_array))
        return time_stamp


class Order:
    """
    Order类，主要功能有：
    ①：根据订单ID、创建时间、商家park、顾客park初始化Order对象
    ②：重置订单对象非固定参数
    构造函数：
    Order(orderid, createtime, shoppark, clientpark)
    接口函数：
    1 ：reset()                      重置非固定参数
    接口变量：
    Order.shopParkIdx                   订单的shopPark的idx
    Order.clientParkIdx                 订单的clientPark的idx
    Order.shopParkOffsetPercent         订单的shopPark的Offset%
    Order.clientParkOffsetPercent       订单的clientPark的Offset%
    Order.shopEdgeIdx                   订单的shopEdge的idx（注意与park区别）
    Order.clientEdgeIdx                 订单的clientEdge的idx（注意与park区别）
    Order.status                        订单的状态（默认None为未分配，此外还有"Dispatched","Accepted","Dismiss","Done"）
    Order.completeTime                  订单结束的时间（时间点）
    Order.last                          订单持续时间
    Order.timeRemain                    订单剩余时间，等于时限减去持续时间
    Order.state                         对应于DQN中的每次调度时的状态（汇总）
    Order.action                        对应于DQN中的每次调度时的动作
    Order.reward                        对应于DQN中的每次调度时的奖励
    """

    def __init__(self, orderid, createtime, shoppark, clientpark, time_limit=30 * 60):
        """

        :param orderid: 订单id
        :param createtime:  订单创建时间
        :param shoppark:    商家park idx
        :param clientpark:  顾客park idx
        :param time_limit:  订单允许时限
        """

        self.id = orderid
        self.createTimePoint = createtime
        self.shopParkIdx = shoppark
        self.clientParkIdx = clientpark
        self.shopParkOffsetPercent = 0
        self.clientParkOffsetPercent = 0
        self.shopEdgeIdx = None
        self.clientEdgeIdx = None
        self.timeLimit = time_limit

        """以下为每episode须重新初始化的参数"""
        self.isNewOrder = None  # 共三种状态：None为未分配，True为该时间隙新分配的订单，False为非该时间隙新分配的订单
        self.dispatchedToCourierID=-1   # 订单已分配给哪个骑手
        self.status = OrderStatusEnum.NOT_DISPATCHED  # 默认为未分配，此外还有"DISPATCHED","COMPLETED"
        self.completeTimePoint = 0  # 订单结束的时间（时间点）
        self.bindingCourierID = -1  # 只有当该订单的shop已被该骑手接收后，才算绑定
        """以上为每episode须重新初始化的参数"""

    def reset(self):
        """
        重置非固定参数
        :return:void
        """
        self.isNewOrder = None
        self.dispatchedToCourierID = -1
        self.status = OrderStatusEnum.NOT_DISPATCHED
        self.completeTimePoint = 0  # 时间点
        self.bindingCourierID = -1

    def complete(self, time_line, time_elapse_in_interval):
        """
        当前订单已完成运送
        :param time_elapse_in_interval: 完成时刻是在当前时间线的时间间隙的第多少秒
        :param time_line: 当前时间
        :return:
        """
        self.status = OrderStatusEnum.COMPLETED
        self.isNewOrder = False
        self.completeTimePoint = time_line + time_elapse_in_interval


if __name__ == '__main__':
    orderTimeBegin = '2016-5-18 10:00:01'
    orderTimeEnd = '2016-5-18 12:59:59'
    orderCenter = OrdersCenter(orderTimeBegin, orderTimeEnd)
    print(orderCenter.orderNum)
    for order in orderCenter.orders:
        print(order.shopParkIdx, " and ", order.createTimePoint)
