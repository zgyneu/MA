import copy
import math
import random
from time import time
from itertools import permutations


# 采用罚函数解决VRP的三种限制
# 采用pickup and delivery纠正算子，加快求解收敛速度
# 采用轮盘赌算法，适应度越高的染色体交叉遗传的概率越大
# 采用(逆序+位移+)2opt算子的变异算法，保持解的多样性，加快跳出局部最优解
# 采用动态调整cross over概率和mutation概率，平衡“保留精英”和跳出局部最优

class MA:
    def __init__(self, seed=123, iter_time=1000, penalty_coefficient=1000, niche_num=1, terminate_by_fitness_equal=True,
                 debug_info=False):
        self._data = {}
        random.seed(seed)

        self._mut_prob = 0.1  # 0.15
        self._cross_over_prob = 0.7  # 0.2
        self._choose_top_percent = 0.00
        self._local_search_prob = 0.2  # 0.4

        self._generation_num = iter_time  # 迭代代数
        self._population_size = 200
        self._nodes_len = -1
        self._terminate_fitness_equal_time = 50
        self._terminate_by_fitness_equal = terminate_by_fitness_equal
        self._fitness_mem_map = {}  # 缓存 路径(.__str__())->适应度
        self._cost_without_penalty_mem_map = {}  # 缓存 路径(.__str__())->路径花费
        self._local_search_map = {}  # 缓存 路径(.__str__())->chromosome (local_search结果)
        self._local_search_save_all_map = {}  # 缓存 路径(.__str__())->所有邻域解的列表 (local_search结果)
        self._penalty_coefficient = penalty_coefficient  # 罚系数, 10W
        self._pickup_delivery_penalty_ratio = 10
        self._time_window_penalty_ratio = 0.5  # 每超时1秒的罚倍率
        self._capacity_penalty_ratio = 5  # 每超限或低限1个的罚倍率
        self._need_correct_pickup_delivery = True

        self.__crossover_equal_count = 0
        self._terminate_fitness_equal_count = 0  # 迭代过程中，最优解相等次数计数器
        self._shift_cross_and_mutation_on = False
        self._dynamic_probability = True  # 动态调整概率

        self._solve_with_few_nodes_threshold = 6
        self._num_of_niches = niche_num  # 小生境数量

        self.__debug_info_print = debug_info

    def change_parameters(self, need_correct_pickup_delivery=True, shift_cross_and_mutation_on=True,
                          dynamic_probability=True, iter_time=1000, niche_num=3):
        """

        :return:
        """
        self._need_correct_pickup_delivery = need_correct_pickup_delivery
        self._shift_cross_and_mutation_on = shift_cross_and_mutation_on
        self._dynamic_probability = dynamic_probability
        self._generation_num = iter_time
        self._num_of_niches = niche_num
        if not self._dynamic_probability:
            self._mut_prob = 0.1
            self._cross_over_prob = 0.7
            self._local_search_prob = 0.2

    def create_data_model(self, graph, pickups_deliveries, time_windows, demands, capacity=3):
        """Stores the data for the problem."""
        self._data['time_matrix'] = graph  # matrix 注意：起对角线元素、第一列元素COST均为0
        self._data['pickups_deliveries'] = pickups_deliveries  # 二维list，内层维度分别为shop和client,形如：[[3, 1], [4, 2],]
        self._data['time_windows'] = time_windows  # list，内层为tuple，分别是0和time_remain
        # 形如：[
        #     (0, 5),  # depot
        #     (0, 10),  # 1
        #     (0, 500),  # 2
        #     (0, 5),  # 3
        #      ]
        self._data['demands'] = demands  # 形如：[1, -1, -1, 1]
        self._data['vehicle_capacities'] = capacity  # 容量限制，形如 3
        self._nodes_len = len(graph[0])

    def gen_init_sol(self):
        """产生初始解"""
        _init_population = []
        _route_without_depot = list(range(1, self._nodes_len))
        for _i in range(self._population_size):
            # seed = int(random.randint(0, self._population_size))

            random.shuffle(_route_without_depot)
            _route_without_depot = self.correct_pickup_and_delivery(_route_without_depot)
            _init_population.append(
                (copy.deepcopy([0] + _route_without_depot), self.cal_fit([0] + _route_without_depot)))
        # self.sol_list.sort(key=lambda x: x[1])
        # print(sorted(self.sol_list, key=lambda x: x[1]))
        return _init_population

    def cal_fit(self, route, cal_cost_without_penalty=False):
        """计算适应度：路径总距离"""
        if cal_cost_without_penalty:
            _cost = self._cost_without_penalty_mem_map.get(route.__str__(), 0)
            if _cost:
                return _cost
            for _idx in range(self._nodes_len - 1):
                if _idx + 1 < self._nodes_len:
                    if route[_idx] == route[_idx + 1]:
                        raise Exception("error", "error")
                    _cost += self._data['time_matrix'][route[_idx]][route[_idx + 1]]
            self._cost_without_penalty_mem_map[route.__str__()] = _cost
            return _cost
        _fitness = self._fitness_mem_map.get(route.__str__(), 0)
        if _fitness:
            # print("_fitness:",_fitness)
            return _fitness
        _cost = 0
        _cap_penalty_count = 0  # 累计超限或低限个数
        _cap_accu = 0
        _time_penalty_count = 0  # 累计超时秒数
        _pickup_delivery_penalty_count = 0
        # _time_accu = 0
        for _idx in range(self._nodes_len - 1):
            if _idx + 1 < self._nodes_len:
                if route[_idx] == route[_idx + 1]:
                    raise Exception("error", "error")
                _cost += self._data['time_matrix'][route[_idx]][route[_idx + 1]]
                if _cost > self._data['time_windows'][route[_idx + 1]][1]:
                    _time_penalty_count += _cost - self._data['time_windows'][route[_idx + 1]][1]
            _cap_accu += self._data['demands'][route[_idx]]
            if _cap_accu < 0:
                _cap_penalty_count += -_cap_accu
            elif _cap_accu > self._data['vehicle_capacities']:
                _cap_penalty_count += _cap_accu - self._data['vehicle_capacities']
        for _first, _second in self._data['pickups_deliveries']:
            _first_idx = route.index(_first)
            _second_idx = route.index(_second)
            if _first_idx > _second_idx:
                _pickup_delivery_penalty_count += 1
        _cost += (_cap_penalty_count * self._capacity_penalty_ratio +
                  _time_penalty_count * self._time_window_penalty_ratio +
                  _pickup_delivery_penalty_count * self._pickup_delivery_penalty_ratio) * self._penalty_coefficient
        _fitness = 1 / _cost
        self._fitness_mem_map[route.__str__()] = _fitness
        return _fitness

    @staticmethod
    def cal_hamming_distance(chrome_1, chrome_2):
        """

        :return:
        """
        _hamming_distance = 0
        for _i in range(1, len(chrome_1[0])):
            if chrome_1[0][_i] == chrome_2[0][_i]:
                _hamming_distance += 1
        return _hamming_distance

    @staticmethod
    def rou_wheel_sel(n, population):
        """
        轮盘赌，选择双亲
        :param n: 轮盘赌旋转次数
        """
        wheel = []  # 轮盘，每两个元素区间为
        choose_parents = []  # 每个元素为二元组，即所选择的双亲，元素总数为n
        total_fitness = 0
        for _sol in population:
            total_fitness += _sol[1]
            wheel.append(total_fitness)
        # print("total_fitness:", total_fitness)
        # print("wheel:", wheel)
        for _i in range(n):
            _parent_one_randint = random.random() * total_fitness
            _parent_two_randint = (_parent_one_randint + total_fitness / 2) % total_fitness  # 每次轮盘赌，同时选择出双亲
            _parent_one_idx = -1
            _parent_two_idx = -1
            if _parent_one_randint <= wheel[0]:
                _parent_one_idx = 0
            if _parent_two_randint <= wheel[0]:
                _parent_two_idx = 0
            for _idx in range(len(wheel) - 1):
                if _parent_one_idx == -1 and wheel[_idx] < _parent_one_randint <= wheel[_idx + 1]:
                    _parent_one_idx = _idx + 1
                if _parent_two_idx == -1 and wheel[_idx] < _parent_two_randint <= wheel[_idx + 1]:
                    _parent_two_idx = _idx + 1
                if _parent_one_idx != -1 and _parent_two_idx != -1:
                    choose_parents.append((_parent_one_idx, _parent_two_idx))
                    break
        return choose_parents

    def mutation_2_opt(self, chromosome):
        """
        2-opt算法，执行变异过程：选取两个不同点，区间元素逆序
        """
        _shift_mutation_prob = 1.0  # 以0.5概率发生循环变异，正向循环
        _reverse_mutation_prob = 0.5
        if not self._shift_cross_and_mutation_on:
            _shift_mutation_prob = 0
            _reverse_mutation_prob = 0
        _mutation_chromosome = copy.deepcopy(chromosome)
        _chromosome_len = len(_mutation_chromosome)
        _reverse_coin = random.random()
        if _reverse_mutation_prob > _reverse_coin:
            _reverse_part = _mutation_chromosome[1:]
            _reverse_part.reverse()
            _mutation_chromosome = [_mutation_chromosome[0]] + _reverse_part
        _shift_coin = random.random()
        if _shift_mutation_prob > _shift_coin:
            _shift_span = random.randint(1, _chromosome_len - 2)
            _left_shift_part = _mutation_chromosome[1:_chromosome_len - _shift_span]
            _right_shift_part = _mutation_chromosome[-_shift_span:]
            _mutation_chromosome = [0] + _right_shift_part + _left_shift_part
            # print(len(_mutation_chromosome))
        _mutation_point_one = random.randint(1, _chromosome_len - 1)
        _mutation_point_two = random.randint(1, _chromosome_len - 1)
        while _mutation_point_two == _mutation_point_one:
            _mutation_point_two = random.randint(1, _chromosome_len - 1)
        if _mutation_point_one > _mutation_point_two:
            _mutation_point_one, _mutation_point_two = _mutation_point_two, _mutation_point_one
        for _i in range((_mutation_point_two - _mutation_point_one + 1) // 2):
            _mutation_chromosome[_mutation_point_one + _i], _mutation_chromosome[_mutation_point_two - _i] = \
                _mutation_chromosome[_mutation_point_two - _i], _mutation_chromosome[_mutation_point_one + _i]
        _mutation_chromosome = self.correct_pickup_and_delivery(_mutation_chromosome)
        return _mutation_chromosome

    def mutation_2_opt_and_cal_fit(self, chromosome):
        """
        变异同时计算适应度
        :param chromosome:
        :return:
        """
        _mutation_chromosome = self.mutation_2_opt(chromosome)
        return _mutation_chromosome, self.cal_fit(_mutation_chromosome)

    def choose_top(self, population, percent):
        """
        选择适应度较好的前percent的population
        :param population: 初始解
        :return:
        """
        # print("population:",population)
        # print("len(population):",len(population))
        # print("len(population[0]):",len(population[0]))
        return sorted(population, reverse=True, key=lambda x: x[1])[
               :int(self._population_size * percent)]

    def segment_into_niches(self, population: list, num_of_niches=1):
        """
        将总体种群按汉明码距分割为 num_of_niches 个小生境
        :param population: 种群
        :param num_of_niches: 小生境数量
        :return: 二维列表，每个元素为一个小生境
        """
        if num_of_niches == 1:
            return [population]
        _niches = []  # 包含 num_of_niches 个子列表
        _population_len = len(population)
        _each_niche_size = int(_population_len / num_of_niches)
        for _ in range(num_of_niches):
            _niches.append([])
        _population_copy = copy.deepcopy(population)
        _population_copy.sort(key=lambda item: item[1], reverse=True)  # 按适应度排序,从大到小
        _niche_centers = [0]  # 适应度最大的个体作为第一个小生境中心，存储序号
        _hamming_distances_summer_dict = {}  # 每个元素为所有个体距前i个小生境中心的汉明距离加和的列表，key:个体的index，value:个体距小生境中心距离加和列表

        _niche_mark = [-1] * _population_len  # 用以标记每个个体加入哪个小生境
        _niche_mark[0] = 0
        for _i in range(num_of_niches - 1):
            # 先找到新的小生境中心
            if _i != 0:
                _max_sum_distance = 0
                _max_sum_distance_chrome_index = 0
                for _j in range(_population_len):
                    if _niche_mark[_j] == -1:
                        if _hamming_distances_summer_dict[_j] > _max_sum_distance:
                            _max_sum_distance = _hamming_distances_summer_dict[_j]
                            _max_sum_distance_chrome_index = _j
                _niche_centers.append(_max_sum_distance_chrome_index)  # 第_i号小生境中心
                _niche_mark[_niche_centers[_i]] = _i
            # 再找到距离该小生境中心最近的(1/k)*population_size个个体，加入该小生境
            _hamming_distances_to_n_niche_center_dict = {}
            for _j in range(_population_len):
                if _niche_mark[_j] == -1:
                    _hamming_distance = self.cal_hamming_distance(_population_copy[_niche_centers[_i]],
                                                                  _population_copy[_j])
                    _hamming_distances_to_n_niche_center_dict[_j] = _hamming_distance
                    if _i == 0:
                        _hamming_distances_summer_dict[_j] = _hamming_distance
                    else:
                        _hamming_distances_summer_dict[_j] += _hamming_distance

            _hamming_distances_to_n_niche_center_list = sorted(_hamming_distances_to_n_niche_center_dict.items(),
                                                               key=lambda item: item[1])
            _niche_counter = _each_niche_size
            for _j, _ in _hamming_distances_to_n_niche_center_list:
                if _niche_mark[_j] == -1:
                    _niche_mark[_j] = _i
                    _niche_counter -= 1
                    if _niche_counter <= 0:
                        break
        for _j in range(_population_len):
            _niches[_niche_mark[_j]].append(_population_copy[_j])
        return _niches

    def cross_over(self, parents, population):
        """
        对选中的parents进行交叉，两点交叉，算子：order Crossover(OX)
        :param population: 种群（小生境）
        :param parents: 二元组，组成二元组的每个元素为self.chromosome的下标号
        :return:
        """

        _parent_chromosome_one = population[parents[0]][0]
        _parent_chromosome_two = population[parents[1]][0]
        _parent_chromosome_one_copy = copy.deepcopy(_parent_chromosome_one)
        _parent_chromosome_two_copy = copy.deepcopy(_parent_chromosome_two)
        _chromosome_len = len(_parent_chromosome_one)
        if _parent_chromosome_one == _parent_chromosome_two:
            return _parent_chromosome_one, _parent_chromosome_two
            # if not self._shift_cross_and_mutation_on:
            #     return _parent_chromosome_one, _parent_chromosome_two
            # _shift_coin = random.random()
            # if self._shift_cross_prob > _shift_coin:
            #     _shift_one_span = random.randint(1, _chromosome_len - 2)
            #     _shift_two_span = random.randint(1, _chromosome_len - 2)
            #     while _shift_two_span != _shift_one_span:
            #         _shift_two_span = random.randint(1, _chromosome_len - 2)
            #     _shift_one_left = _parent_chromosome_one_copy[1:_chromosome_len - _shift_one_span]
            #     _shift_one_right = _parent_chromosome_one_copy[-_shift_one_span:]
            #     _parent_chromosome_one_copy = [0] + _shift_one_right + _shift_one_left
            #     _shift_two_left = _parent_chromosome_two_copy[1:_chromosome_len - _shift_two_span]
            #     _shift_two_right = _parent_chromosome_two_copy[-_shift_two_span:]
            #     _parent_chromosome_two_copy = [0] + _shift_two_right + _shift_two_left
        if _parent_chromosome_one_copy == _parent_chromosome_two:
            self.__crossover_equal_count += 1
        _cross_point_one = random.randint(1, _chromosome_len)  # 包含
        _cross_point_two = random.randint(1, _chromosome_len)  # 包含
        if _cross_point_one > _cross_point_two:
            _cross_point_one, _cross_point_two = _cross_point_two, _cross_point_one
        if _cross_point_two - _cross_point_one == _chromosome_len - 1:
            _cross_point_one += random.randint(0, _chromosome_len // 2)
            _cross_point_two -= random.randint(0, _chromosome_len // 2)
            if _cross_point_one > _cross_point_two:
                _cross_point_one, _cross_point_two = _cross_point_two, _cross_point_one
        _cross_part_one = _parent_chromosome_one_copy[_cross_point_one:_cross_point_two + 1]
        _cross_part_two = _parent_chromosome_two_copy[_cross_point_one:_cross_point_two + 1]
        _vacant_pos_flags_one = []
        _vacant_pos_flags_two = []
        _child_chromosome_one = [0] * _cross_point_one + _cross_part_one + [0] * (
                _chromosome_len - _cross_point_two - 1)
        _child_chromosome_two = [0] * _cross_point_one + _cross_part_two + [0] * (
                _chromosome_len - _cross_point_two - 1)
        for _idx, _gene in enumerate(_child_chromosome_one):
            if _idx == 0:
                continue
            if _gene == 0:
                _vacant_pos_flags_one.append(_idx)
                _vacant_pos_flags_two.append(_idx)
        _cross_len = len(_cross_part_one)
        for _idx, _gene in enumerate(_parent_chromosome_two_copy):
            if _gene == 0:
                continue
            if _gene not in _cross_part_one:
                _child_chromosome_one[_vacant_pos_flags_one[0]] = _gene
                _vacant_pos_flags_one.pop(0)
        for _idx, _gene in enumerate(_parent_chromosome_one_copy):
            if _gene == 0:
                continue
            if _gene not in _cross_part_two:
                _child_chromosome_two[_vacant_pos_flags_two[0]] = _gene
                _vacant_pos_flags_two.pop(0)
        # print("_child_chromosome_one:", _child_chromosome_one, "_child_chromosome_two:", _child_chromosome_two)
        _child_chromosome_one = self.correct_pickup_and_delivery(_child_chromosome_one)
        _child_chromosome_two = self.correct_pickup_and_delivery(_child_chromosome_two)
        return _child_chromosome_one, _child_chromosome_two

    def __total_diff_chromosome(self, population):
        if self.__debug_info_print:
            _container = []
            for _chromosome in population:
                # print(_chromosome[0].__str__())
                _container.append(_chromosome[0].__str__())
            _container = set(_container)
            print("how many diff:", len(_container))
        else:
            return

    def cross_over_and_cal_fit(self, parents, population):
        """
        交叉并计算适应度
        :param population:
        :param parents:
        :return:
        """
        _child_chromosome_one, _child_chromosome_two = self.cross_over(parents, population)
        return (_child_chromosome_one, self.cal_fit(_child_chromosome_one)), \
               (_child_chromosome_two, self.cal_fit(_child_chromosome_two))

    def local_search(self, chromosome, init_fitness):
        """
        局部搜索算法
        :param chromosome:
        :param init_fitness:
        :return:
        """
        _best_fitness = init_fitness
        _best_chromosome = chromosome
        _chromosome_len = len(chromosome)
        for _i in range(1, _chromosome_len - 1):
            for _j in range(_i + 1, _chromosome_len):
                _chromosome_switched = copy.deepcopy(chromosome)
                _chromosome_switched[_i], _chromosome_switched[_j] = _chromosome_switched[_j], _chromosome_switched[_i]
                _chromosome_switched = self.correct_pickup_and_delivery(_chromosome_switched)
                _fitness = self.cal_fit(_chromosome_switched)
                if _fitness > _best_fitness:
                    _best_fitness = _fitness
                    _best_chromosome = _chromosome_switched
        return _best_chromosome, _best_fitness

    def local_search_save_all(self, chromosome, sort=True):
        """
        局部搜索算法，返回所有邻域解
        :param chromosome:
        :return:
        """
        _neighbor_solutions = []
        _chromosome_len = len(chromosome)
        for _i in range(1, _chromosome_len - 1):
            for _j in range(_i + 1, _chromosome_len):
                _chromosome_switched = copy.deepcopy(chromosome)
                _chromosome_switched[_i], _chromosome_switched[_j] = _chromosome_switched[_j], _chromosome_switched[_i]
                _fitness = self.cal_fit(_chromosome_switched)
                _neighbor_solutions.append((_chromosome_switched, _fitness))
        if sort:
            _neighbor_solutions = sorted(_neighbor_solutions, key=lambda item: item[1])
        return _neighbor_solutions

    def correct_pickup_and_delivery(self, chromosome: list):
        """
        纠正chromosome的先取后送错误
        :return:
        """
        if self._need_correct_pickup_delivery:
            for _first, _second in self._data['pickups_deliveries']:
                _first_idx = chromosome.index(_first)
                _second_idx = chromosome.index(_second)
                if _first_idx > _second_idx:
                    # print("ori chromosome:", chromosome)
                    chromosome[_second_idx], chromosome[_first_idx] = chromosome[_first_idx], chromosome[_second_idx]
                    # print("aft chromosome:", chromosome)
        return chromosome

    def check_feasible(self, route):
        """

        :param route:
        :return:
        """
        _cost = 0
        _cap_accu = 0
        for _idx in range(len(route) - 1):
            if _idx + 1 < self._nodes_len:
                if route[_idx] == route[_idx + 1]:
                    raise Exception("error", "error")
                _cost += self._data['time_matrix'][route[_idx]][route[_idx + 1]]
                if _cost > self._data['time_windows'][route[_idx + 1]][1]:
                    return False
            _cap_accu += self._data['demands'][route[_idx]]
            if _cap_accu < 0:
                return False
            elif _cap_accu > self._data['vehicle_capacities']:
                return False
        for _first, _second in self._data['pickups_deliveries']:
            _first_idx = route.index(_first)
            _second_idx = route.index(_second)
            if _first_idx > _second_idx:
                return False
        return True

    def solve_with_few_nodes(self):
        """

        :param threshold_node_num: 当节点数少于threshold时，使用穷举算法求解
        :return:
        """

        _all_routes_without_depot = permutations(list(range(1, len(self._data['demands']))))
        _all_solutions = []
        for _route_without_depot in _all_routes_without_depot:
            _route = [0] + list(_route_without_depot)
            _all_solutions.append((_route, self.cal_fit(_route, True)))
        _all_solutions.sort(key=lambda x: x[1])
        for _solution in _all_solutions:
            if self.check_feasible(_solution[0]):
                return _solution[0], _solution[1]
        return False, False

    def solve_tsp(self, graph, pickups_deliveries, time_windows, demands, capacity=3, return_iter_cost=False):
        """

        :return:
        """
        # TODO: 加入输入上一轮解，以此通过启发式方法，将新订单的两个节点插入上一轮的解中，生成初始解
        iter_record = []  # 用于存储每轮迭代后的best_solution的cost
        iter_without_penalty_record = [] # 用于存储每轮迭代后的best_solution的cost（忽略penalty）
        self.create_data_model(graph, pickups_deliveries, time_windows, demands)
        if self._nodes_len <= self._solve_with_few_nodes_threshold:
            return self.solve_with_few_nodes()

        _iter_population = self.gen_init_sol()

        _best_solution = [[], -float('inf')]
        self._terminate_fitness_equal_count = 0
        for _ in range(self._generation_num):
            _iter_population, _solution = self.iteration(_iter_population)
            # print("len(_iter_population):",len(_iter_population))
            # print("_iter_population:",_iter_population)

            if _solution[1] > _best_solution[1]:
                _best_solution = _solution
                self._terminate_fitness_equal_count = 0
            else:
                self._terminate_fitness_equal_count += 1
                if self._terminate_by_fitness_equal and \
                        self._terminate_fitness_equal_count >= self._terminate_fitness_equal_time:
                    break
            if self.__debug_info_print:
                print("_best_solution:", _best_solution[0], int(1 / _best_solution[1]),
                      "\t_current_solution:", _solution[0], int(1 / _solution[1]))
            if return_iter_cost:
                iter_record.append(int(1 / _best_solution[1]))
                iter_without_penalty_record.append(self.cal_fit(_best_solution[0],True))
        if self.__debug_info_print:
            print("result:", _best_solution[0], int(1 / _best_solution[1]))
        # print("init population:", sorted(_init_population, key=lambda x: x[1]), "\n size:", len(_init_population))

        # print("population:", _one_iter_solutions, "\n size:", len(_one_iter_solutions))

        if return_iter_cost:
            self.clean_cache()
            return _best_solution[0], int(1 / _best_solution[1]), iter_record,iter_without_penalty_record
        if self.check_feasible(_best_solution[0]):
            self.clean_cache()
            return _best_solution[0], int(1 / _best_solution[1])
        else:
            self.clean_cache()
            return False

    def iteration(self, population):
        """
        迭代
        :param population:
        :return:
        """
        _one_iter_solutions = []
        _one_iter_solutions += self.choose_top(population, self._choose_top_percent)
        random.shuffle(_one_iter_solutions)
        # random.seed()
        _niches = self.segment_into_niches(population, self._num_of_niches)

        self.__crossover_equal_count = 0
        if self._dynamic_probability:
            _prob_variation = min(
                self._cross_over_prob - 0.1,
                math.sin(
                    min(self._terminate_fitness_equal_count / self._terminate_fitness_equal_time,
                        1) / 2 * math.pi) * self._cross_over_prob
            )
        else:
            _prob_variation = 0
        _cross_over_prob = self._cross_over_prob - _prob_variation
        _mut_prob = self._mut_prob + _prob_variation
        __total = 0
        for _niche in _niches:
            for _parents in self.rou_wheel_sel(int(len(_niche) * _cross_over_prob // 2), _niche):
                _one_iter_solutions += self.cross_over_and_cal_fit(_parents, _niche)
                __total += 1
        # print("self.__crossover_equal_count:", self.__crossover_equal_count, "/", __total)
        _one_iter_solutions_len = len(_one_iter_solutions)
        _mut_solutions = []
        for _ in range(int(self._population_size * _mut_prob)):
            _choose_mutation = random.randint(0, _one_iter_solutions_len - 1)
            _mut_solutions.append(self.mutation_2_opt_and_cal_fit(_one_iter_solutions[_choose_mutation][0]))
        _one_iter_solutions += _mut_solutions
        _one_iter_solutions_len = len(_one_iter_solutions)
        # print(_one_iter_solutions_len)

        # if self._local_search_prob == 0.5:
        #     for _chromosome in _one_iter_solutions[:_one_iter_solutions_len]:
        #         _local_search_result = self._local_search_map.get(_chromosome[0].__str__(), 0)
        #         if _local_search_result:
        #             _one_iter_solutions.append(_local_search_result)
        #         else:
        #             _local_search_result = self.local_search(_chromosome[0], _chromosome[1])
        #             self._local_search_map[_chromosome[0].__str__()] = _local_search_result
        #             _one_iter_solutions.append(self.local_search(_local_search_result[0], _local_search_result[1]))
        # else:
        #     for _ in range(self._population_size - _one_iter_solutions_len):
        #         _choose_local_search = random.randint(0, _one_iter_solutions_len - 1)
        #         _chromosome = _one_iter_solutions[_choose_local_search]
        #         _local_search_result = self._local_search_map.get(_chromosome[0].__str__(), 0)
        #         if _local_search_result:
        #             _one_iter_solutions.append(_local_search_result)
        #         else:
        #             _local_search_result = self.local_search(_chromosome[0], _chromosome[1])
        #             self._local_search_map[_chromosome[0].__str__()] = _local_search_result
        #             _one_iter_solutions.append(self.local_search(_local_search_result[0], _local_search_result[1]))
        _best_solution_till_now = _one_iter_solutions[0]
        for _solution in _one_iter_solutions:
            if _solution[1] > _best_solution_till_now[1]:
                _best_solution_till_now = _solution
        _local_search_result = self._local_search_map.get(_best_solution_till_now[0].__str__(), 0)
        if not _local_search_result:
            _local_search_result = self.local_search_save_all(_best_solution_till_now[0], True)
            self._local_search_map[_best_solution_till_now[0].__str__()] = _local_search_result
        _one_iter_solutions += _local_search_result[:self._population_size - _one_iter_solutions_len]

        _best_solution = ([], -float('inf'))
        self.__total_diff_chromosome(_one_iter_solutions)
        for _sol in _one_iter_solutions:
            if _sol[1] > _best_solution[1]:
                _best_solution = _sol
        # print(_best_solution[0], int(1 / _best_solution[1]), "cost:", self.cal_fit(_best_solution[0], True))
        return _one_iter_solutions, _best_solution

    def clean_cache(self):
        """
        求解结束后，清空运算缓存
        :return:
        """
        self._fitness_mem_map = {}
        self._cost_without_penalty_mem_map = {}
        self._local_search_map = {}
        self._local_search_save_all_map = {}
        self._data = {}


if __name__ == '__main__':
    m_graph = [
        [0, 6, 9, 8, 7, 3, 6, 2, 3, 2, 6, 6, 4, 4, 5, 9, 7, 8, 4, 6, 2],
        [0, 0, 8, 3, 2, 6, 8, 4, 8, 8, 13, 7, 5, 8, 12, 10, 14, 2, 5, 7, 8],
        [0, 8, 0, 11, 10, 6, 3, 9, 5, 8, 4, 15, 14, 13, 9, 18, 9, 3, 6, 9, 2],
        [0, 3, 11, 0, 1, 7, 10, 6, 10, 10, 14, 6, 7, 9, 14, 6, 16, 4, 5, 9, 1],
        [0, 2, 10, 1, 0, 6, 9, 4, 8, 9, 13, 4, 6, 8, 12, 8, 14, 3, 9, 1, 8],
        [0, 6, 6, 7, 6, 0, 2, 3, 2, 2, 7, 9, 7, 7, 6, 12, 8, 2, 4, 3, 5],
        [0, 8, 3, 10, 9, 2, 0, 6, 2, 5, 4, 12, 10, 10, 6, 15, 5, 9, 2, 8, 1],
        [0, 4, 9, 6, 4, 3, 6, 0, 4, 4, 8, 5, 4, 3, 7, 8, 10, 1, 2, 7, 6],
        [0, 8, 5, 10, 8, 2, 2, 4, 0, 3, 4, 9, 8, 7, 3, 13, 6, 1, 4, 4, 5],
        [0, 8, 8, 10, 9, 2, 5, 4, 3, 0, 4, 6, 5, 4, 3, 9, 5, 2, 2, 2, 3],
        [0, 13, 4, 14, 13, 7, 4, 8, 4, 4, 0, 10, 9, 8, 4, 13, 4, 4, 3, 2, 1],
        [0, 7, 15, 6, 4, 9, 12, 5, 9, 6, 10, 0, 1, 3, 7, 3, 10, 11, 9, 3, 4],
        [0, 5, 14, 7, 6, 7, 10, 4, 8, 5, 9, 1, 0, 2, 6, 4, 8, 4, 3, 6, 8],
        [0, 8, 13, 9, 8, 7, 10, 3, 7, 4, 8, 3, 2, 0, 4, 5, 6, 5, 6, 8, 7],
        [0, 12, 9, 14, 12, 6, 6, 7, 3, 3, 4, 7, 6, 4, 0, 9, 2, 1, 4, 4, 10],
        [0, 10, 18, 6, 8, 12, 15, 8, 13, 9, 13, 3, 4, 5, 9, 0, 9, 3, 3, 7, 6],
        [0, 14, 9, 16, 14, 8, 5, 10, 6, 5, 4, 10, 8, 6, 2, 9, 0, 4, 4, 3, 3],
        [0, 7, 6, 5, 4, 3, 4, 5, 6, 7, 8, 9, 5, 4, 3, 2, 3, 0, 1, 5, 6],
        [0, 3, 5, 9, 8, 6, 4, 8, 5, 2, 3, 6, 9, 7, 4, 1, 3, 5, 0, 5, 6],
        [0, 1, 4, 7, 8, 2, 5, 6, 3, 9, 9, 5, 1, 4, 3, 2, 3, 2, 8, 0, 6],
        [0, 7, 1, 7, 6, 3, 4, 9, 9, 5, 1, 3, 5, 7, 6, 5, 4, 5, 1, 9, 0],
    ]

    m_pickups_deliveries = [
        [1, 6],
        [2, 10],
        [4, 3],
        [5, 9],
        [7, 8],
        [15, 11],
        [13, 12],
        [16, 14],
        [17, 18],
        [19, 20],
    ]
    m_time_windows = [
        (0, 5),  # depot
        (0, 62),  # 1
        (0, 65),  # 2
        (0, 68),  # 3
        (0, 63),  # 4
        (0, 65),  # 5
        (0, 60),  # 6
        (0, 64),  # 7
        (0, 60),  # 8
        (0, 63),  # 9
        (0, 46),  # 10
        (0, 65),  # 11
        (0, 65),  # 12
        (0, 60),  # 13
        (0, 68),  # 14
        (0, 65),  # 15
        (0, 66),  # 16
        (0, 66),  # 17
        (0, 66),  # 18
        (0, 66),  # 19
        (0, 66),  # 20
    ]
    m_demands = [1, 1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, 1, -1, 1, -1]
    time1 = time()
    MA = MA(terminate_by_fitness_equal=False, niche_num=1, debug_info=True)
    MA.change_parameters(False, False, False)
    # GA.create_data_model(graph, pickups_deliveries, time_windows, demands)
    # GA.gen_init_sol()
    # # for i in GA.sol_list:
    # #     print(i)
    # parents = GA.rou_wheel_sel(50)
    # for p in parents:
    #     print("cross_over:", GA.cross_over(p))
    MA.solve_tsp(m_graph, m_pickups_deliveries, m_time_windows, m_demands)
    print("time:", time() - time1)
