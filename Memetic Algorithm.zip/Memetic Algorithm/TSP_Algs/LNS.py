import copy
import random
from time import time
from itertools import permutations


class LNS:
    def __init__(self,seed=123,iter_time=1000, penalty_coefficient = 1000,terminate_by_fitness_equal=True,debug_info=False):
        self._data = {}
        random.seed(seed)
        self._nodes_len = -1
        self._iteration_num = iter_time  # 迭代次数
        self._terminate_cost_equal_time = 50
        self._terminate_by_cost_equal = terminate_by_fitness_equal
        self._cost_mem_map = {}  # 缓存 路径(.__str__())->cost
        self._cost_without_penalty_mem_map = {}  # 缓存 路径(.__str__())->纯路径花费
        self._penalty_coefficient = penalty_coefficient  # 罚系数, 10W
        self._pickup_delivery_penalty_ratio = 10
        self._time_window_penalty_ratio = 0.5  # 每超时1秒的罚倍率
        self._capacity_penalty_ratio = 5  # 每超限或低限1个的罚倍率
        self._need_correct_pickup_delivery = True

        self.__debug_info_print = debug_info

    def create_data_model(self, graph, pickups_deliveries, time_windows, demands, capacity=3):
        """Stores the data for the problem."""
        self._data['time_matrix'] = graph  # matrix 注意：起对角线元素、第一列元素COST均为0
        self._data['pickups_deliveries'] = pickups_deliveries  # 二维list，内层维度分别为shop和client,形如：[[3, 1], [4, 2],]
        self._data['time_windows'] = time_windows  # list，内层为tuple，分别是0和time_remain
        # 形如：[
        #     (0, 5),  # depot
        #     (0, 10),  # 1
        #     (0, 500),  # 2
        #     (0, 5),  # 3
        #      ]
        self._data['demands'] = demands  # 形如：[1, -1, -1, 1]
        self._data['vehicle_capacities'] = capacity  # 容量限制，形如 3
        self._nodes_len = len(graph[0])

    def gen_init_sol(self):
        """产生初始解, greedy"""
        _init_sols_size = self._nodes_len ** 2
        _init_sols = []
        _route_without_depot = list(range(1, self._nodes_len))
        for _i in range(_init_sols_size):
            random.shuffle(_route_without_depot)
            _init_sols.append(
                (copy.deepcopy([0] + _route_without_depot), self.cal_cost([0] + _route_without_depot)))

        _init_sols = sorted(_init_sols, key=lambda x: x[1])
        return _init_sols[0]

    def cal_cost(self, route, cal_cost_without_penalty=False):
        """计算路径花费：路径总距离"""
        if cal_cost_without_penalty:
            _cost = self._cost_without_penalty_mem_map.get(route.__str__(), 0)
            if _cost:
                return _cost
            for _idx in range(self._nodes_len - 1):
                if _idx + 1 < self._nodes_len:
                    if route[_idx] == route[_idx + 1]:
                        raise Exception("error", "error")
                    _cost += self._data['time_matrix'][route[_idx]][route[_idx + 1]]
            self._cost_without_penalty_mem_map[route.__str__()] = _cost
            return _cost
        _cost = self._cost_mem_map.get(route.__str__(), 0)
        if _cost:
            # print("_fitness:",_fitness)
            return _cost
        _cap_penalty_count = 0  # 累计超限或低限个数
        _cap_accu = 0
        _time_penalty_count = 0  # 累计超时秒数
        _pickup_delivery_penalty_count = 0
        # _time_accu = 0
        for _idx in range(self._nodes_len - 1):
            if _idx + 1 < self._nodes_len:
                if route[_idx] == route[_idx + 1]:
                    raise Exception("error", "error")
                _cost += self._data['time_matrix'][route[_idx]][route[_idx + 1]]
                if _cost > self._data['time_windows'][route[_idx + 1]][1]:
                    _time_penalty_count += _cost - self._data['time_windows'][route[_idx + 1]][1]
            _cap_accu += self._data['demands'][route[_idx]]
            if _cap_accu < 0:
                _cap_penalty_count += -_cap_accu
            elif _cap_accu > self._data['vehicle_capacities']:
                _cap_penalty_count += _cap_accu - self._data['vehicle_capacities']
        for _first, _second in self._data['pickups_deliveries']:
            _first_idx = route.index(_first)
            _second_idx = route.index(_second)
            if _first_idx > _second_idx:
                _pickup_delivery_penalty_count += 1
        _cost += (_cap_penalty_count * self._capacity_penalty_ratio +
                  _time_penalty_count * self._time_window_penalty_ratio +
                  _pickup_delivery_penalty_count * self._pickup_delivery_penalty_ratio) * self._penalty_coefficient
        self._cost_mem_map[route.__str__()] = _cost
        return _cost

    def correct_pickup_and_delivery(self, route: list):
        """
        纠正chromosome的先取后送错误
        :return:
        """
        if self._need_correct_pickup_delivery:
            for _first, _second in self._data['pickups_deliveries']:
                _first_idx = route.index(_first)
                _second_idx = route.index(_second)
                if _first_idx > _second_idx:
                    # print("ori chromosome:", chromosome)
                    route[_second_idx], route[_first_idx] = route[_first_idx], route[_second_idx]
                    # print("aft chromosome:", chromosome)
        return route

    def destroy(self, route, positions: list):
        """
        敲掉给定位置的节点，返回位置和对应的节点列表
        :param positions:
        :return:
        """
        destroyed_nodes = []
        for _pos in positions:
            destroyed_nodes.append(route[_pos])
        return positions, destroyed_nodes

    def repair(self, route, positions: list, destroyed_nodes: list):
        """

        :param route:
        :param positions:
        :param destroyed_nodes:
        :return:
        """
        _repair_list = list(permutations(destroyed_nodes))
        _neighbor_solutions = []
        for _repair in _repair_list:
            _repair_route = copy.deepcopy(route)
            for _i, _pos in enumerate(positions):
                _repair_route[_pos] = _repair[_i]
            _repair_route = self.correct_pickup_and_delivery(_repair_route)
            _neighbor_solutions.append((_repair_route, self.cal_cost(_repair_route, False)))
        return _neighbor_solutions

    def destroy_pos_generator(self, route_len):
        """

        :param route_len:
        :return:
        """
        _destroy_node_num = random.randint(2, min(6, route_len - 1))
        _nodes = list(range(route_len))[1:]
        random.shuffle(_nodes)
        return _nodes[:_destroy_node_num]

    def solve_tsp(self, graph, pickups_deliveries, time_windows, demands, capacity=3,return_iter_cost=False):
        """

        :return:
        """
        iter_record = []  # 用于存储每轮迭代后的best_solution的cost
        iter_without_penalty_record = []  # 用于存储每轮迭代后的best_solution的cost（忽略penalty）
        self.create_data_model(graph, pickups_deliveries, time_windows, demands)
        _best_solution = self.gen_init_sol()
        _current_solution = copy.deepcopy(_best_solution)
        if self.__debug_info_print:
            print("_best_sol:", _best_solution)
        _terminal_cost_equal_count = 0
        for _ in range(self._iteration_num):
            _destroy_positions = self.destroy_pos_generator(len(_current_solution[0]))
            _destroy_positions, destroyed_nodes = self.destroy(_current_solution[0], _destroy_positions)
            _neighbor_sols = self.repair(_current_solution[0], _destroy_positions, destroyed_nodes)
            _neighbor_sols = sorted(_neighbor_sols, key=lambda x: x[1])
            # print("_neighbor_sols:",_neighbor_sols)
            if _neighbor_sols[0][0] == _best_solution[0]:
                _current_solution = copy.deepcopy(_neighbor_sols[1])
            if _neighbor_sols[0][1] < _best_solution[1]:
                _best_solution = _neighbor_sols[0]
                _current_solution = copy.deepcopy(_best_solution)
            if self.__debug_info_print:
                print("_best_solution:", _best_solution, "\t_current_solution:", _current_solution)
            if return_iter_cost:
                iter_record.append( _best_solution[1])
                iter_without_penalty_record.append(self.cal_cost(_best_solution[0], True))
        if self.__debug_info_print:
            print("result:", _best_solution)

        self.clean_cache()
        if return_iter_cost:
            return _best_solution[0], _best_solution[1],iter_record,iter_without_penalty_record
        return _best_solution[0], _best_solution[1]

    def clean_cache(self):
        """
        求解结束后，清空运算缓存
        :return:
        """
        self._cost_without_penalty_mem_map = {}
        self._cost_mem_map = {}


if __name__ == '__main__':
    graph = [
        [0, 6, 9, 8, 7, 3, 6, 2, 3, 2, 6, 6, 4, 4, 5, 9, 7, 8, 4, 6, 2],
        [0, 0, 8, 3, 2, 6, 8, 4, 8, 8, 13, 7, 5, 8, 12, 10, 14, 2, 5, 7, 8],
        [0, 8, 0, 11, 10, 6, 3, 9, 5, 8, 4, 15, 14, 13, 9, 18, 9, 3, 6, 9, 2],
        [0, 3, 11, 0, 1, 7, 10, 6, 10, 10, 14, 6, 7, 9, 14, 6, 16, 4, 5, 9, 1],
        [0, 2, 10, 1, 0, 6, 9, 4, 8, 9, 13, 4, 6, 8, 12, 8, 14, 3, 9, 1, 8],
        [0, 6, 6, 7, 6, 0, 2, 3, 2, 2, 7, 9, 7, 7, 6, 12, 8, 2, 4, 3, 5],
        [0, 8, 3, 10, 9, 2, 0, 6, 2, 5, 4, 12, 10, 10, 6, 15, 5, 9, 2, 8, 1],
        [0, 4, 9, 6, 4, 3, 6, 0, 4, 4, 8, 5, 4, 3, 7, 8, 10, 1, 2, 7, 6],
        [0, 8, 5, 10, 8, 2, 2, 4, 0, 3, 4, 9, 8, 7, 3, 13, 6, 1, 4, 4, 5],
        [0, 8, 8, 10, 9, 2, 5, 4, 3, 0, 4, 6, 5, 4, 3, 9, 5, 2, 2, 2, 3],
        [0, 13, 4, 14, 13, 7, 4, 8, 4, 4, 0, 10, 9, 8, 4, 13, 4, 4, 3, 2, 1],
        [0, 7, 15, 6, 4, 9, 12, 5, 9, 6, 10, 0, 1, 3, 7, 3, 10, 11, 9, 3, 4],
        [0, 5, 14, 7, 6, 7, 10, 4, 8, 5, 9, 1, 0, 2, 6, 4, 8, 4, 3, 6, 8],
        [0, 8, 13, 9, 8, 7, 10, 3, 7, 4, 8, 3, 2, 0, 4, 5, 6, 5, 6, 8, 7],
        [0, 12, 9, 14, 12, 6, 6, 7, 3, 3, 4, 7, 6, 4, 0, 9, 2, 1, 4, 4, 10],
        [0, 10, 18, 6, 8, 12, 15, 8, 13, 9, 13, 3, 4, 5, 9, 0, 9, 3, 3, 7, 6],
        [0, 14, 9, 16, 14, 8, 5, 10, 6, 5, 4, 10, 8, 6, 2, 9, 0, 4, 4, 3, 3],
        [0, 7, 6, 5, 4, 3, 4, 5, 6, 7, 8, 9, 5, 4, 3, 2, 3, 0, 1, 5, 6],
        [0, 3, 5, 9, 8, 6, 4, 8, 5, 2, 3, 6, 9, 7, 4, 1, 3, 5, 0, 5, 6],
        [0, 1, 4, 7, 8, 2, 5, 6, 3, 9, 9, 5, 1, 4, 3, 2, 3, 2, 8, 0, 6],
        [0, 7, 1, 7, 6, 3, 4, 9, 9, 5, 1, 3, 5, 7, 6, 5, 4, 5, 1, 9, 0],
    ]

    pickups_deliveries = [
        [1, 6],
        [2, 10],
        [4, 3],
        [5, 9],
        [7, 8],
        [15, 11],
        [13, 12],
        [16, 14],
        [17, 18],
        [19, 20],
    ]
    time_windows = [
        (0, 5),  # depot
        (0, 62),  # 1
        (0, 65),  # 2
        (0, 68),  # 3
        (0, 63),  # 4
        (0, 65),  # 5
        (0, 60),  # 6
        (0, 64),  # 7
        (0, 60),  # 8
        (0, 63),  # 9
        (0, 46),  # 10
        (0, 65),  # 11
        (0, 65),  # 12
        (0, 60),  # 13
        (0, 68),  # 14
        (0, 65),  # 15
        (0, 66),  # 16
        (0, 66),  # 17
        (0, 66),  # 18
        (0, 66),  # 19
        (0, 66),  # 20
    ]
    demands = [1, 1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, 1, -1, 1, -1]
    time1 = time()
    LNS = LNS()
    # GA.create_data_model(graph, pickups_deliveries, time_windows, demands)
    # GA.gen_init_sol()
    # # for i in GA.sol_list:
    # #     print(i)
    # parents = GA.rou_wheel_sel(50)
    # for p in parents:
    #     print("cross_over:", GA.cross_over(p))
    LNS.solve_tsp(graph, pickups_deliveries, time_windows, demands)
    print("time:", time() - time1)
