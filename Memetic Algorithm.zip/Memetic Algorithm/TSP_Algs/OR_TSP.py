class TSP:
    """
    TSP类
    主要功能：包装谷歌ortools.constraint_solver提供的TSP求解算法
    构造函数TSP()
    详细教学链接：https://developers.google.com/optimization/routing/tsp （需梯子）
    提供的接口：
    solve_tsp()                     给定graph, pickups_deliveries, time_windows, demands, capacity参数，返回route和cost
    """

    def __init__(self):
        self._data = {'num_vehicles': 1, 'depot': 0}

    def _create_data_model(self, graph, pickups_deliveries, time_windows, demands, capacity=3):
        """Stores the data for the problem."""
        self._data['time_matrix'] = graph  # matrix 注意：起对角线元素、第一列元素COST均为0
        self._data['pickups_deliveries'] = pickups_deliveries  # 二维list，内层维度分别为shop和client,形如：[[3, 1], [4, 2],]
        self._data['time_windows'] = time_windows  # list，内层为tuple，分别是0和time_remain
        # 形如：[
        #     (0, 5),  # depot
        #     (0, 10),  # 1
        #     (0, 500),  # 2
        #     (0, 5),  # 3
        #      ]
        self._data['demands'] = demands  # 形如：[1, -1, -1, 1]
        self._data['vehicle_capacities'] = capacity  # 容量限制，形如 3

    def _get_routes_and_cost(self, solution, routing, manager):
        """Get vehicle routes from a solution and store them in an array."""
        # Get vehicle routes and store them in a two dimensional array whose
        # i,j entry is the jth location visited by vehicle i along its route.
        cost = 0
        route = []
        for route_nbr in range(routing.vehicles()):
            index = routing.Start(route_nbr)
            route = [manager.IndexToNode(index)]
            while not routing.IsEnd(index):
                pre_index = index
                index = solution.Value(routing.NextVar(index))
                cost += routing.GetArcCostForVehicle(pre_index, index, 0)
                route.append(manager.IndexToNode(index))
            route.pop(0)
            route.pop(-1)
        return route, cost

    def solve_tsp(self, graph, pickups_deliveries, time_windows, demands, capacity=3):
        """
        主要接口，给定各节点参数，返回route和cost，未能求解返回None
        :param graph:
        :param pickups_deliveries:
        :param time_windows:
        :param demands:
        :param capacity:
        :return:
        """
        from ortools.constraint_solver import routing_enums_pb2
        from ortools.constraint_solver import pywrapcp

        # Instantiate the data problem.
        self._create_data_model(graph, pickups_deliveries, time_windows, demands, capacity)

        # Create the routing index manager.
        manager = pywrapcp.RoutingIndexManager(len(self._data['time_matrix']),
                                               self._data['num_vehicles'], self._data['depot'])

        # Create Routing Model.
        routing = pywrapcp.RoutingModel(manager)

        # Create and register a transit callback.
        def time_callback(from_index, to_index):
            """Returns the travel time between the two nodes."""
            # Convert from routing variable Index to time matrix NodeIndex.
            from_node = manager.IndexToNode(from_index)
            to_node = manager.IndexToNode(to_index)
            return self._data['time_matrix'][from_node][to_node]

        transit_callback_index = routing.RegisterTransitCallback(time_callback)

        # Define cost of each arc.
        routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

        # Add Capacity constraint.
        def demand_callback(from_index):
            """Returns the demand of the node."""
            # Convert from routing variable Index to demands NodeIndex.
            from_node = manager.IndexToNode(from_index)
            return self._data['demands'][from_node]

        demand_callback_index = routing.RegisterUnaryTransitCallback(
            demand_callback)
        routing.AddDimensionWithVehicleCapacity(
            demand_callback_index,
            0,  # null capacity slack
            [self._data['vehicle_capacities']],  # vehicle maximum capacities
            True,  # start cumul to zero
            'Capacity')

        # Define Transportation Requests.
        for request in self._data['pickups_deliveries']:
            pickup_index = manager.NodeToIndex(request[0])
            delivery_index = manager.NodeToIndex(request[1])
            routing.AddPickupAndDelivery(pickup_index, delivery_index)
            routing.solver().Add(
                routing.VehicleVar(pickup_index) == routing.VehicleVar(
                    delivery_index))
            # routing.solver().Add(
            #     distance_dimension.CumulVar(pickup_index) <=
            #     distance_dimension.CumulVar(delivery_index))

        # Add Time Windows constraint.
        time = 'Time'
        routing.AddDimension(
            transit_callback_index,
            0,  # allow waiting time
            9999999999,  # maximum time per vehicle
            False,  # Don't force start cumul to zero.
            time)
        time_dimension = routing.GetDimensionOrDie(time)
        # Add time window constraints for each location except depot.
        for location_idx, time_window in enumerate(self._data['time_windows']):
            if location_idx == 0:
                continue
            index = manager.NodeToIndex(location_idx)
            time_dimension.CumulVar(index).SetRange(time_window[0], time_window[1])
        # Add time window constraints for each vehicle start node.
        for vehicle_id in range(self._data['num_vehicles']):
            index = routing.Start(vehicle_id)
            time_dimension.CumulVar(index).SetRange(self._data['time_windows'][0][0],
                                                    self._data['time_windows'][0][1])

        # Instantiate route start and end times to produce feasible times.
        for i in range(self._data['num_vehicles']):
            routing.AddVariableMinimizedByFinalizer(
                time_dimension.CumulVar(routing.Start(i)))
            routing.AddVariableMinimizedByFinalizer(
                time_dimension.CumulVar(routing.End(i)))

        # Setting first solution heuristic.
        search_parameters = pywrapcp.DefaultRoutingSearchParameters()
        search_parameters.time_limit.seconds = 2
        search_parameters.first_solution_strategy = (
            routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)

        # Solve the problem.
        solution = routing.SolveWithParameters(search_parameters)

        # Print solution on console.
        if solution:
            route, cost = self._get_routes_and_cost(solution, routing, manager)
            return route, cost
        else:
            return None, None


if __name__ == '__main__':
    from time import time

    # graph = [
    #     [
    #         0, 1, 2, 5, 3, 7, 4, 3
    #     ],
    #     [
    #         0, 0, 4, 5, 1, 2, 2, 1
    #     ],
    #     [
    #         0, 5, 0, 6, 9, 1, 1, 3
    #     ],
    #     [
    #         0, 5, 1, 0, 1, 3, 5, 5
    #     ],
    #     [
    #         0, 7, 3, 1, 0, 4, 3, 3
    #     ],
    #     [
    #         0, 2, 5, 2, 4, 0, 2, 4
    #     ],
    #     [
    #         0, 9, 8, 7, 6, 5, 0, 3
    #     ],
    #     [
    #         0, 6, 5, 4, 3, 2, 1, 0
    #     ]
    # ]
    # pickups_deliveries = [
    #     [3, 1],
    #     [5, 4],
    #     [2, 6]
    # ]
    # time_windows = [
    #     (0, 5),  # depot
    #     (0, 10),  # 1
    #     (0, 15),  # 2
    #     (0, 15),  # 3
    #     (0, 15),  # 4
    #     (0, 25),  # 5
    #     (0, 20),  # 6
    #     (0, 18),  # 7
    # ]
    # demands = [1, -1, 1, 1, -1, 1,-1,-1]


    graph = [
        [0, 6, 9, 8, 7, 3, 6, 2, 3, 2, 6, 6, 4, 4, 5, 9, 7, 8, 4, 6, 2],
        [0, 0, 8, 3, 2, 6, 8, 4, 8, 8, 13, 7, 5, 8, 12, 10, 14, 2, 5, 7, 8],
        [0, 8, 0, 11, 10, 6, 3, 9, 5, 8, 4, 15, 14, 13, 9, 18, 9, 3, 6, 9, 2],
        [0, 3, 11, 0, 1, 7, 10, 6, 10, 10, 14, 6, 7, 9, 14, 6, 16, 4, 5, 9, 1],
        [0, 2, 10, 1, 0, 6, 9, 4, 8, 9, 13, 4, 6, 8, 12, 8, 14, 3, 9, 1, 8],
        [0, 6, 6, 7, 6, 0, 2, 3, 2, 2, 7, 9, 7, 7, 6, 12, 8, 2, 4, 3, 5],
        [0, 8, 3, 10, 9, 2, 0, 6, 2, 5, 4, 12, 10, 10, 6, 15, 5, 9, 2, 8, 1],
        [0, 4, 9, 6, 4, 3, 6, 0, 4, 4, 8, 5, 4, 3, 7, 8, 10, 1, 2, 7, 6],
        [0, 8, 5, 10, 8, 2, 2, 4, 0, 3, 4, 9, 8, 7, 3, 13, 6, 1, 4, 4, 5],
        [0, 8, 8, 10, 9, 2, 5, 4, 3, 0, 4, 6, 5, 4, 3, 9, 5, 2, 2, 2, 3],
        [0, 13, 4, 14, 13, 7, 4, 8, 4, 4, 0, 10, 9, 8, 4, 13, 4, 4, 3, 2, 1],
        [0, 7, 15, 6, 4, 9, 12, 5, 9, 6, 10, 0, 1, 3, 7, 3, 10, 11, 9, 3, 4],
        [0, 5, 14, 7, 6, 7, 10, 4, 8, 5, 9, 1, 0, 2, 6, 4, 8, 4, 3, 6, 8],
        [0, 8, 13, 9, 8, 7, 10, 3, 7, 4, 8, 3, 2, 0, 4, 5, 6, 5, 6, 8, 7],
        [0, 12, 9, 14, 12, 6, 6, 7, 3, 3, 4, 7, 6, 4, 0, 9, 2, 1, 4, 4, 10],
        [0, 10, 18, 6, 8, 12, 15, 8, 13, 9, 13, 3, 4, 5, 9, 0, 9, 3, 3, 7, 6],
        [0, 14, 9, 16, 14, 8, 5, 10, 6, 5, 4, 10, 8, 6, 2, 9, 0, 4, 4, 3, 3],
        [0, 7, 6, 5, 4, 3, 4, 5, 6, 7, 8, 9, 5, 4, 3, 2, 3, 0, 1, 5, 6],
        [0, 3, 5, 9, 8, 6, 4, 8, 5, 2, 3, 6, 9, 7, 4, 1, 3, 5, 0, 5, 6],
        [0, 1, 4, 7, 8, 2, 5, 6, 3, 9, 9, 5, 1, 4, 3, 2, 3, 2, 8, 0, 6],
        [0, 7, 1, 7, 6, 3, 4, 9, 9, 5, 1, 3, 5, 7, 6, 5, 4, 5, 1, 9, 0],
    ]

    pickups_deliveries = [
        [1, 6],
        [2, 10],
        [4, 3],
        [5, 9],
        [7, 8],
        [15, 11],
        [13, 12],
        [16, 14],
        [17, 18],
        [19, 20],
    ]
    time_windows = [
        (0, 5),  # depot
        (0, 62),  # 1
        (0, 65),  # 2
        (0, 68),  # 3
        (0, 63),  # 4
        (0, 65),  # 5
        (0, 60),  # 6
        (0, 64),  # 7
        (0, 60),  # 8
        (0, 63),  # 9
        (0, 46),  # 10
        (0, 65),  # 11
        (0, 65),  # 12
        (0, 60),  # 13
        (0, 68),  # 14
        (0, 65),  # 15
        (0, 66),  # 16
        (0, 66),  # 17
        (0, 66),  # 18
        (0, 66),  # 19
        (0, 66),  # 20
    ]
    demands = [1, 1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, 1, -1, 1, -1]


    solver = TSP()
    time1 = time()
    route, cost = solver.solve_tsp(graph, pickups_deliveries, time_windows, demands)
    time2 = time()
    if route:
        print("cost:", cost)
        print("route:", route)
    else:
        print("未能求解")
    print("运算时间： ", time2 - time1, " s")
